-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2023 at 10:07 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shiftware`
--

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `c_id` int(11) NOT NULL,
  `wt_user_id` int(255) NOT NULL,
  `m_name` varchar(255) NOT NULL,
  `apprt_num` text NOT NULL,
  `religion` varchar(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `c_archived` int(2) NOT NULL,
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`c_id`, `wt_user_id`, `m_name`, `apprt_num`, `religion`, `nationality`, `language`, `c_archived`, `close`, `status`) VALUES
(1, 4, 'Mustafa', '123', 'islam', 'pakistani', 'punjabi', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `client_documents`
--

CREATE TABLE `client_documents` (
  `cl_doc_id` int(11) NOT NULL,
  `c_id` int(255) NOT NULL,
  `cl_doc_document` text NOT NULL,
  `cl_doc_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `company_bank`
--

CREATE TABLE `company_bank` (
  `comp_b_id` int(11) NOT NULL,
  `bank_title` varchar(50) NOT NULL,
  `bank_branch` varchar(50) NOT NULL,
  `account_no` text NOT NULL,
  `account_title` varchar(50) NOT NULL,
  `close` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company_bank`
--

INSERT INTO `company_bank` (`comp_b_id`, `bank_title`, `bank_branch`, `account_no`, `account_title`, `close`, `status`) VALUES
(1, 'Sample Bank', 'Sample', '12345678', 'Sample', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `company_info`
--

CREATE TABLE `company_info` (
  `com_id` int(11) NOT NULL,
  `com_name` varchar(50) NOT NULL,
  `com_phone` varchar(20) NOT NULL,
  `com_email` varchar(50) NOT NULL,
  `com_logo` text NOT NULL,
  `com_address` text NOT NULL,
  `close` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company_info`
--

INSERT INTO `company_info` (`com_id`, `com_name`, `com_phone`, `com_email`, `com_logo`, `com_address`, `close`, `status`) VALUES
(1, 'ShiftCare', '0000000000', 'info@centralmountainair.com', 'logo.jpg', 'ABC', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `event_date` date NOT NULL,
  `event_name` text NOT NULL,
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `in_id` int(11) NOT NULL,
  `in_c_id` int(11) NOT NULL,
  `in_invoice_number` varchar(255) NOT NULL,
  `in_customer_po_number` varchar(255) NOT NULL,
  `in_issue_date` date NOT NULL,
  `in_due_date` date NOT NULL,
  `in_accounts_are` varchar(50) NOT NULL,
  `in_customer_note` text NOT NULL,
  `in_subtotal` float NOT NULL,
  `in_total_tax` float NOT NULL,
  `in_total_amount` float NOT NULL,
  `in_paid_amount` float NOT NULL,
  `in_balance_due` float NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_items`
--

CREATE TABLE `invoice_items` (
  `it_id` int(11) NOT NULL,
  `it_in_id` int(11) NOT NULL,
  `it_i_id` int(11) NOT NULL,
  `it_account` varchar(255) NOT NULL,
  `it_unit_nmbers` varchar(255) NOT NULL,
  `it_discount` varchar(255) NOT NULL,
  `it_amount` varchar(255) NOT NULL,
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `i_id` int(11) NOT NULL,
  `i_name` varchar(255) NOT NULL,
  `i_description` text NOT NULL,
  `i_use_on_sale_purchase` int(2) NOT NULL,
  `i_item_id` varchar(255) NOT NULL,
  `i_inactive` int(2) NOT NULL,
  `i_sell_item` int(2) NOT NULL,
  `i_selling_price` varchar(100) NOT NULL,
  `i_selling_tax_status` varchar(50) NOT NULL,
  `i_selling_measure_unit` varchar(50) NOT NULL,
  `i_track_sale_account` varchar(255) NOT NULL,
  `i_selling_tax_code` varchar(100) NOT NULL,
  `i_buy_item` int(2) NOT NULL,
  `i_buying_price` varchar(100) NOT NULL,
  `i_buying_tax_status` varchar(50) NOT NULL,
  `i_buying_measure_unit` varchar(50) NOT NULL,
  `i_track_purchase_account` varchar(255) NOT NULL,
  `i_buying_tax_code` varchar(100) NOT NULL,
  `i_buying_sup_item_id` varchar(100) NOT NULL,
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `leave_management`
--

CREATE TABLE `leave_management` (
  `lv_id` int(11) NOT NULL,
  `emp_id` int(255) NOT NULL,
  `leavetype` varchar(255) NOT NULL,
  `half_day_leave_date` date NOT NULL,
  `half_day_leave_time_from` time NOT NULL,
  `half_day_leave_time_to` time NOT NULL,
  `full_day_leave_date` date NOT NULL,
  `multi_days_leave_date_from` date NOT NULL,
  `multi_days_leave_date_to` date NOT NULL,
  `leave_reason` text NOT NULL,
  `leave_create_date` date NOT NULL,
  `leave_status` int(3) NOT NULL,
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leave_management`
--

INSERT INTO `leave_management` (`lv_id`, `emp_id`, `leavetype`, `half_day_leave_date`, `half_day_leave_time_from`, `half_day_leave_time_to`, `full_day_leave_date`, `multi_days_leave_date_from`, `multi_days_leave_date_to`, `leave_reason`, `leave_create_date`, `leave_status`, `close`, `status`) VALUES
(1, 2, 'fullday', '0000-00-00', '00:00:00', '00:00:00', '2023-07-15', '0000-00-00', '0000-00-00', 'ill', '2023-07-14', 2, 1, 1),
(2, 2, 'fullday', '0000-00-00', '00:00:00', '00:00:00', '2023-07-15', '0000-00-00', '0000-00-00', 'work', '2023-07-14', 0, 1, 1),
(3, 2, 'fullday', '0000-00-00', '00:00:00', '00:00:00', '2023-07-16', '0000-00-00', '0000-00-00', 'personal', '2023-07-14', 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `rejected_shifts`
--

CREATE TABLE `rejected_shifts` (
  `rs_id` int(11) NOT NULL,
  `rs_sr_id` int(11) NOT NULL,
  `rs_date` date NOT NULL,
  `rs_by` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sectors`
--

CREATE TABLE `sectors` (
  `sec_id` int(11) NOT NULL,
  `sector_name` text NOT NULL,
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sectors`
--

INSERT INTO `sectors` (`sec_id`, `sector_name`, `close`, `status`) VALUES
(1, 'paint', 1, 1),
(2, 'plumber', 1, 1),
(3, 'driver', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `ser_id` int(11) NOT NULL,
  `service_name` text NOT NULL,
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`ser_id`, `service_name`, `close`, `status`) VALUES
(1, 'paint', 1, 1),
(2, 'wall paintings', 1, 1),
(3, 'Spray painting', 1, 1),
(4, 'car painting', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shifts`
--

CREATE TABLE `shifts` (
  `s_id` int(11) NOT NULL,
  `s_client` int(11) NOT NULL,
  `s_shift_type` varchar(255) NOT NULL,
  `s_staff` varchar(255) NOT NULL,
  `s_shiftdate` date NOT NULL,
  `s_finish_next_day` int(2) NOT NULL,
  `s_starttime` time NOT NULL,
  `s_endtime` time NOT NULL,
  `s_repeat` int(2) NOT NULL,
  `s_recurrance` varchar(50) NOT NULL,
  `s_address` text NOT NULL,
  `s_apartment` text NOT NULL,
  `s_instructions` text NOT NULL,
  `s_completed` int(2) NOT NULL,
  `create_date` date NOT NULL,
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shifts`
--

INSERT INTO `shifts` (`s_id`, `s_client`, `s_shift_type`, `s_staff`, `s_shiftdate`, `s_finish_next_day`, `s_starttime`, `s_endtime`, `s_repeat`, `s_recurrance`, `s_address`, `s_apartment`, `s_instructions`, `s_completed`, `create_date`, `close`, `status`) VALUES
(1, 1, '1', '3', '2023-07-14', 0, '04:07:00', '18:10:00', 0, '', 'kohenoor city', '02', 'hello', 0, '2023-07-14', 1, 1),
(2, 1, '1', '0,3', '2023-07-15', 0, '04:07:00', '18:10:00', 0, '', '09', '67', '', 0, '2023-07-14', 1, 1),
(3, 1, '2', '0,2', '2023-07-16', 0, '08:00:00', '16:00:00', 0, '', 'aaa', 'bbb', '', 0, '2023-07-14', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shift_dates`
--

CREATE TABLE `shift_dates` (
  `sd_id` int(11) NOT NULL,
  `sd_s_id` int(11) NOT NULL,
  `sd_date` date NOT NULL,
  `sd_complete` int(11) NOT NULL,
  `sd_reject` int(11) NOT NULL,
  `sd_hour` float NOT NULL,
  `sd_milage` float NOT NULL,
  `sd_expense` int(11) NOT NULL,
  `sd_note` text NOT NULL,
  `sd_rating` int(11) NOT NULL,
  `sd_rating_feedback` text NOT NULL,
  `sd_completed_date` date NOT NULL,
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shift_dates`
--

INSERT INTO `shift_dates` (`sd_id`, `sd_s_id`, `sd_date`, `sd_complete`, `sd_reject`, `sd_hour`, `sd_milage`, `sd_expense`, `sd_note`, `sd_rating`, `sd_rating_feedback`, `sd_completed_date`, `close`, `status`) VALUES
(1, 1, '2023-07-14', 2, 0, 6, 2, 7, '', 5, '', '2023-07-14', 1, 1),
(2, 2, '2023-07-15', 0, 0, 0, 0, 0, '', 0, '', '0000-00-00', 1, 1),
(3, 3, '2023-07-16', 0, 0, 0, 0, 0, '', 0, '', '0000-00-00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shift_orgnal_staff`
--

CREATE TABLE `shift_orgnal_staff` (
  `s_o_s_id` int(11) NOT NULL,
  `shift_id` int(11) NOT NULL,
  `staff_id` varchar(255) NOT NULL,
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shift_orgnal_staff`
--

INSERT INTO `shift_orgnal_staff` (`s_o_s_id`, `shift_id`, `staff_id`, `close`, `status`) VALUES
(1, 1, '0,2', 1, 1),
(2, 2, '0,2', 1, 1),
(3, 3, '0,2', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sms`
--

CREATE TABLE `sms` (
  `sms_id` int(11) NOT NULL,
  `sms_link` text NOT NULL,
  `sms_username` varchar(50) NOT NULL,
  `sms_password` text NOT NULL,
  `sms_email` varchar(100) NOT NULL,
  `close` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sms`
--

INSERT INTO `sms` (`sms_id`, `sms_link`, `sms_username`, `sms_password`, `sms_email`, `close`, `status`) VALUES
(1, 'http//localhost/atozcoder/admin/profile-setting', 'atozcoder', '123', 'berat@gmail.com', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `staff_documents`
--

CREATE TABLE `staff_documents` (
  `staff_dco_id` int(11) NOT NULL,
  `staff_id` int(255) NOT NULL,
  `stf_doc_document` text NOT NULL,
  `stf_doc_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `staff_sector`
--

CREATE TABLE `staff_sector` (
  `staff_sec_id` int(11) NOT NULL,
  `wt_user_id` int(255) NOT NULL,
  `sector_id` int(255) NOT NULL,
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff_sector`
--

INSERT INTO `staff_sector` (`staff_sec_id`, `wt_user_id`, `sector_id`, `close`, `status`) VALUES
(1, 2, 1, 1, 1),
(2, 3, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wt_users`
--

CREATE TABLE `wt_users` (
  `id` int(11) NOT NULL,
  `prefix` varchar(255) NOT NULL,
  `profile_img` text NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_type` varchar(40) NOT NULL,
  `email` varchar(250) NOT NULL,
  `address` text NOT NULL,
  `phone` text NOT NULL,
  `mobile` text NOT NULL,
  `dob` date NOT NULL,
  `password` varchar(250) NOT NULL,
  `archieved` int(2) NOT NULL,
  `close` int(2) NOT NULL,
  `status` int(2) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wt_users`
--

INSERT INTO `wt_users` (`id`, `prefix`, `profile_img`, `f_name`, `l_name`, `user_name`, `user_type`, `email`, `address`, `phone`, `mobile`, `dob`, `password`, `archieved`, `close`, `status`, `create_date`) VALUES
(1, 'Mr.', '', 'Muhammad', 'Safdar', 'atozcoder', 'admin', 'admin@atozcoder.com', 'qwerty', '03038590506', '03038590506', '2000-10-07', '827ccb0eea8a706c4c34a16891f84e7b', 0, 1, 1, '2022-04-17 01:55:24'),
(2, 'Mr.', '', 'Akbar', 'Ali', 'akbar017', 'staff', 'akbar046@gmail.com', 'al khari plaza faislabad', '03051055780', '923051055780', '2000-08-05', '202cb962ac59075b964b07152d234b70', 0, 1, 1, '2023-07-14 13:00:50'),
(3, 'Miss', '', 'irfa', 'anum', 'anum017', 'staff', 'unistudenetl!@gmail.com', 'al khair plaza ', '03038590506', '923038590506', '2019-01-29', '81dc9bdb52d04dc20036dbd8313ed055', 0, 1, 1, '2023-07-14 13:03:04'),
(4, 'Mr.', '', 'Ghulam', '2.O', '', 'client', 'gm956900@gmaol.com', 'al khari plaza faislavad', '03154385817', '923154385817', '2019-02-05', '', 0, 1, 1, '2023-07-14 13:04:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `client_documents`
--
ALTER TABLE `client_documents`
  ADD PRIMARY KEY (`cl_doc_id`);

--
-- Indexes for table `company_bank`
--
ALTER TABLE `company_bank`
  ADD PRIMARY KEY (`comp_b_id`);

--
-- Indexes for table `company_info`
--
ALTER TABLE `company_info`
  ADD PRIMARY KEY (`com_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`in_id`);

--
-- Indexes for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD PRIMARY KEY (`it_id`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`i_id`);

--
-- Indexes for table `leave_management`
--
ALTER TABLE `leave_management`
  ADD PRIMARY KEY (`lv_id`);

--
-- Indexes for table `rejected_shifts`
--
ALTER TABLE `rejected_shifts`
  ADD PRIMARY KEY (`rs_id`);

--
-- Indexes for table `sectors`
--
ALTER TABLE `sectors`
  ADD PRIMARY KEY (`sec_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`ser_id`);

--
-- Indexes for table `shifts`
--
ALTER TABLE `shifts`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `shift_dates`
--
ALTER TABLE `shift_dates`
  ADD PRIMARY KEY (`sd_id`);

--
-- Indexes for table `shift_orgnal_staff`
--
ALTER TABLE `shift_orgnal_staff`
  ADD PRIMARY KEY (`s_o_s_id`);

--
-- Indexes for table `sms`
--
ALTER TABLE `sms`
  ADD PRIMARY KEY (`sms_id`);

--
-- Indexes for table `staff_documents`
--
ALTER TABLE `staff_documents`
  ADD PRIMARY KEY (`staff_dco_id`);

--
-- Indexes for table `staff_sector`
--
ALTER TABLE `staff_sector`
  ADD PRIMARY KEY (`staff_sec_id`);

--
-- Indexes for table `wt_users`
--
ALTER TABLE `wt_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `client_documents`
--
ALTER TABLE `client_documents`
  MODIFY `cl_doc_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `company_bank`
--
ALTER TABLE `company_bank`
  MODIFY `comp_b_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `company_info`
--
ALTER TABLE `company_info`
  MODIFY `com_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `in_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoice_items`
--
ALTER TABLE `invoice_items`
  MODIFY `it_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `i_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_management`
--
ALTER TABLE `leave_management`
  MODIFY `lv_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `rejected_shifts`
--
ALTER TABLE `rejected_shifts`
  MODIFY `rs_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sectors`
--
ALTER TABLE `sectors`
  MODIFY `sec_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `ser_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `shifts`
--
ALTER TABLE `shifts`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `shift_dates`
--
ALTER TABLE `shift_dates`
  MODIFY `sd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `shift_orgnal_staff`
--
ALTER TABLE `shift_orgnal_staff`
  MODIFY `s_o_s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sms`
--
ALTER TABLE `sms`
  MODIFY `sms_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `staff_documents`
--
ALTER TABLE `staff_documents`
  MODIFY `staff_dco_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_sector`
--
ALTER TABLE `staff_sector`
  MODIFY `staff_sec_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wt_users`
--
ALTER TABLE `wt_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

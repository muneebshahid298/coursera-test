<?php
	$con  = mysqli_connect('localhost','root','','shiftware');
	if($con == false){
	    echo "Connection Not Established";
	}else{
		$company = "SELECT * FROM company_info WHERE close ='1' AND status = '1'";
        $company_ex = mysqli_query($con,$company);
        foreach($company_ex as $row){
        	$_SESSION['cm_name'] = $row['com_name'];
        	$_SESSION['cm_phone'] = $row['com_phone'];
        	$_SESSION['cm_email'] = $row['com_email'];
        	$_SESSION['cm_logo'] = $row['com_logo'];
        	$_SESSION['cm_address'] = $row['com_address'];
        	$loginphoto = $row['com_logo'];
        }
	}
?>
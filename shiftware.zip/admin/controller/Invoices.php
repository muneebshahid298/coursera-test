<?php
	$res_data = "SELECT * FROM invoice JOIN invoice_items ON invoice.in_id=invoice_items.it_in_id JOIN client ON invoice.in_c_id = client.c_id WHERE invoice.close = '1' AND invoice.status = '1' GROUP BY invoice_items.it_in_id";
	$res_data_ex = mysqli_query($con,$res_data);

	$email = "SELECT * FROM company_info WHERE close = '1' AND status = '1'";
	$email_ex = mysqli_query($con,$email);

	foreach ($email_ex as $email) {
		$company_email = $email['com_email'];
	}


if(isset($_POST['submitpaidamount'])){
      $total_amount = 0;
      $in_id = $_POST['in_id'];
      $paid_amount = $_POST['paid_amount'];

      $select_invoice = "SELECT * FROM invoice WHERE in_id = '".$in_id."'";
      $select_invoice_ex = mysqli_query($con,$select_invoice);
      foreach ($select_invoice_ex as $row) {
            $total_amount = $row['in_total_amount'];
      }
      $due_amount = $total_amount - $paid_amount;

      
      $update_invoice = "UPDATE `invoice` SET `in_paid_amount`='".$paid_amount."', `in_balance_due`='".$due_amount."' WHERE in_id = '".$in_id."'";
      $update_invoice_ex = mysqli_query($con,$update_invoice);

      if($update_invoice_ex){
            header('Location: invoices');
      }
}
?>
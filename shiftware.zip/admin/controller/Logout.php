<?php
session_unset();
header('Location:../login');
 ?>
 
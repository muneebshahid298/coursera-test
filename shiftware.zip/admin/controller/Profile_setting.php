<!--
Created By: Aadil Sohail
Dated: Novenber 14, 2019
Purpose:  Profile Setting
-->
 <?php
    $fetch1 = "SELECT * FROM wt_users WHERE id ='".$_SESSION['id']."'";
    $user_update = mysqli_query($con,$fetch1);
 if(isset($_POST['update'])){
    $fname = isset($_POST['fname']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['fname']) : "";
    $lname = isset($_POST['lname']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['lname']) : "";
    $email = isset($_POST['email']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['email']) : "";
    $password1 = isset($_POST['password']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['password']) : "";
    $password = md5($password1);
    $phone_no = isset($_POST['phoneno']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['phoneno']) : "";
           $add_user_sql = "UPDATE  wt_users SET f_name = '".$fname."',l_name = '".$lname."' WHERE id = '".$_SESSION['id']."'";
         $add_user_sql_ex = mysqli_query($con,$add_user_sql);
         if ($add_user_sql_ex) {
             header('Location:../login');
         }
      else{
        echo "error";
      }

    }
    
    if(isset($_POST['updatecompany'])){
    echo $companyname = isset($_POST['companyname']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['companyname']) : "";
    $companyphone = isset($_POST['companyphone']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['companyphone']) : "";
    $companyemail = isset($_POST['companyemail']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['companyemail']) : "";
    $companyaddress = isset($_POST['companyaddress']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['companyaddress']) : "";
    $logo_photo = $_FILES['logo_photo']['name'];
    if (empty($logo_photo)){
        $add_user_sql = "UPDATE  company_info SET com_name = '".$companyname."',com_phone = '".$companyphone."',com_email = '".$companyemail."',com_address = '".$companyaddress."',close = '1',status = '1' WHERE com_id = '1' ";
         $add_user_sql_ex = mysqli_query($con,$add_user_sql);
    }else{
        $folder = "../img/".$logo_photo;   
        move_uploaded_file($tempname, $folder);
        $add_user_sql = "UPDATE  company_info SET com_name = '".$companyname."',com_phone = '".$companyphone."',com_email = '".$companyemail."',com_logo = '".$logo_photo."',com_address = '".$companyaddress."',close = '1',status = '1' WHERE com_id = '1' ";
         $add_user_sql_ex = mysqli_query($con,$add_user_sql);
    }
        
    if ($add_user_sql_ex) {
        header('Location: profile-setting');
        }
    else{
        echo "error";
      }
  }
    $company_bank = "SELECT * FROM company_bank WHERE close ='1' AND status = '1'";
    $company_bank_ex = mysqli_query($con,$company_bank);
    if(isset($_POST['Updatebank'])){
    $banktitle = isset($_POST['banktitle']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['banktitle']) : "";
    $bankbranch = isset($_POST['bankbranch']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['bankbranch']) : "";
    $accounttitle = isset($_POST['accounttitle']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['accounttitle']) : "";
    $accountno = isset($_POST['accountno']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['accountno']) : "";
        $add_user_sql_bank = "UPDATE  company_bank SET bank_title = '".$banktitle."',bank_branch = '".$bankbranch."',account_no = '".$accountno."',account_title = '".$accounttitle."',close = '1',status = '1' WHERE comp_b_id = '1' ";
         $add_user_sql_bank_ex = mysqli_query($con,$add_user_sql_bank);
         if ($add_user_sql_bank_ex) {
             header('Location: profile-setting');
         }
      else{
        echo "error";
      }

    }
    $sms = "SELECT * FROM sms WHERE close ='1' AND status = '1'";
    $sms_ex = mysqli_query($con,$sms);
    if(isset($_POST['updatesms'])){
    $smslink = isset($_POST['smslink']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['smslink']) : "";
    $smsuname = isset($_POST['smsuname']) ? preg_replace('/[^!<>@&.\/\sA-Za-z0-9_-]/', '', $_POST['smsuname']) : "";
    $smspassword = $_POST['smspassword'];
    $add_sms = "UPDATE sms SET sms_link = '".$smslink."',sms_username = '".$smsuname."',sms_password = '".$smspassword."',close = '1',status = '1' WHERE sms_id = '1' ";
         $add_sms_ex = mysqli_query($con,$add_sms);
         if ($add_sms_ex) {
             header('Location: profile-setting');
         }
      else{
        echo "error";
      }

    }
    
?>

<?php
$current_date = date('Y-m-d');

if (isset($_POST['submitevent'])) {
      $event_date = $_POST['event_date'];
      $event_name = $_POST['event_name'];
      $insert_event = "INSERT INTO `events`(`event_date`,`event_name`,`close`, `status`) VALUES ('".$event_date."','".$event_name."','1','1')";
      $insert_event_ex = mysqli_query($con,$insert_event);

      if ($insert_event_ex) {
            header("Location: events");
      }
}





if (isset($_POST['editevent'])) {
      $event_id = $_POST['event_id'];
      $event_name_u = $_POST['event_name_u'];
      $event_date_u = $_POST['event_date_u'];

      $update_event = "UPDATE `events` SET `event_date`='".$event_date_u."',`event_name`='".$event_name_u."' WHERE event_id = '".$event_id."'";
      $update_event_ex = mysqli_query($con,$update_event);

}
?>
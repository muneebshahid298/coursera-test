<?php
	$res_data = "SELECT * FROM wt_users JOIN client ON wt_users.id=client.wt_user_id WHERE wt_users.close = '1' AND wt_users.status = '1' AND client.c_archived = '1' AND wt_users.user_type ='client'";
	$res_data_ex = mysqli_query($con,$res_data);

	$email = "SELECT * FROM company_info WHERE close = '1' AND status = '1'";
	$email_ex = mysqli_query($con,$email);

	foreach ($email_ex as $email) {
		$company_email = $email['com_email'];
	}

	
            if(isset($_POST['editclient'])){
            $image = $_FILES['profile_img_u']['name'];
            $submit_image = $_FILES['profile_img_u']['tmp_name'];
            $img_path = "../assets/img/".$image;
            move_uploaded_file($submit_image,$img_path);


            $clientid = $_POST['clientid'];
            $prefix_u = $_POST['prefix_u'];
            $fname_u = $_POST['fname_u'];
            $mname_u = $_POST['mname_u'];
            $lname_u = $_POST['lname_u'];
            $phone_u = $_POST['phone_u'];
            $mobile_u = $_POST['mobile_u'];
            $dob_u = $_POST['dob_u'];
            $email_u = $_POST['email_u'];
            $address_u = $_POST['address_u'];
            $aprt_num_u = $_POST['aprt_num_u'];
            $religion_u = $_POST['religion_u'];
            $nationality_u = $_POST['nationality_u'];
            $language_u = $_POST['language_u'];

            $update_client = "UPDATE `wt_users` SET `profile_img`='".$image."',`prefix`='".$prefix_u."',`f_name`='".$fname_u."',`l_name`='".$lname_u."',`email`='".$email_u."',`address`='".$address_u."',`phone`='".$phone_u."',`mobile`='".$mobile_u."',`dob`='".$dob_u."' WHERE id = '".$clientid."'";
            $update_client_ex = mysqli_query($con,$update_client);

            if($update_client_ex){
            $update_client1 = "UPDATE `client` SET `m_name`='".$mname_u."',`apprt_num`='".$aprt_num_u."',`religion`='".$religion_u."',`nationality`='".$nationality_u."',`language`='".$language_u."' WHERE wt_user_id = '".$clientid."'";
            $update_client1_ex = mysqli_query($con,$update_client1);
            if ($update_client1_ex) {
            header("Location: clientarchived");
            }
            }else{
            echo "<div class='alert alert-danger' style = 'text-align : center;'><strong>Something</strong> Went Worng!!</div>";
            }
      }



      if (isset($_POST['subclientdoc'])) {
             $doc = $_FILES['cl_doc_document']['name'];
            $submit_doc = $_FILES['cl_doc_document']['tmp_name'];
            $img_path = "../assets/img/".$doc;
            move_uploaded_file($submit_doc,$img_path);
             $idclient = $_POST['idclient'];
            $insert_client_doc = "INSERT INTO `client_documents`(`c_id`,`cl_doc_document`,`close`, `status`) VALUES ('".$idclient."','".$doc."','1','1')";
            $insert_client_doc_ex = mysqli_query($con,$insert_client_doc);
      }
?>
<?php
$current_date = date('Y-m-d');
$current_month = date('m');
$current_month2 = date('F');
$current_year = date('Y');

	$user_email = $_SESSION['user_email'];
	$user_name = $_SESSION['user_name'];
	$user_id = $_SESSION['id']; 
	$fetch = "SELECT * FROM wt_users WHERE email = '".$user_email."' AND status = '1' AND close = '1' AND user_type = 'admin'";
	$execuit = mysqli_query($con,$fetch);

	$current_date = date('Y-m-d');

      $total_worked_hours = 0;
	$select_total_hours = "SELECT *,SUM(sd_hour) FROM shift_dates WHERE close = '1' AND status = '1'";
	$select_total_hours_ex = mysqli_query($con,$select_total_hours);
	foreach ($select_total_hours_ex as $row) {
		$total_worked_hours = $row['SUM(sd_hour)'];
	}


      $total_created_shifts = 0;
      $select_created_shifts = "SELECT * FROM shift_dates WHERE close = '1' AND status = '1' AND sd_reject = '0'";
      $select_created_shifts_ex = mysqli_query($con,$select_created_shifts);
      $total_created_shifts = mysqli_num_rows($select_created_shifts_ex);

      $total_accepted_shifts = 0;
      $select_rejected_shifts = "SELECT * FROM shift_dates WHERE close = '1' AND status = '1' AND sd_reject = '1'";
      $select_rejected_shifts_ex = mysqli_query($con,$select_rejected_shifts);
      $total_rejectd_shifts = mysqli_num_rows($select_rejected_shifts_ex);


      $select_staff_with_most_hours = "SELECT *,SUM(sd_hour) FROM shifts JOIN shift_dates ON shifts.s_id=shift_dates.sd_s_id JOIN wt_users ON shifts.s_staff=wt_users.id WHERE shift_dates.close = '1' AND shift_dates.status = '1' AND wt_users.user_type ='staff' GROUP BY shifts.s_staff ORDER BY SUM(sd_hour) DESC";
	$select_staff_with_most_hours_ex = mysqli_query($con,$select_staff_with_most_hours);

      $weekly_repeated_shifts = array();
      $i = 1;
      $select_top_weekly_provided_services = "SELECT *,SUM(close) FROM shifts WHERE close = '1' AND status = '1' AND s_recurrance = 'weekly' GROUP BY s_shift_type ORDER BY SUM(close) DESC LIMIT 3";
      $select_top_weekly_provided_services_ex = mysqli_query($con,$select_top_weekly_provided_services);
      foreach ($select_top_weekly_provided_services_ex as $row) {
            $weekly_repeated_shifts[$i] = $row['s_shift_type'];
            $i++;
      }

      $monthly_repeated_shifts = array();
      $j = 1;
      $select_top_monthly_provided_services = "SELECT *,SUM(close) FROM shifts WHERE close = '1' AND status = '1' AND s_recurrance = 'monthly' GROUP BY s_shift_type ORDER BY SUM(close) DESC LIMIT 3";
      $select_top_monthly_provided_services_ex = mysqli_query($con,$select_top_monthly_provided_services);
      foreach ($select_top_monthly_provided_services_ex as $row) {
            $monthly_repeated_shifts[$j] = $row['s_shift_type'];
            $j++;
      }

      $current_month_sales = 0;
      $select_current_month_sale = "SELECT *,SUM(in_total_amount) FROM invoice WHERE MONTH(in_issue_date) = '".$current_month."' AND YEAR(in_issue_date) = '".$current_year."' AND close = '1' AND status = '1' GROUP BY MONTH(in_issue_date),YEAR(in_issue_date)";
      $select_current_month_sale_ex = mysqli_query($con,$select_current_month_sale);
      foreach ($select_current_month_sale_ex as $row) {
            $current_month_sales = $row['SUM(in_total_amount)'];
      }

      $select_open_invoices = "SELECT * FROM invoice WHERE in_balance_due != 0 AND close = '1' AND status = '1'";
      $select_open_invoices_ex = mysqli_query($con,$select_open_invoices);
      $open_invoices = mysqli_num_rows($select_open_invoices_ex);

      $select_overdue_invoices = "SELECT * FROM invoice WHERE in_balance_due != 0 AND in_due_date < '".$current_date."' AND close = '1' AND status = '1'";
      $select_overdue_invoices_ex = mysqli_query($con,$select_overdue_invoices);
      $overdue_invoices = mysqli_num_rows($select_overdue_invoices_ex);

      $client = "SELECT * FROM client WHERE close = '1' AND status = '1' ";
      $client_ex = mysqli_query($con,$client);
      $total_client = mysqli_num_rows($client_ex);

      $staff_sector = "SELECT * FROM staff_sector WHERE close = '1' AND status = '1' ";
      $staff_sector_ex = mysqli_query($con,$staff_sector);
      $total_staff_sector = mysqli_num_rows($staff_sector_ex);

      $services = "SELECT * FROM services WHERE close = '1' AND status = '1' ";
      $services_ex = mysqli_query($con,$services);
      $total_services = mysqli_num_rows($services_ex);

      $sectors = "SELECT * FROM sectors WHERE close = '1' AND status = '1' ";
      $sectors_ex = mysqli_query($con,$sectors);
      $total_sectors = mysqli_num_rows($sectors_ex);

?>
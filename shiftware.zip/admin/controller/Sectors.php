<?php 	
	if(isset($_POST['submitp'])){
 		$sector_name = $_POST['sector_name'];

	   	$add_sector = "INSERT INTO `sectors` (`sector_name`, `close`, `status`) VALUES ('".$sector_name."','1','1')";
	   	$add_sector_ex = mysqli_query($con,$add_sector);

	   	if($add_sector_ex){
	   		header('location: sectors');
	   	}
	   	else{
	   		print_r($add_sector);
	   	}

	}
	if (isset($_POST['updatep'])) {
		$sec_id = $_POST['sec_id'];
		$sector_name = $_POST['sector_name_u'];
	   	$update_sector = "UPDATE sectors SET sector_name='".$sector_name."' WHERE sec_id ='".$sec_id."'";
	   	$update_sector_ex = mysqli_query($con,$update_sector);
	   	if ($update_sector_ex) {
	   		header('location: sectors');
	   	}
	   	else{
	   		echo "sorry";
	   	}
	}

 ?>
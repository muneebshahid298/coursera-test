<?php
	$res_data = "SELECT * FROM accounts WHERE close = '1' AND status = '1'";
	$res_data_ex = mysqli_query($con,$res_data);

if (isset($_POST['submitaccount'])) {

      $acc_name = $_POST['acc_name'];
	$acc_type = $_POST['acc_type'];
	
	$insert_account = "INSERT INTO `accounts`(`acc_name`,`acc_type`, `close`, `status`) VALUES ('".$acc_name."','".$acc_type."','1','1')";
      $insert_account_ex = mysqli_query($con,$insert_account);
      if ($insert_account_ex) {
            header('Location: accounts');
      }
}

if (isset($_POST['updateaccount'])) {

      $acc_id = $_POST['acc_id'];
      $acc_name = $_POST['acc_name'];
      $acc_type = $_POST['acc_type'];
      
      $update_account = "UPDATE accounts SET acc_name = '".$acc_name."', acc_type = '".$acc_type."' WHERE acc_id = '".$acc_id."'";
      $update_account_ex = mysqli_query($con,$update_account);
      if ($update_account_ex) {
            header('Location: accounts');
      }
}
?>
<?php


$select_staff = "SELECT * FROM wt_users WHERE user_type = 'staff' AND close = '1' AND status = '1'";
$select_staff_ex = mysqli_query($con,$select_staff);

$select_shift = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id WHERE shifts.close = '1' AND shifts.status = '1' AND shift_dates.sd_complete = '0' AND shift_dates.sd_reject = '0' AND shift_dates.close = '1' AND shift_dates.status = '1'";
$select_shift_ex = mysqli_query($con,$select_shift);

$select_shift2 = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id JOIN wt_users ON shifts.s_staff = wt_users.id WHERE shifts.close = '1' AND shifts.status = '1' AND shift_dates.sd_complete = '1' AND shift_dates.sd_reject = '0' AND shift_dates.close = '1' AND shift_dates.status = '1'";
$select_shift2_ex = mysqli_query($con,$select_shift2);

$select_shift3 = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id JOIN wt_users ON shifts.s_staff = wt_users.id WHERE shifts.close = '1' AND shifts.status = '1' AND shift_dates.sd_complete = '2' AND shift_dates.sd_reject = '0' AND shift_dates.close = '1' AND shift_dates.status = '1'";
$select_shift3_ex = mysqli_query($con,$select_shift3);

$select_shift4 = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id JOIN wt_users ON shifts.s_staff = wt_users.id WHERE shifts.close = '1' AND shifts.status = '1' AND shift_dates.sd_complete = '0' AND shift_dates.sd_reject = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'";
$select_shift4_ex = mysqli_query($con,$select_shift4);


$current_date = date('Y-m-d');

if (isset($_POST['submitshift'])) {
      $client = $_POST['client'];
      $shift_type = $_POST['shift_type'];
      $staff = 0;
      for ($i=0; $i < sizeof($_POST['staff']); $i++) { 
            $staff = $staff.",".$_POST['staff'][$i];
      }
      $shiftdate = $_POST['shiftdate'];
      $finish_next_day = $_POST['finish_next_day'];
      $starttime = $_POST['starttime'];
      $endtime = $_POST['endtime'];
      $repeat = $_POST['repeat'];
      $repeat_dates = array();
      if ($repeat == '1') {
            $repeat_dates2 = $shiftdate;
            $recurrance = $_POST['recurrance'];
            if ($recurrance == 'daily') {
                  $daily_repeat_every = $_POST['daily_repeat_every'];
                  for ($i=0; $i < $daily_repeat_every ; $i++) { 
                        array_push($repeat_dates,$repeat_dates2);
                        $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                  }
                 
            }
            elseif ($recurrance == 'weekly') {
                  $weekly_repeat_every = $_POST['weekly_repeat_every'];
                  $mon = $_POST['mon'];
                  $tue = $_POST['tue'];
                  $wed = $_POST['wed'];
                  $thu = $_POST['thu'];
                  $fri = $_POST['fri'];
                  $sat = $_POST['sat'];
                  $sun = $_POST['sun'];

                  $time=strtotime($repeat_dates2);
                  $dayname=date("D",$time);
                  $day=date("d",$time);
                  $month=date("m",$time);
                  $year=date("Y",$time);
                  $day_of_week = date('N', strtotime($dayname));
                  $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' -'.$day_of_week.'day'));
                  $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));

                  for ($i=0; $i < $weekly_repeat_every; $i++) { 
                        if ($mon == 1) {
                              array_push($repeat_dates,$repeat_dates2);
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        else{
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        if ($tue == 1) {
                              array_push($repeat_dates,$repeat_dates2);
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        else{
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        if ($wed == 1) {
                              array_push($repeat_dates,$repeat_dates2);
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        else{
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        if ($thu == 1) {
                              array_push($repeat_dates,$repeat_dates2);
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        else{
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        if ($fri == 1) {
                              array_push($repeat_dates,$repeat_dates2);
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        else{
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        if ($sat == 1) {
                              array_push($repeat_dates,$repeat_dates2);
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        else{
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        if ($sun == 1) {
                              array_push($repeat_dates,$repeat_dates2);
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                        else{
                              $repeat_dates2 = date('Y-m-d', strtotime($repeat_dates2 . ' +1 day'));
                        }
                  }
                
            }
            elseif ($recurrance == 'monthly') {
                  $monthly_repeat_every = $_POST['monthly_repeat_every'];
                  $occures_on = $_POST['occures_on'];

                  $time=strtotime($repeat_dates2);
                  $day=date("d",$time);
                  $month=date("m",$time);
                  $year=date("Y",$time);

                  if ($day > $occures_on) {
                        $month++;
                  }
                  for ($i=0; $i < $monthly_repeat_every; $i++) { 
                        $month = sprintf("%02d", $month);
                        $repeat_dates2 = $year."-".$month."-".$occures_on;
                        array_push($repeat_dates,$repeat_dates2);
                        $month++;
                  }
                
            }
      }
      elseif ($repeat == '0') {
            array_push($repeat_dates,$shiftdate);
            $recurrance = "";
         
      }
      $address = $_POST['address'];
      $apartment = $_POST['apartment'];
      $instructions = $_POST['instructions'];
      

      $insert_shift = "INSERT INTO `shifts`(`s_client`, `s_shift_type`, `s_staff`, `s_shiftdate`, `s_finish_next_day`, `s_starttime`, `s_endtime`, `s_repeat`, `s_recurrance`, `s_address`, `s_apartment`, `s_instructions`,`s_completed`, `create_date`, `close`, `status`) VALUES ('".$client."','".$shift_type."','".$staff."','".$shiftdate."','".$finish_next_day."','".$starttime."','".$endtime."','".$repeat."','".$recurrance."','".$address."','".$apartment."','".$instructions."','0','".$current_date."','1','1')";
      $insert_shift_ex = mysqli_query($con,$insert_shift);

      if ($insert_shift_ex) {
            $last_id = $con->insert_id;

             $insert_shift_staf_org = "INSERT INTO `shift_orgnal_staff`(`shift_id`, `staff_id`, `close`, `status`) VALUES ('".$last_id."','".$staff."','1','1')";
            $insert_shift_staf_org_ex = mysqli_query($con,$insert_shift_staf_org);



            for ($i=0; $i < count($repeat_dates); $i++) {
                  $insert_shift_dates = "INSERT INTO `shift_dates`(`sd_s_id`, `sd_date`, `close`, `status`) VALUES ('".$last_id."','".$repeat_dates[$i]."','1','1')";
                  $insert_shift_dates_ex = mysqli_query($con,$insert_shift_dates);
            }
            if ($insert_shift_dates_ex) {
                  header("Location: shifts");
            }
      }

}

if (isset($_POST['editshift'])) {
      $s_id = $_POST['s_id'];
      $sd_id = $_POST['sd_id'];
      $client = $_POST['client'];
      $shift_type = $_POST['shift_type'];
      $staff = 0;
      for ($i=0; $i < sizeof($_POST['staff']); $i++) { 
            $staff = $staff.",".$_POST['staff'][$i];
      }
      $shiftdate = $_POST['shiftdate'];
      $starttime = $_POST['starttime'];
      $endtime = $_POST['endtime'];
      

      $delete_shift_date = "DELETE FROM shift_dates WHERE sd_id = '".$sd_id."'";
      $delete_shift_date_ex = mysqli_query($con,$delete_shift_date);
      if ($delete_shift_date_ex) {
            $insert_shift = "INSERT INTO `shifts`(`s_client`, `s_shift_type`, `s_staff`, `s_shiftdate`, `s_starttime`, `s_endtime`, `create_date`, `close`, `status`) VALUES ('".$client."','".$shift_type."','".$staff."','".$shiftdate."','".$starttime."','".$endtime."','".$current_date."','1','1')";
            $insert_shift_ex = mysqli_query($con,$insert_shift);
            if ($insert_shift_ex) {
                  $last_id = $con->insert_id;
                  $insert_shift_dates = "INSERT INTO `shift_dates`(`sd_s_id`, `sd_date`, `close`, `status`) VALUES ('".$last_id."','".$shiftdate."','1','1')";
                  $insert_shift_dates_ex = mysqli_query($con,$insert_shift_dates);
                  if ($insert_shift_dates_ex) {
                        header("Location: shifts");
                  }
            }
      }

}
?>
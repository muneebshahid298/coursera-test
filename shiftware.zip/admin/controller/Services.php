<?php 	
	if(isset($_POST['submitp'])){
 		$service_name = $_POST['service_name'];

	   	$add_services = "INSERT INTO `services` (`service_name`, `close`, `status`) VALUES ('".$service_name."','1','1')";
	   	$add_services_ex = mysqli_query($con,$add_services);

	   	if($add_services_ex){
	   		header('location: services');
	   	}
	   	else{
	   		print_r($add_services);
	   	}

	}
	if (isset($_POST['updatep'])) {
		$ser_id = $_POST['ser_id'];
		$service_name = $_POST['service_name_u'];
	   	$update_services = "UPDATE services SET service_name='".$service_name."' WHERE ser_id ='".$ser_id."'";
	   	$update_services_ex = mysqli_query($con,$update_services);
	   	if ($update_services_ex) {
	   		header('location: services');
	   	}
	   	else{
	   		echo "sorry";
	   	}
	}

 ?>
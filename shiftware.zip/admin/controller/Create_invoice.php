<?php
$select_client = "SELECT * FROM wt_users JOIN client ON wt_users.id=client.wt_user_id WHERE wt_users.close = '1' AND wt_users.status = '1' AND wt_users.user_type ='client'";
$select_client_ex = mysqli_query($con,$select_client);

$select_item = "SELECT * FROM item WHERE i_inactive = '0' AND close = '1' AND status = '1'";
$select_item_ex = mysqli_query($con,$select_item);

$select_account = "SELECT * FROM accounts WHERE close = '1' AND status = '1'";
$select_account_ex = mysqli_query($con,$select_account);

if (isset($_POST['submitinvoice'])) {
	$c_id = $_POST['customer'];
	$invoice_num = $_POST['invoice_num'];
	$cus_po = $_POST['cus_po'];
	$issue_date = $_POST['issue_date'];
	$due_date = $_POST['due_date'];
	$tax_status = $_POST['tax_status'];
	$customer_note = $_POST['customer_note'];

	$subtotal = $_POST['subtotal'];
	$totaltax = $_POST['totaltax'];
	$totalamount = $_POST['totalamount'];
	$amount_paid = $_POST['amount_paid'];
	$balancedue = $_POST['balancedue'];

	$itemarray = $_POST['item'];

	$insert_invoice = "INSERT INTO invoice (in_c_id,in_invoice_number,in_customer_po_number,in_issue_date,in_due_date,in_accounts_are,in_customer_note,in_subtotal,in_total_tax,in_total_amount,in_paid_amount,in_balance_due,close,status) VALUES ('".$c_id."','".$invoice_num."','".$cus_po."','".$issue_date."','".$due_date."','".$tax_status."','".$customer_note."','".$subtotal."','".$totaltax."','".$totalamount."','".$amount_paid."','".$balancedue."','1','1')";
	$insert_invoice_ex = mysqli_query($con,$insert_invoice);
	if ($insert_invoice_ex) {

		$last_id = $con->insert_id;
		for ($i=0; $i < count($itemarray); $i++) { 
			$item_id = $_POST['item'][$i];
			$account = $_POST['account'][$i];
			$number_unit = $_POST['number_unit'][$i];
			$discount = $_POST['discount'][$i];
			$amount = $_POST['amount'][$i];

			$insert_invoice_item = "INSERT INTO invoice_items (it_in_id,it_i_id,it_account,it_unit_nmbers,it_discount,it_amount,close,status) VALUES ('".$last_id."','".$item_id."','".$account."','".$number_unit."','".$discount."','".$amount."','1','1')";
			$insert_invoice_item_ex = mysqli_query($con,$insert_invoice_item);
		}
	}

}
?>
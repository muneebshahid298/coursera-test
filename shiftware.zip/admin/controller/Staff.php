<?php
$res_data = "SELECT * FROM wt_users JOIN staff_sector ON staff_sector.wt_user_id = wt_users.id JOIN sectors ON sectors.sec_id = staff_sector.sector_id WHERE wt_users.close = '1' AND wt_users.status = '1' AND wt_users.archieved = '0' AND wt_users.user_type ='staff'";
$res_data_ex = mysqli_query($con,$res_data);

$email = "SELECT * FROM company_info WHERE close = '1' AND status = '1'";
$email_ex = mysqli_query($con,$email);

foreach ($email_ex as $email) {
  $company_email = $email['com_email'];
}

if (isset($_POST['submitstaff'])) {

   $image = $_FILES['profile_img']['name'];
   $submit_image = $_FILES['profile_img']['tmp_name'];
   $img_path = "../assets/img/".$image;
   move_uploaded_file($submit_image,$img_path);

   $prefix = $_POST['prefix'];
   $fname = $_POST['fname'];
   $lname = $_POST['lname'];
   $phone = $_POST['phone'];
   $mobile = $_POST['mobile'];
   $countryCode = $_POST['countryCode'];
   $dob = $_POST['dob'];
   $email = $_POST['email'];
   $address = $_POST['address'];
   $sector = $_POST['sector'];
   $userloginnamee = $_POST['userloginnamee'];
   $password = $_POST['password'];
   $userpass = md5($_POST['password']);
   $mobile_final = $countryCode.$mobile;


   $insert_staff = "INSERT INTO `wt_users`(`prefix`, `profile_img`, `f_name`, `l_name`, `user_name`, `user_type`, `email`, `address`, `phone`, `mobile`, `dob`, `password`, `close`, `status`) VALUES ('".$prefix."','".$image."','".$fname."','".$lname."','".$userloginnamee."','staff','".$email."','".$address."','".$phone."','".$mobile_final."','".$dob."','".$userpass."','1','1')";
   $insert_staff_ex = mysqli_query($con,$insert_staff);
   if ($insert_staff_ex) {
    $last_id = $con->insert_id;
    $insert_staff_sector = "INSERT INTO `staff_sector`(`wt_user_id`,`sector_id`, `close`, `status`) VALUES ('".$last_id."','".$sector."','1','1')";
    $insert_staff_sector_ex = mysqli_query($con,$insert_staff_sector);
 }

 if($insert_staff_sector_ex){
   $sender = $company_email;
   $recipient = $email;
   $subject = "Login Information";
   $headers  = 'MIME-Version: 1.0' . "\r\n";
   $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
   $headers .= 'From: '.$sender."\r\n".
   'Reply-To: '.$sender."\r\n" .
   'X-Mailer: PHP/' . phpversion();
   echo $message = "<!DOCTYPE html>
   <head>
   <meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
   <title>Profin-kredit</title>
   <meta name='viewport' content='width=device-width, initial-scale=1.0'/>

   <style type='text/css'>
   a[x-apple-data-detectors] {color: inherit !important;}
   </style>

   </head>
   <body style='margin: 0; padding: 0;'>
   <table role='presentation' border='0' cellpadding='0' cellspacing='0' width='100%'>
   <tr>
   <td style='padding: 20px 0 30px 0;'>

   <table align='center' border='0' cellpadding='0' cellspacing='0' width='600' style='border-collapse: collapse; border: 1px solid #cccccc;'>
   <tr>
   <td align='center' style='padding: 40px 0 30px 0;'>
   <img src='' alt='Your Company Logo.' width='300' height='80' style='display: block;' />
   </td>
   </tr>
   <tr>
   <td bgcolor='#ffffff' style='padding: 40px 30px 40px 30px;'>
   <table border='0' cellpadding='0' cellspacing='0' width='100%' style='border-collapse: collapse;'>
   <tr>
   <td style='color: #153643; font-family: Arial, sans-serif;'>
   <h1 style='font-size: 24px; margin: 0;'>Thank You!</h1>
   </td>
   </tr>
   <tr>
   <td style='color: #153643; font-family: Arial, sans-serif; font-size: 16px; line-height: 24px; padding: 20px 0 30px 0;'>
   <p style='margin: 0;'>
   <b>Hello!</b><br>
   <h2>'".$fname." ".$lname."'</h2>
   <h5>Your Login Information is given below</h5>
   <h4>User Name: <span>".$userloginnamee."</span></h4>
   <h4>Password: <span>".$password."</span></h4>
   </p>
   </td>
   </tr>
   </table>
   </td>
   </tr>
   <tr>
   <td bgcolor='#000000' style='padding: 30px 30px;'>
   <table border='0' cellpadding='0' cellspacing='0' width='100%' style='border-collapse: collapse;'>
   <tr>
   <td style='color: #ffffff; font-family: Arial, sans-serif; font-size: 14px;'>
   <p style='margin: 0;'>Regards: <br/><br>
   <a href='#' style='color: #ffffff;'>Central Mountain Air</a><br><br> Email: <a href=\"mailto:info@centralmountainair\" style='color: white;'>info@centralmountainair</a><br><br>
   Phone: <a href=\"tel:+00 00 000 00 00\" style='color: white;'>+00 00 000 00 00</a>
   </p>
   </td>
   <td align='right'>
   <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse;'>
   <tr>
   <td>
   <a href='#'>
   <img src='https://cdn2.iconfinder.com/data/icons/social-media-2285/512/1_Facebook_colored_svg_copy-128.png' alt='Twitter.' width='38' height='38' style='display: block;' border='0' />
   </a>
   </td>
   <td style='font-size: 0; line-height: 0;' width='20'>&nbsp;</td>
   <td>
   <a href='#'>
   <img src='https://cdn2.iconfinder.com/data/icons/social-media-2285/512/1_Instagram_colored_svg_1-128.png' alt='Facebook.' width='38' height='38' style='display: block;' border='0' />
   </a>
   </td>
   </tr>
   </table>
   </td>
   </tr>
   </table>
   </td>
   </tr>
   </table>

   </td>
   </tr>
   </table>
   </body>
   </html>";
			//mail($recipient, $subject, $message, $headers);
   header("Location: staff");
}
else{
   echo "<div class='alert alert-danger' style = 'text-align : center;'><strong>Something</strong> Went Worng!!</div>";
}
}
if(isset($_POST['editstaff'])){

   $image = $_FILES['profile_img_u']['name'];
   $submit_image = $_FILES['profile_img_u']['tmp_name'];
   $img_path = "../assets/img/".$image;
   move_uploaded_file($submit_image,$img_path);


   $staffid = $_POST['staffid'];
   $prefix_u = $_POST['prefix_u'];
   $fname_u = $_POST['fname_u'];
   $lname_u = $_POST['lname_u'];
   $phone_u = $_POST['phone_u'];
   $mobile_u = $_POST['mobile_u'];
   $dob_u = $_POST['dob_u'];
   $email_u = $_POST['email_u'];
   $address_u = $_POST['address_u'];
   $sector = $_POST['sector'];

   $update_staff = "UPDATE `wt_users` SET `prefix`='".$prefix_u."',`profile_img`='".$image."',`f_name`='".$fname_u."',`l_name`='".$lname_u."',`email`='".$email_u."',`address`='".$address_u."',`phone`='".$phone_u."',`mobile`='".$mobile_u."',`dob`='".$dob_u."' WHERE id = '".$staffid."'";
   $update_staff_ex = mysqli_query($con,$update_staff);

   if($update_staff_ex){
      $update_staff_sector = "UPDATE `staff_sector` SET `sector_id`='".$sector."' WHERE wt_user_id = '".$staffid."'";
      $update_staff_sector_ex = mysqli_query($con,$update_staff_sector);
      if ($update_staff_sector_ex) {
       header("Location: staff");
    }
    
 }else{
   echo "<div class='alert alert-danger' style = 'text-align : center;'><strong>Something</strong> Went Worng!!</div>";
}
}


if (isset($_POST['substaffdoc'])) {
 $doc = $_FILES['stf_doc_document']['name'];
 $submit_doc = $_FILES['stf_doc_document']['tmp_name'];
 $img_path = "../assets/img/".$doc;
 move_uploaded_file($submit_doc,$img_path);
 $idstaff = $_POST['idstaff'];
 $insert_staff_doc = "INSERT INTO `staff_documents`(`staff_id`,`stf_doc_document`,`close`, `status`) VALUES ('".$idstaff."','".$doc."','1','1')";
 $insert_staff_doc_ex = mysqli_query($con,$insert_staff_doc);
}
?>
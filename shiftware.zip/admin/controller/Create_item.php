<?php

$select_account = "SELECT * FROM accounts WHERE (acc_type = 'income' || acc_type = 'other income') AND close = '1' AND status = '1'";
$select_account_ex = mysqli_query($con,$select_account);

$select_item = "SELECT * FROM item WHERE close = '1' AND status = '1'";
$select_item_ex = mysqli_query($con,$select_item);

if (isset($_POST['submititem'])) {
	$item_name = $_POST['itemname'];
	$item_desc = $_POST['itemdesc'];
	$use_desc = $_POST['usedesc'][0];
	$item_id = $_POST['itemid'];
	$inactive_item = $_POST['inactiveitem'][0];

	$sell_item = $_POST['sellitem'];
	$buy_item = $_POST['buyitem'];

	if ($sell_item == 1 && $buy_item == 0) {
		$selling_price = $_POST['selling_price'];
		$tax_status = $_POST['tax_status'];
		$measure_unit = $_POST['measure_unit'];
		$track_sale_account = $_POST['track_sale_account'];
		$tax_code = $_POST['tax_code'];

		$insert_item = "INSERT INTO item (i_name,i_description,i_use_on_sale_purchase,i_item_id,i_inactive,i_sell_item,i_selling_price,i_selling_tax_status,i_selling_measure_unit,i_track_sale_account,i_selling_tax_code,close,status) VALUES ('".$item_name."','".$item_desc."','".$use_desc."','".$item_id."','".$inactive_item."','".$sell_item."','".$selling_price."','".$tax_status."','".$measure_unit."','".$track_sale_account."','".$tax_code."','1','1')";
		$insert_item_ex = mysqli_query($con,$insert_item);
		if ($insert_item_ex) {
			header('Location: create-item');
		}

	}elseif ($sell_item == 0 && $buy_item == 1) {
		$buying_price = $_POST['buying_price'];
		$buying_tax_status = $_POST['buying_tax_status'];
		$buying_measure_unit = $_POST['buying_measure_unit'];
		$track_purchase_account = $_POST['track_purchase_account'];
		$buying_tax_code = $_POST['buying_tax_code'];
		$buying_sup_item_id = $_POST['buying_sup_item_id'];

		$insert_item = "INSERT INTO item (i_name,i_description,i_use_on_sale_purchase,i_item_id,i_inactive,i_buy_item,i_buying_price,i_buying_tax_status,i_buying_measure_unit,i_track_purchase_account,i_buying_tax_code,i_buying_sup_item_id,close,status) VALUES ('".$item_name."','".$item_desc."','".$use_desc."','".$item_id."','".$inactive_item."','".$buy_item."','".$buying_price."','".$buying_tax_status."','".$buying_measure_unit."','".$track_purchase_account."','".$buying_tax_code."','".$buying_sup_item_id."','1','1')";
		$insert_item_ex = mysqli_query($con,$insert_item);
		if ($insert_item_ex) {
			header('Location: create-item');
		}
	}
	else{
		echo "<div class='alert alert-danger text-center'>Please select Sell item Or Buy item.</div>";
	}

}

if (isset($_POST['submitstatus'])) {
	$i_id = $_POST['i_id'];
	$status = $_POST['item_status'];

	$update_status = "UPDATE item SET i_inactive = '".$status."' WHERE i_id = '".$i_id."'";
	$update_status_ex = mysqli_query($con,$update_status);

	if ($update_status_ex) {
		header('Location: create-item');
	}


}
?>
<?php
$res_data = "SELECT * FROM leave_management JOIN wt_users ON leave_management.emp_id = wt_users.id WHERE  leave_management.close = '1' AND leave_management.status = '1' ";
$res_data_ex = mysqli_query($con,$res_data);

$email = "SELECT * FROM company_info WHERE close = '1' AND status = '1'";
$email_ex = mysqli_query($con,$email);

foreach ($email_ex as $email) {
  $company_email = $email['com_email'];
}

if (isset($_POST['submitclient'])) {
      $emp_id = $_POST['emp_id'];
      $leavetype = $_POST['leavetype'];
      $half_day_leave_date = $_POST['half_day_leave_date'];
      $half_day_leave_time_from = $_POST['half_day_leave_time_from'];
      $half_day_leave_time_to = $_POST['half_day_leave_time_to'];
      $full_day_leave_date = $_POST['full_day_leave_date'];
      $multi_days_leave_date_from = $_POST['multi_days_leave_date_from'];
      $multi_days_leave_date_to = $_POST['multi_days_leave_date_to'];
      $leave_reason = $_POST['leave_reason'];
      $leave_create_date = date('Y-m-d');
      
      $insert_leave = "INSERT INTO `leave_management`(`emp_id`, `leavetype`, `half_day_leave_date`, `half_day_leave_time_from`, `half_day_leave_time_to`, `full_day_leave_date`, `multi_days_leave_date_from`, `multi_days_leave_date_to`, `leave_reason`, `leave_create_date`,`close`, `status`) VALUES ('".$emp_id."','".$leavetype."','".$half_day_leave_date."','".$half_day_leave_time_from."','".$half_day_leave_time_to."','".$full_day_leave_date."','".$multi_days_leave_date_from."','".$multi_days_leave_date_to."','".$leave_reason."','".$leave_create_date."','1','1')";
      $insert_leave_ex = mysqli_query($con,$insert_leave);
      if ($insert_leave_ex) {
            header("Location: leavemanagement");
      }
      else{
            echo "<div class='alert alert-danger' style = 'text-align : center;'><strong>Something</strong> Went Worng!!</div>";
      }

}









if(isset($_POST['editleave'])){

      $lv_id = $_POST['lv_id'];
      $leavetype = $_POST['leavetype_u'];
      $half_day_leave_date = $_POST['half_day_leave_date_u'];
      $half_day_leave_time_from = $_POST['half_day_leave_time_from_u'];
      $half_day_leave_time_to = $_POST['half_day_leave_time_to_u'];
      $full_day_leave_date = $_POST['full_day_leave_date_u'];
      $multi_days_leave_date_from = $_POST['multi_days_leave_date_from_u'];
      $multi_days_leave_date_to = $_POST['multi_days_leave_date_to_u'];
      $leave_reason = $_POST['leave_reason_u'];

      $update_leave = "UPDATE `leave_management` SET `leavetype`='".$leavetype."',`half_day_leave_date`='".$half_day_leave_date."',`half_day_leave_time_from`='".$half_day_leave_time_from."',`half_day_leave_time_to`='".$half_day_leave_time_to."',`full_day_leave_date`='".$full_day_leave_date."',`multi_days_leave_date_from`='".$multi_days_leave_date_from."',`multi_days_leave_date_to`='".$multi_days_leave_date_to."',`leave_reason`='".$leave_reason."' WHERE lv_id = '".$lv_id."'";
      $update_leave_ex = mysqli_query($con,$update_leave);

      if ($update_leave_ex) {
            header("Location: leavemanagement");
      }
      else{
            echo "<div class='alert alert-danger' style = 'text-align : center;'><strong>Something</strong> Went Worng!!</div>";
      }
}






if (isset($_POST['editshiftstaff'])) {
      $s_id = $_POST['shift_id'];
      $staff = 0;
      for ($i=0; $i < sizeof($_POST['staff']); $i++) { 
            $staff = $staff.",".$_POST['staff'][$i];
      }
      
      
      $update_shift_staff = "UPDATE `shifts` SET `s_staff`='".$staff."' WHERE s_id = '".$s_id."'";
      $update_shift_staff_ex = mysqli_query($con,$update_shift_staff);
}


?>
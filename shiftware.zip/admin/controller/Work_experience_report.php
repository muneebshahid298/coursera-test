<?php
	$res_data = "SELECT *,SUM(sd_hour),SUM(sd_milage),SUM(sd_expense) FROM shift_dates JOIN shifts ON shift_dates.sd_s_id=shifts.s_id JOIN wt_users ON shifts.s_staff=wt_users.id WHERE shift_dates.close = '1' AND shift_dates.status = '1' AND wt_users.user_type ='staff' GROUP BY shifts.s_staff";
	$res_data_ex = mysqli_query($con,$res_data);

	$current_month_num = date('m');
	$current_year = date('Y');
	echo $d=cal_days_in_month(CAL_GREGORIAN,$current_month_num,$current_year);
?>
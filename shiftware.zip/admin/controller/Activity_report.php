<?php
	$res_data = "SELECT *,SUM(sd_hour),SUM(sd_milage),SUM(sd_expense) FROM shifts JOIN shift_dates ON shifts.s_id=shift_dates.sd_s_id JOIN wt_users ON shifts.s_staff=wt_users.id WHERE shift_dates.close = '1' AND shift_dates.status = '1' AND wt_users.user_type ='staff' GROUP BY shifts.s_staff,shifts.s_recurrance";
	$res_data_ex = mysqli_query($con,$res_data);
?>
<?php
	$res_data = "SELECT * FROM wt_users JOIN staff_sector ON staff_sector.wt_user_id = wt_users.id JOIN sectors ON sectors.sec_id = staff_sector.sector_id WHERE wt_users.close = '1' AND wt_users.status = '1' AND wt_users.archieved = '1' AND wt_users.type ='staff'";
	$res_data_ex = mysqli_query($con,$res_data);

	if(isset($_POST['editstaff'])){

            $image = $_FILES['profile_img_u']['name'];
            $submit_image = $_FILES['profile_img_u']['tmp_name'];
            $img_path = "../assets/img/".$image;
            move_uploaded_file($submit_image,$img_path);

            
		$staffid = $_POST['staffid'];
            $prefix_u = $_POST['prefix_u'];
		$fname_u = $_POST['fname_u'];
		$lname_u = $_POST['lname_u'];
		$phone_u = $_POST['phone_u'];
		$mobile_u = $_POST['mobile_u'];
		$dob_u = $_POST['dob_u'];
		$email_u = $_POST['email_u'];
		$address_u = $_POST['address_u'];

		$update_staff = "UPDATE `wt_users` SET `profile_img`='".$image."',`prefix`='".$prefix_u."',`f_name`='".$fname_u."',`l_name`='".$lname_u."',`email`='".$email_u."',`address`='".$address_u."',`phone`='".$phone_u."',`mobile`='".$mobile_u."',`dob`='".$dob_u."' WHERE id = '".$staffid."'";
		
		$update_staff_ex = mysqli_query($con,$update_staff);

		if($update_staff_ex){
			header("Location: staffarchived");
		}else{
			echo "<div class='alert alert-danger' style = 'text-align : center;'><strong>Something</strong> Went Worng!!</div>";
		}
	}


        if (isset($_POST['substaffdoc'])) {
             $doc = $_FILES['stf_doc_document']['name'];
            $submit_doc = $_FILES['stf_doc_document']['tmp_name'];
            $img_path = "../assets/img/".$doc;
            move_uploaded_file($submit_doc,$img_path);
             $idstaff = $_POST['idstaff'];
            $insert_staff_doc = "INSERT INTO `staff_documents`(`staff_id`,`stf_doc_document`,`close`, `status`) VALUES ('".$idstaff."','".$doc."','1','1')";
            $insert_staff_doc_ex = mysqli_query($con,$insert_staff_doc);
      }
?>
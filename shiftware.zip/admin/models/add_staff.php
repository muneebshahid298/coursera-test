<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");

    // same_useremail_chk
if(isset($_POST['same_chk2'])){
    $user_email = $_POST['same_chk2'];
    $select_query = "SELECT * from wt_users WHERE status = '1' AND close='1' AND user_name = '".$user_email."'";
    $select_query_ex = mysqli_query($con , $select_query);
    if(mysqli_num_rows($select_query_ex) > 0){
        echo "<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>User Name</strong> Already Exists!!</div>";
    }else{
        echo true;
    }
}
    // same_empno_chk
if(isset($_POST['same_chk3'])){
    $user_empNo = $_POST['same_chk3'];
    $select_query = "SELECT * from wt_users WHERE status = '1' AND close='1' AND emp_no = '".$user_empNo."'";
    $select_query_ex = mysqli_query($con , $select_query);
    if(mysqli_num_rows($select_query_ex) > 0){
        echo "<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>Employee No</strong> Already Exists!!</div>";
    }else{
        echo true;
    }
}
    // same_email_chk
if(isset($_POST['same_chk4'])){
    $user_email = $_POST['same_chk4'];
    $select_query = "SELECT * from wt_users WHERE status = '1' AND close='1' AND email = '".$user_email."'";
    $select_query_ex = mysqli_query($con , $select_query);
    if(mysqli_num_rows($select_query_ex) > 0){
        echo "<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>Email</strong> Already Exists!!</div>";
    }else{
        echo true;
    }
}
if (isset($_POST['staff_edit'])) {
    $staff_id = $_POST['staff_edit'];
    $userEdit = "SELECT * FROM wt_users JOIN staff_sector ON staff_sector.wt_user_id = wt_users.id JOIN sectors ON sectors.sec_id = staff_sector.sector_id WHERE wt_users.close = '1' AND wt_users.status = '1' AND wt_users.id = '".$staff_id."'";
    $userEdit_ex = mysqli_query($con,$userEdit);
    foreach($userEdit_ex as $row){

      ?>
      <fieldset class="scheduler-border">
        <legend class="scheduler-border">
            Staff Details <span class="req-data">*</span>
        </legend>
        <div class="row">
            <div class="col-md-7">
                <div class="row">
                    <div class="form-group col-md-12">
                        <input type="hidden" name="staffid" value="<?php echo $staff_id; ?>">
                        <label for="prefix">Prefix</label>
                        <select class="form-control" name="prefix_u" id="prefix" autofocus autocomplete="off">
                            <option value disabled selected><?php echo $row['prefix']; ?></option>
                            <option value='Mr.'>Mr.</option>
                            <option value='Mrs.'>Mrs.</option>
                            <option value='Miss'>Miss</option>
                            <option value='Ms'>Ms</option>
                            <option value='Doctor'>Doctor</option>
                            <option value='They'>They</option>
                            <option value='Them'>Them</option>

                        </select>
                    </div>
                    <div class="form-group col-md-12">
                        <label for="fname_u">First Name</label>
                        <input type="text" id="fname_u" name="fname_u" value="<?php echo $row['f_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                    </div>
                    <div class="form-group col-md-12">
                        <label for="lname_u">Last Name</label>
                        <input type="text" id="lname_u" name="lname_u" value="<?php echo $row['l_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="form-group col-md-5">
                <label for="profile_img">Profile Image</label>
                <input id="profile_img" type="file" name="profile_img_u" class="dropify" data-default-file="../assets/img/<?php echo $row['profile_img']; ?>">
            </div>
            <script>
                $(document).ready(function(){
                    $('.dropify').dropify();
                });
            </script>
            <div class="form-group col-md-6">
                <label for="phone_u">Contact</label>
                <input type="number" id="phone_u" name="phone_u" value="<?php echo $row['phone'] ?>" class="form-control prevent" data-required="true" required="required" autofocus autocomplete="off">
            </div>
            <div class="form-group col-md-6">
                <label for="mobile_u">Mobile</label>
                <input type="number" id="mobile" name="mobile_u" value="<?php echo $row['mobile'] ?>" class="form-control prevent" data-required="true" required="required" autofocus autocomplete="off">
            </div>
            <div class="form-group col-md-6">
                <label for="dob_u">DOB</label>
                <input type="date" id="dob_u" name="dob_u" value="<?php echo $row['dob'] ?>" class="form-control" max="2023-01-01" autofocus autocomplete="off">
            </div>
            <div class="form-group col-md-6">
                <label for="useremail">Email</label>
                <input type="email" id="useremail" name="email_u" value="<?php echo $row['email'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onkeyup="useremailchk();">
            </div>
            <div class="form-group col-md-12" id="alert_msg4"> </div>
            <div class="form-group col-md-12">
                <label for="address_u">Address</label>
                <input type="text" id="address_u" name="address_u" value="<?php echo $row['address'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
            </div>
            <div class="form-group col-md-12">
                <label for="sector">Sector</label>
                <select class="form-control" name="sector" id="sector" data-required="true" required="required">
                    <optionvalue='<?php echo $row['sec_id'] ?>' selected><?php echo $row['sector_name'] ?></option>
                    <?php
                    foreach ($con->query('SELECT * FROM sectors WHERE close = "1" AND status = "1"') as $rowsector){
                        ?>
                        <option value = '<?php echo $rowsector['sec_id']; ?>'><?php echo ucwords($rowsector['sector_name']); ?></option>
                    <?php } ?>
                </select>
            </div>
        </div>
    </fieldset>
    <div class="modal-footer">
        <button type="submit" id="submitstaff" name="editstaff" class="btn btn-customs"><span class="btn-label"><i class="fa fa-spinner"></i></span> Update</button>
    </div>
    <?php   
}
}
if (isset($_POST['staff_view'])) {
    $user_id = $_POST['staff_view'];
    $userEdit = "SELECT * FROM wt_users JOIN staff_sector ON staff_sector.wt_user_id = wt_users.id JOIN sectors ON sectors.sec_id = staff_sector.sector_id WHERE wt_users.close = '1' AND wt_users.status = '1' AND wt_users.id = '".$user_id."'";
    $userEdit_ex = mysqli_query($con,$userEdit);
    foreach($userEdit_ex as $row){
      ?>
      <div class="modal-body">
        <fieldset class="scheduler-border">
            <legend class="scheduler-border">
                Staff Details <span class="req-data">*</span>
            </legend>
            <div class="row">
                <div class="col-md-7">
                    <div class="row">
                        <div class="form-group col-md-12">
                            <input type="hidden" name="staffid" value="<?php echo $staff_id; ?>">
                            <label for="prefix">Prefix</label>
                            <select class="form-control" name="prefix" id="prefix" disabled="">
                                <option value disabled selected><?php echo $row['prefix']; ?></option>
                            </select>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="fname_u">First Name</label>
                            <input type="text" id="fname_u" name="fname_u" readonly="" value="<?php echo $row['f_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="lname_u">Last Name</label>
                            <input type="text" id="lname_u" name="lname_u" readonly="" value="<?php echo $row['l_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                        </div>
                    </div>
                </div>
                <div class="form-group col-md-5">
                  <label for="profile_img">Profile Image</label>
                  <input disabled="" type="file" class="dropify" data-default-file="../assets/img/<?php echo $row['profile_img']; ?>">
              </div>
              <script>
                $(document).ready(function(){
                    $('.dropify').dropify();
                });
            </script>
            <div class="form-group col-md-6">
                <label for="phone_u">Contact</label>
                <input type="number" id="phone_u" name="phone_u" readonly="" value="<?php echo $row['phone'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
            </div>
            <div class="form-group col-md-6">
                <label for="mobile_u">Mobile</label>
                <input type="text" id="mobile" name="mobile_u" readonly="" value="<?php echo "+".$row['mobile'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
            </div>
            <div class="form-group col-md-6">
                <label for="dob_u">DOB</label>
                <input type="date" id="dob_u" name="dob_u" readonly="" value="<?php echo $row['dob'] ?>" class="form-control" autofocus autocomplete="off">
            </div>
            <div class="form-group col-md-6">
                <label for="useremail">Email</label>
                <input type="email" id="useremail" name="email_u" readonly="" value="<?php echo $row['email'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onkeyup="useremailchk();">
            </div>
            <div class="form-group col-md-12">
                <label for="address_u">Address</label>
                <input type="text" id="address_u" name="address_u" readonly="" value="<?php echo $row['address'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
            </div>

            <div class="form-group col-md-12">
                <label for="staff_sector">Sector</label>
                <input type="text" id="staff_sector" name="staff_sector" readonly="" value="<?php echo $row['sector_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
            </div>
        </div>
    </div>

    <?php   
}
}
if (isset($_POST['staff_del'])) {
    $staff_del = $_POST['staff_del'];
    $close = 0;
    $staffDel = "UPDATE wt_users SET close = '".$close."' WHERE id = '".$staff_del."'";
    $staffDel_ex = mysqli_query($con,$staffDel);
}

if (isset($_POST['uploadstaffdoc'])) {
    $uploadstaffdoc = $_POST['uploadstaffdoc'];
    ?>
    <div class="row">
        <div class="form-group col-md-12">
            <input type="hidden" name="idstaff" value="<?php echo $uploadstaffdoc; ?>">
            <label for="cl_doc_document">First Name</label>
            <input type="file" id="stf_doc_document" readonly="" name="stf_doc_document" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" id="submitstaffdoc" name="substaffdoc" class="btn btn-customs"><span class="btn-label"><i class="fa fa-spinner"></i></span> Upload</button>
    </div>
    <?php
}

if (isset($_POST['staff_doc_del'])) {
    $staff_doc_del = $_POST['staff_doc_del'];
    $close = 0;
    $staffDocDel = "UPDATE staff_documents SET close = '".$close."' WHERE staff_dco_id  = '".$staff_doc_del."'";
    $staffDocDel_ex = mysqli_query($con,$staffDocDel);
}


if (isset($_POST['document_download'])){
    $doc_id = $_POST['document_download'];
    $client = "SELECT * FROM staff_documents WHERE close = '1' AND status = '1' AND staff_dco_id = '".$doc_id."' ";
    $photo_view_mem = mysqli_query($con,$client);
    foreach($photo_view_mem as $row2){
        $clientdoc =  $row2['stf_doc_document'];
        echo $clientdoc;
    }
}



if (isset($_POST['staff_archive'])) {
    $staff_archive = $_POST['staff_archive'];
    $archive_status = $_POST['archive_status'];
    $clientArchive = "UPDATE wt_users SET archieved = '".$archive_status."' WHERE id = '".$staff_archive."'";
    $clientArchive_ex = mysqli_query($con,$clientArchive);
}







if (isset($_POST['view_staff_shift_data'])) {
    $view_staff_shift_data = $_POST['view_staff_shift_data'];
    $select_shifts = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id JOIN client ON shifts.s_client = client.c_id JOIN wt_users ON CONCAT(',', shifts.s_staff, ',') LIKE CONCAT('%,', wt_users.id, ',%') WHERE wt_users.id = '".$view_staff_shift_data."' AND shifts.close = '1' AND shifts.status = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'";
    $select_shifts_ex = mysqli_query($con, $select_shifts);
    ?>
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr style="border-bottom: 1px solid #000;">
                <th>S/No</th>
                <th>Shift Date</th>
                <th>Shift Time From</th>
                <th>Shift Time To</th>
                <th>Client</th>
                <th>Address</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sr = 1;
            foreach ($select_shifts_ex as $row) {
                $sd_status = $row['sd_complete'];
                ?>
                <tr id="<?php echo $row['s_id']; ?>">
                    <?php 
                    echo "<td>".$sr."</td><td>".$row['s_shiftdate']."</td><td>".date("g:i A", strtotime($row['s_starttime']))."</td><td>".date("g:i A", strtotime($row['s_endtime']))."</td><td>".ucwords($row['m_name'])."</td><td>".$row['s_address']."</td>";
                    if ($sd_status == '0') {
                        $status = 'Pending';
                        echo "<td style= 'color:red; font-weight: bold;'>".$status."</td>";
                    }
                    elseif ($sd_status == '1') {
                        $status = 'Accepted';
                        echo "<td style= 'color:blue; font-weight: bold;'>".$status."</td>";
                    }
                    elseif ($sd_status == '2') {
                        $status = 'Completed';
                        echo "<td style= 'color:green; font-weight: bold;'>".$status."</td>";
                    }
                    ?>
                </tr>
                <?php 
                $sr++;
            }
            ?>
        </tbody>
        <tfoot>
            <tr style="border-top: 1px solid #000;">
                <th>S/No</th>
                <th>Shift Date</th>
                <th>Shift Time From</th>
                <th>Shift Time To</th>
                <th>Client</th>
                <th>Address</th>
                <th>Status</th>
            </tr>
        </tfoot>
    </table>
    <?php
}



?>
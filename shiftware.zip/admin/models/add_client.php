<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");

    // same_empno_chk
if(isset($_POST['same_chk3'])){
    $user_empNo = $_POST['same_chk3'];
    $select_query = "SELECT * from wt_users WHERE status = '1' AND close='1' AND emp_no = '".$user_empNo."'";
    $select_query_ex = mysqli_query($con , $select_query);
    if(mysqli_num_rows($select_query_ex) > 0){
        echo "<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>Employee No</strong> Already Exists!!</div>";
    }else{
        echo true;
    }
}
    // same_email_chk
if(isset($_POST['same_chk4'])){
    $user_email = $_POST['same_chk4'];
    $select_query = "SELECT * from wt_users WHERE status = '1' AND close='1' AND email = '".$user_email."'";
    $select_query_ex = mysqli_query($con , $select_query);
    if(mysqli_num_rows($select_query_ex) > 0){
        echo "<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>Email</strong> Already Exists!!</div>";
    }else{
        echo true;
    }
}
if (isset($_POST['client_edit'])) {
    $clientid = $_POST['client_edit'];
    $userEdit = "SELECT * FROM wt_users JOIN client ON wt_users.id=client.wt_user_id WHERE wt_users.id = '".$clientid."' AND wt_users.close = '1' AND wt_users.status = '1'";
    $userEdit_ex = mysqli_query($con,$userEdit);
    foreach($userEdit_ex as $row){
      ?>
        <fieldset class="scheduler-border">
            <legend class="scheduler-border">
                Client Details <span class="req-data">*</span>
            </legend>
            <div class="row">
                <div class="col-md-7">
                    <div class="row">
                        <div class="form-group col-md-12">
                            <input type="hidden" name="clientid" value="<?php echo $clientid; ?>">
                            <label for="prefix">Prefix</label>
                            <select class="form-control" name="prefix_u" id="prefix" autofocus autocomplete="off">
                                <option value disabled selected><?php echo $row['prefix']; ?></option>
                                <option value='Mr.'>Mr.</option>
                                <option value='Mrs.'>Mrs.</option>
                                <option value='Miss'>Miss</option>
                                <option value='Ms'>Ms</option>
                                <option value='Doctor'>Doctor</option>
                                <option value='They'>They</option>
                                <option value='Them'>Them</option>

                            </select>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="fname_u">First Name</label>
                            <input type="text" id="fname_u" name="fname_u" value="<?php echo $row['f_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="mname">Middle Name</label>
                            <input type="text" id="mname" name="mname_u" value="<?php echo $row['m_name'] ?>" class="form-control" autofocus autocomplete="off">
                        </div>
                    </div>
                </div>
                <div class="form-group col-md-5">
                    <label for="profile_img">Profile Image</label>
                    <input id="profile_img" type="file" name="profile_img_u" class="dropify" data-default-file="../assets/img/<?php echo $row['profile_img']; ?>">
                </div>
                <script>
                    $(document).ready(function(){
                        $('.dropify').dropify();
                    });
                </script>
                
                <div class="form-group col-md-6">
                    <label for="lname_u">Family Name</label>
                    <input type="text" id="lname_u" name="lname_u" value="<?php echo $row['l_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                </div>
                <div class="form-group col-md-6">
                    <label for="phone_u">Contact</label>
                    <input type="number" id="phone_u" name="phone_u" value="<?php echo $row['phone'] ?>" class="form-control prevent" data-required="true" required="required" autofocus autocomplete="off">
                </div>
                <div class="form-group col-md-6">
                    <label for="mobile_u">Mobile</label>
                    <input type="number" id="mobile" name="mobile_u" value="<?php echo $row['mobile'] ?>" class="form-control prevent" data-required="true" required="required" autofocus autocomplete="off">
                </div>
                <div class="form-group col-md-6">
                    <label for="dob_u">DOB</label>
                    <input type="date" id="dob_u" name="dob_u" value="<?php echo $row['dob'] ?>" class="form-control" autofocus autocomplete="off">
                </div>
                <div class="form-group col-md-12">
                    <label for="useremail">Email</label>
                    <input type="email" id="useremail" name="email_u" value="<?php echo $row['email'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onkeyup="useremailchk();">
                </div>
                <div class="form-group col-md-12" id="alert_msg4">
                </div>
                <div class="form-group col-md-12">
                    <label for="address_u">Address</label>
                    <input type="text" id="address_u" name="address_u" value="<?php echo $row['address'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                </div>
                <div class="form-group col-md-12">
                    <label for="aprt_num">Unit/Appartment Number</label>
                    <input type="text" id="aprt_num" name="aprt_num_u" value="<?php echo $row['apprt_num'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                </div>
                <div class="form-group col-md-6"></div>
                <div class="form-group col-md-12">
                    <label for="religion">Religion</label>
                    <input type="text" id="religion" name="religion_u" value="<?php echo $row['religion'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                </div>
                <div class="form-group col-md-6">
                    <label for="nationality">Nationality</label>
                    <input type="text" id="nationality" name="nationality_u" value="<?php echo $row['nationality'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                </div>
                <div class="form-group col-md-6">
                    <label for="language">Language Spoken</label>
                    <input type="text" id="language" name="language_u" value="<?php echo $row['language'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                </div>
            </div>
        </fieldset>
        <div class="modal-footer">
            <button type="submit" id="submitclient" name="editclient" class="btn btn-customs"><span class="btn-label"><i class="fa fa-spinner"></i></span> Update</button>
        </div>
<?php   
}
}
if (isset($_POST['client_view'])) {
    $clientid = $_POST['client_view'];
    $userEdit = "SELECT * FROM wt_users JOIN client ON wt_users.id=client.wt_user_id WHERE wt_users.id = '".$clientid."' AND wt_users.close = '1' AND wt_users.status = '1'";
    $userEdit_ex = mysqli_query($con,$userEdit);
    foreach($userEdit_ex as $row){
      ?>
      <div class="modal-body">
        <fieldset class="scheduler-border">
            <legend class="scheduler-border">
                Client Details <span class="req-data">*</span>
            </legend>
          <div class="row">
            <div class="col-md-7">
                <div class="row">
                    <div class="form-group col-md-12">
                        <label for="prefix">Prefix</label>
                        <select class="form-control" readonly="" name="prefix_u" id="prefix" autofocus autocomplete="off">
                            <option value disabled selected><?php echo $row['prefix']; ?></option>
                        </select>
                    </div>
                    <div class="form-group col-md-12">
                        <label for="fname_u">First Name</label>
                        <input type="text" id="fname_u" readonly="" name="fname_u" value="<?php echo $row['f_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                    </div>
                    <div class="form-group col-md-12">
                        <label for="mname">Middle Name</label>
                        <input type="text" id="mname" readonly="" name="mname" value="<?php echo $row['m_name'] ?>" class="form-control" autofocus autocomplete="off">
                    </div>
                </div>
            </div>
           <div class="form-group col-md-5">
              <label for="profile_img">Profile Image</label>
              <input disabled="" type="file" class="dropify" data-default-file="../assets/img/<?php echo $row['profile_img']; ?>">
          </div>
          <script>
            $(document).ready(function(){
                $('.dropify').dropify();
            });
        </script>
        
        <div class="form-group col-md-6">
            <label for="lname_u">Family Name</label>
            <input type="text" id="lname_u" readonly="" name="lname_u" value="<?php echo $row['l_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6">
            <label for="phone_u">Contact</label>
            <input type="number" id="phone_u" readonly="" name="phone_u" value="<?php echo $row['phone'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6">
            <label for="mobile_u">Mobile</label>
            <input type="text" id="mobile" readonly="" name="mobile_u" value="<?php echo '+'.$row['mobile'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6">
            <label for="dob_u">DOB</label>
            <input type="date" id="dob_u" readonly="" name="dob_u" value="<?php echo $row['dob'] ?>" class="form-control" max="2023-01-01" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-12">
            <label for="useremail">Email</label>
            <input type="email" id="useremail" readonly="" name="email_u" value="<?php echo $row['email'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onkeyup="useremailchk();">
        </div>

        <div class="form-group col-md-12">
            <label for="address_u">Address</label>
            <input type="text" id="address_u" readonly="" name="address_u" value="<?php echo $row['address'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-12">
            <label for="aprt_num">Unit/Appartment Number</label>
            <input type="text" id="aprt_num" readonly="" name="aprt_num" value="<?php echo $row['apprt_num'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6"></div>
        <div class="form-group col-md-12">
            <label for="religion">Religion</label>
            <input type="text" id="religion" readonly="" name="religion" value="<?php echo $row['religion'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6">
            <label for="nationality">Nationality</label>
            <input type="text" id="nationality" readonly="" name="nationality" value="<?php echo $row['nationality'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6">
            <label for="language">Language Spoken</label>
            <input type="text" id="language" readonly="" name="language" value="<?php echo $row['language'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
    </div>
</div>
</fieldset>


<?php   
}
}
if (isset($_POST['client_del'])) {
    $client_del = $_POST['client_del'];
    $close = 0;
    $clientDel = "UPDATE wt_users SET close = '".$close."' WHERE id = '".$client_del."'";
    $clientDel_ex = mysqli_query($con,$clientDel);
    if ($clientDel_ex) {
        $clientDel1 = "UPDATE client SET close = '".$close."' WHERE wt_user_id = '".$client_del."'";
        $clientDel1_ex = mysqli_query($con,$clientDel1);
    }
}

if (isset($_POST['client_archive'])) {
    $client_archive = $_POST['client_archive'];
    $archive_status = $_POST['archive_status'];
    $clientArchive = "UPDATE client SET c_archived = '".$archive_status."' WHERE wt_user_id = '".$client_archive."'";
    $clientArchive_ex = mysqli_query($con,$clientArchive);
}



if (isset($_POST['uploadclientdoc'])) {
    $uploadclientdoc = $_POST['uploadclientdoc'];
    ?>
    <div class="row">
        <div class="form-group col-md-12">
            <input type="hidden" name="idclient" value="<?php echo $uploadclientdoc; ?>">
            <label for="cl_doc_document">First Name</label>
            <input type="file" id="cl_doc_document" readonly="" name="cl_doc_document" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" id="submitclientdoc" name="subclientdoc" class="btn btn-success"><span class="btn-label"><i class="fa fa-spinner"></i></span> Upload</button>
    </div>
    <?php
}
?>
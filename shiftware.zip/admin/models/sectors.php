<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");

//////////////////////sector_name_chk////////////////////////////
if (isset($_POST['sector_name_chk'])) {
  $sector_name = $_POST['sector_name_chk'];
  $select_query = "SELECT * from sectors WHERE status = '1' AND close='1'";
  $select_query_ex = mysqli_query($con,$select_query);
  if($select_query_ex){
    foreach ($select_query_ex as $row){
      if ($row['sector_name'] == $sector_name) {
        echo "yes";
    }
}
}
else{
    echo "error";
}
}


////////////////////sector_del//////////////////////////////////
if (isset($_POST['sector_del'])) {
  $sec_id = $_POST['sector_del'];
  $close = 0;
  $del_query = "UPDATE sectors SET close = '".$close."' WHERE sec_id = '".$sec_id."'";
  $del_query_ex = mysqli_query($con,$del_query);
}


// sector_edit

if (isset($_POST['sector_edit'])) {
  $sec_id = $_POST['sector_edit'];
  $get_data = "SELECT * FROM `sectors` WHERE `sec_id`='".$sec_id."' AND status = '1' AND close = '1'";
  $get_data_ex =  mysqli_query($con,$get_data);
  ?>
  <form action="" method="post" enctype="multipart/form-data">
    <fieldset class="scheduler-border">
                                        <legend class="scheduler-border">
                                            Sector <span class="req-data">*</span>
                                        </legend>
    <div class="row">
      <?php
      foreach ($get_data_ex as $row) {
        ?>
        <div class="form-group col-md-12">
          <input value="<?php echo $sec_id?>" type="hidden" name="sec_id">
          <label>Sector <span class="req-data text-danger">*</span></label>
          <input value="<?php echo $row['sector_name']?>" type="text" class="form-control prevent" name="sector_name_u" id="sector_name_u" data-required="true" placeholder="" required="required" autocomplete="off" onkeyup="sector_name_checking_u();">
      </div>
      <div id="already-msg-u" class="form-group col-md-12"></div>
    </div>
  </fieldset>
    <div class="modal-footer">
                              <button type="submit" id="updatep" name="updatep" class="btn btn-customs"><span class="btn-label"><i class="fa fa-spinner"></i></span> Update</button>
                          </div>


      <?php 
  }
  ?>

</form>
<?php   
}
?>
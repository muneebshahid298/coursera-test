<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");

$select_client = "SELECT * FROM client WHERE close = '1' AND status = '1'";
$select_client_ex = mysqli_query($con,$select_client);

$select_staff = "SELECT * FROM wt_users WHERE user_type = 'staff' AND close = '1' AND status = '1'";
$select_staff_ex = mysqli_query($con,$select_staff);

if (isset($_POST['shift_edit'])) {
  $shiftid = $_POST['shift_edit'];
  $select_shift = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id=shift_dates.sd_s_id JOIN client ON shifts.s_client = client.c_id WHERE shift_dates.sd_id = '".$shiftid."'";
  $select_shift_ex = mysqli_query($con,$select_shift);
  foreach($select_shift_ex as $row){
    ?>
    <div class="row p-4">
      <div class="form-group col-md-6">
        <label for="fname">Chose Client</label>
        <input type="hidden" name="sd_id" value="<?php echo $row['sd_id'] ?>">
        <input type="hidden" name="s_id" value="<?php echo $row['s_id'] ?>">
        <select class="form-control" name="client" id="client" data-required="true" required="required" autofocus autocomplete="off">
          <option value="<?php echo $row['c_id'] ?>"><?php echo ucwords($row['m_name']) ?></option>
          <?php
          foreach ($select_client_ex as $select_client_ex1) {
            ?>
            <option value="<?php echo $select_client_ex1['c_id'] ?>"><?php echo ucwords($select_client_ex1['m_name']) ?></option>
            <?php
          }
          ?>

        </select>
      </div>
      <div class="form-group col-md-6">
        <label for="fname">Chose Staff</label>
        <select class="form-control" name="staff[]" id="selectstaff_up" data-required="true" required="required" autofocus autocomplete="off">
          <option class="text-center" value disabled selected>-----Select Staff-----</option>
          <?php
          foreach ($select_staff_ex as $select_staff_ex1) {
            ?>
            <option value="<?php echo $select_staff_ex1['id'] ?>"><?php echo ucwords($select_staff_ex1['f_name']." ".$select_staff_ex1['l_name']) ?></option>
            <?php
          }
          ?>

        </select>
      </div>
     <!--  <div class="form-group col-md-12">
        <div class="row">
          <div class="form-group col-md-8"></div>
          <div class="col-md-3 pr-0 float-right">Open Shift</div>
          <div class="col-md-1 pl-0 float-left" style="height: 20px;"><input type="checkbox" id="open_shift_up" name="open_shift" value="0" class="form-control" onchange="checkopenshift_up(this.value);"></div>
        </div>
      </div> -->
      <div class="form-group col-md-6">
        <label for="fname">Shift Type</label>
        <select class="form-control" name="shift_type" id="shift_type" data-required="true" required="required" autofocus autocomplete="off">
          <option value="<?php echo $row['s_shift_type'] ?>"><?php echo ucwords($row['s_shift_type']) ?></option>
          <option value="personal cares">Personal Cares</option>
          <option value="client expense">Client Expense</option>
          <option value="domestic assistance">Domestic Assistance</option>
          <option value="night shift">Night Shift</option>
          <option value="brazil">Brazil</option>
          <option value="respite care">Respite Care</option>
          <option value="sleepover">Sleepover</option>
          <option value="support coordination">Support Coordination</option>
          <option value="transport">Transport</option>

        </select>
      </div>
      <div class="form-group col-md-6">
        <label for="fname">Shift Date</label>
        <input class="form-control" type="date" name="shiftdate" value="<?php echo $row['sd_date'] ?>">
      </div>
      <div class="form-group col-md-6">
        <label>Start Time</label>
        <input type="time" id="starttime" name="starttime" value="<?php echo $row['s_starttime'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
      </div>
      <div class="form-group col-md-6">
        <label>End Time</label>
        <input type="time" id="endtime" name="endtime" value="<?php echo $row['s_endtime'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
      </div>
    </div>
    <?php
  }
  ?>
  <div class="modal-footer">
    <button type="submit" id="submitclient" name="editshift" class="btn btn-success"><span class="btn-label"><i class="fa fa-spinner"></i></span> Update</button>
  </div>

  <?php   
}

if (isset($_POST['shift_add'])) {
  $shiftdate = $_POST['shift_add'];
  $select_shift = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id=shift_dates.sd_s_id JOIN client ON shifts.s_client = client.c_id JOIN wt_users ON shifts.s_staff = wt_users.id WHERE shift_dates.sd_id = '".$shiftid."'";
  $select_shift_ex = mysqli_query($con,$select_shift);
  foreach($select_shift_ex as $row){
    ?>
    <div class="row p-4">
      <div class="form-group col-md-6">
        <label for="fname">Chose Client</label>
        <input type="hidden" name="sd_id" value="<?php echo $row['sd_id'] ?>">
        <input type="hidden" name="s_id" value="<?php echo $row['s_id'] ?>">
        <select class="form-control" name="client" id="client" data-required="true" required="required" autofocus autocomplete="off">
          <option value="<?php echo $row['c_id'] ?>"><?php echo ucwords($row['m_name']) ?></option>
          <?php
          foreach ($select_client_ex as $select_client_ex1) {
            ?>
            <option value="<?php echo $select_client_ex1['c_id'] ?>"><?php echo ucwords($select_client_ex1['m_name']) ?></option>
            <?php
          }
          ?>

        </select>
      </div>
      <div class="form-group col-md-6">
        <label for="fname">Chose Staff</label>
        <select class="form-control" name="staff" id="staff" data-required="true" required="required" autofocus autocomplete="off">
          <option value="<?php echo $row['id'] ?>"><?php echo ucwords($row['f_name']." ".$row['l_name']) ?></option>
          <?php
          foreach ($select_staff_ex as $select_staff_ex1) {
            ?>
            <option value="<?php echo $select_staff_ex1['id'] ?>"><?php echo ucwords($select_staff_ex1['f_name']." ".$select_staff_ex1['l_name']) ?></option>
            <?php
          }
          ?>

        </select>
      </div>
      <div class="form-group col-md-6">
        <label for="fname">Shift Type</label>
        <select class="form-control" name="shift_type" id="shift_type" data-required="true" required="required" autofocus autocomplete="off">
          <option value="<?php echo $row['s_shift_type'] ?>"><?php echo ucwords($row['s_shift_type']) ?></option>
          <option value="personal cares">Personal Cares</option>
          <option value="client expense">Client Expense</option>
          <option value="domestic assistance">Domestic Assistance</option>
          <option value="night shift">Night Shift</option>
          <option value="brazil">Brazil</option>
          <option value="respite care">Respite Care</option>
          <option value="sleepover">Sleepover</option>
          <option value="support coordination">Support Coordination</option>
          <option value="transport">Transport</option>

        </select>
      </div>
      <div class="form-group col-md-6">
        <label for="fname">Shift Date</label>
        <input class="form-control" type="date" name="shiftdate" value="<?php echo $row['sd_date'] ?>">
      </div>
      <div class="form-group col-md-6">
        <label>Start Time</label>
        <input type="time" id="starttime" name="starttime" value="<?php echo $row['s_starttime'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
      </div>
      <div class="form-group col-md-6">
        <label>End Time</label>
        <input type="time" id="endtime" name="endtime" value="<?php echo $row['s_endtime'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
      </div>
    </div>
    <?php
  }
  ?>
  <div class="modal-footer">
    <button type="submit" id="submitclient" name="editshift" class="btn btn-success"><span class="btn-label"><i class="fa fa-spinner"></i></span> Update</button>
  </div>

  <?php   
}


if (isset($_POST['shift_del'])) {
  $shift_del = $_POST['shift_del'];
  $close = 0;
  $shiftDel = "UPDATE shift_dates SET close = '".$close."' WHERE sd_id = '".$shift_del."'";
  $shiftDel_ex = mysqli_query($con,$shiftDel);
}

if (isset($_POST['show_shifts'])) {
  $shift_time1c = date('Y-m-d',strtotime($_POST['show_shifts']));
    // $staff_id = $_POST['staff_id'];

  $select_shifts = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id JOIN client ON shifts.s_client = client.c_id JOIN wt_users ON CONCAT(',', shifts.s_staff, ',') LIKE CONCAT('%,', wt_users.id, ',%') WHERE wt_users.user_type = 'staff' AND shift_dates.sd_date = '".$shift_time1c."' AND shifts.close = '1' AND shifts.status = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'";
  $select_shifts_ex = mysqli_query($con,$select_shifts);

  foreach ($select_shifts_ex as $row) {
    $shift_id = $row['s_id'];
    ?>
    <div class="col-md-12 mb-3">
      <div class="py-2" style="border: 1px solid #ced4da; border-radius: 0.25rem; height: auto;">
        <input type="hidden" name="sr_id" value="<?php echo $sd_id ?>">
        <input type="hidden" name="shift_time" value="<?php echo $shift_time1c ?>">
        <div class="col-md-12 mb-4">
          <div class="col-md-6 float-left"><strong>Date: </strong><?php echo date('d-M-Y',strtotime($shift_time1c)) ?></div>
          <div class="col-md-6 float-left"><strong>Type: </strong><span><?php echo ucwords($row['s_shift_type']) ?></span></div>
        </div>
        <div class="col-md-12 mb-4">
          <div class="col-md-6 float-left"><strong>Client: </strong><span class="text-info"><?php echo ucwords($row['m_name']) ?></span></div>
        </div>
        <div class="col-md-12 mb-4">
          <div class="col-md-6 float-left"><strong>Original Shift Staff: </strong><span class="text-info">
           <?php 
           $select_shifts_org_staff = "SELECT * FROM shift_orgnal_staff JOIN wt_users ON CONCAT(',', shift_orgnal_staff.staff_id, ',') LIKE CONCAT('%,', wt_users.id, ',%') WHERE shift_orgnal_staff.shift_id = '".$shift_id."'";
           $select_shifts_org_staff_ex = mysqli_query($con, $select_shifts_org_staff);

           foreach ($select_shifts_org_staff_ex as $roworignal) {
            echo ucwords($roworignal['f_name']." ".$roworignal['l_name']);
          }
          ?>


        </span></div>
        <div class="col-md-6 float-left"><strong>Current Shift Staff: </strong><span class="text-info"><?php echo ucwords($row['f_name']." ".$row['l_name']) ?></span></div>
      </div>
      <div class="col-md-12 mb-4"></div>
      <div class="col-md-12 mb-4">
        <div class="col-md-6 float-left"><strong>From: </strong><span class="text-success"><?php echo date('h:i A',strtotime($row['s_starttime'])) ?></span></div>
        <div class="col-md-6 float-left"><strong>To: </strong><span class="text-danger"><?php echo date('h:i A',strtotime($row['s_endtime'])) ?></span></div>
      </div>
      <div class="col-md-12 mb-4">
        <div class="col-md-12 float-left"><strong>Address: </strong><span><?php echo $row['address'] ?></span></div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6">
        <button class="form-control text-white btn btn-success" onclick="edit_shift(<?php echo $row['sd_id'] ?>)"><i class="fa fa-edit fa-lg"></i></button>
      </div>
      <div class="col-md-6">
        <button class="form-control text-white btn btn-danger" onclick="del(delS,<?php echo $row['sd_id'] ?>)"><i class="fa fa-trash fa-lg"></i></button>
      </div>
    </div>
  </div>
  <?php
}
?>
<div class="row mt-3">
  <div class="col-md-12">
    <button type="button" data-toggle="modal" data-target="#exampleModal" class="form-control btn-info" onclick="add_shift();"><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Add Shift</button>
  </div>
</div>
<?php

}

if (isset($_POST['show_shift2'])) {
  $sd_id = $_POST['show_shift2'];
  $shift_time = date('Y-m-d',strtotime($_POST['start_date']));
    // $resource = $_POST['resource'];

  $select_shifts = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id JOIN client ON shifts.s_client = client.c_id JOIN wt_users ON CONCAT(',', shifts.s_staff, ',') LIKE CONCAT('%,', wt_users.id, ',%') WHERE wt_users.user_type = 'staff' AND shift_dates.sd_id = '".$sd_id."' AND shifts.close = '1' AND shifts.status = '1'";
  $select_shifts_ex = mysqli_query($con,$select_shifts);

  foreach ($select_shifts_ex as $row) {
    $shift_id = $row['s_id'];
    $s_shiftdate = $row['s_shiftdate'];
    ?>
    <di v class="col-md-12 mb-3">
      <div class="py-4" style="border: 1px solid #ced4da; border-radius: 0.25rem; height: auto;">
        <input type="hidden" name="sr_id" value="<?php echo $sd_id ?>">
        <input type="hidden" name="shift_time" value="<?php echo $shift_time ?>">
        <div class="col-md-12 mb-4">
          <div class="col-md-6 float-left"><strong>Date: </strong><?php echo date('d-M-Y',strtotime($shift_time)) ?></div>
          <div class="col-md-6 float-left"><strong>Type: </strong><span><?php echo ucwords($row['s_shift_type']) ?></span></div>
        </div>
        <div class="col-md-12 mb-4">
          <div class="col-md-6 float-left"><strong>Client: </strong><span class="text-info"><?php echo ucwords($row['m_name']) ?></span></div>
        </div>
        <div class="col-md-12 mb-4">
          <div class="col-md-6 float-left"><strong>Original Shift Staff: </strong><span class="text-info">
           <?php 
           $select_shifts_org_staff = "SELECT * FROM shift_orgnal_staff JOIN wt_users ON CONCAT(',', shift_orgnal_staff.staff_id, ',') LIKE CONCAT('%,', wt_users.id, ',%') WHERE shift_orgnal_staff.shift_id = '".$shift_id."'";
           $select_shifts_org_staff_ex = mysqli_query($con, $select_shifts_org_staff);

           foreach ($select_shifts_org_staff_ex as $roworignal) {
            echo ucwords($roworignal['f_name']." ".$roworignal['l_name']);
          }
          ?>


        </span></div>
        <div class="col-md-6 float-left"><strong>Current Shift Staff: </strong><span class="text-info"><?php echo ucwords($row['f_name']." ".$row['l_name']) ?></span></div>
      </div>
      <div class="col-md-12 mb-4"></div>
      <div class="col-md-12 mb-4">
        <div class="col-md-6 float-left"><strong>From: </strong><span class="text-success"><?php echo date('h:i A',strtotime($row['s_starttime'])) ?></span></div>
        <div class="col-md-6 float-left"><strong>To: </strong><span class="text-danger"><?php echo date('h:i A',strtotime($row['s_endtime'])) ?></span></div>
      </div>
      <div class="col-md-12 mb-4">
        <div class="col-md-12 float-left"><strong>Address: </strong><span><?php echo $row['address'] ?></span></div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6">
        <button class="form-control text-white btn btn-success" onclick="edit_shift(<?php echo $row['sd_id'] ?>)"><i class="fa fa-edit fa-lg"></i></button>
      </div>
      <div class="col-md-6">
        <button class="form-control text-white btn btn-danger" onclick="del(delS,<?php echo $row['sd_id'] ?>)"><i class="fa fa-trash fa-lg"></i></button>
      </div>
    </div>
    <div class="row mt-3">
      <div class="col-md-12">
        <button type="button" data-toggle="modal" data-target="#exampleModal" class="form-control btn-info" data-dismiss="modal" onclick="add_shift();"><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Add Shift</button>
      </div>
    </div>
  </div>
  <?php
}
}

if (isset($_POST['show_shift3'])) {
  $sd_id = $_POST['show_shift3'];
  $shift_time = date('Y-m-d',strtotime($_POST['start_date']));

  $select_shifts = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id JOIN client ON shifts.s_client = client.c_id JOIN wt_users ON shifts.s_staff = wt_users.id WHERE wt_users.user_type = 'staff' AND shift_dates.sd_id = '".$sd_id."' AND shifts.close = '1' AND shifts.status = '1'";
  $select_shifts_ex = mysqli_query($con,$select_shifts);

  foreach ($select_shifts_ex as $row) {
    $shift_id = $row['s_id'];
    $s_shiftdate = $row['s_shiftdate'];
    ?>
    <div class="col-md-12 mb-3">
      <div class="py-2" style="border: 1px solid #ced4da; border-radius: 0.25rem; height: auto;">
        <input type="hidden" name="sr_id" value="<?php echo $sd_id ?>">
        <input type="hidden" name="shift_time" value="<?php echo $shift_time ?>">
        <div class="col-md-12 mb-4">
          <div class="col-md-6 float-left"><strong>Date: </strong><?php echo date('d-M-Y',strtotime($shift_time)) ?></div>
          <div class="col-md-6 float-left"><strong>Type: </strong><span><?php echo ucwords($row['s_shift_type']) ?></span></div>
        </div>
        <div class="col-md-12 mb-4">
          <div class="col-md-6 float-left"><strong>Client: </strong><span class="text-info"><?php echo ucwords($row['m_name']) ?></span></div>
        </div>
        <div class="col-md-12 mb-4">
          <div class="col-md-6 float-left"><strong>Original Shift Staff: </strong><span class="text-info">
           <?php 
           $select_shifts_org_staff = "SELECT * FROM shift_orgnal_staff JOIN wt_users ON CONCAT(',', shift_orgnal_staff.staff_id, ',') LIKE CONCAT('%,', wt_users.id, ',%') WHERE shift_orgnal_staff.shift_id = '".$shift_id."'";
           $select_shifts_org_staff_ex = mysqli_query($con, $select_shifts_org_staff);

           foreach ($select_shifts_org_staff_ex as $roworignal) {
            echo ucwords($roworignal['f_name']." ".$roworignal['l_name']);
          }
          ?>


        </span></div>
        <div class="col-md-6 float-left"><strong>Current Shift Staff: </strong><span class="text-info"><?php echo ucwords($row['f_name']." ".$row['l_name']) ?></span></div>
      </div>
      <div class="col-md-12 mb-4"></div>
      <div class="col-md-12 mb-4">
        <div class="col-md-6 float-left"><strong>From: </strong><span class="text-success"><?php echo date('h:i A',strtotime($row['s_starttime'])) ?></span></div>
        <div class="col-md-6 float-left"><strong>To: </strong><span class="text-danger"><?php echo date('h:i A',strtotime($row['s_endtime'])) ?></span></div>
      </div>
      <div class="col-md-12 mb-4">
        <div class="col-md-12 float-left"><strong>Address: </strong><span><?php echo $row['address'] ?></span></div>
      </div>
    </div>
  </div>
  <?php
}
}






if (isset($_POST['checkshiftsector'])) {
  $checkshiftsector = $_POST['checkshiftsector'];
  $select_query = "SELECT * from wt_users JOIN staff_sector ON staff_sector.wt_user_id = wt_users.id WHERE wt_users.user_type = 'staff' AND wt_users.close = '1' AND wt_users.status = '1' AND staff_sector.sector_id = '".$checkshiftsector."'";
  $select_query_ex = mysqli_query($con,$select_query);
  if($select_query_ex){
    ?> <option value disabled selected>---- Select Staff ----</option>
    <?php foreach ($select_query_ex as $row){

      ?>

      <option value="<?php echo $row['id'] ?>"><?php echo ucwords($row['f_name']." ".$row['l_name']) ?></option>
      <?php

    }
  }
}



if (isset($_POST['checkstaffleave'])) {
  $checkstaffleave = $_POST['checkstaffleave'];
  $shiftdate = $_POST['shiftdate'];
  $get_mngr_data = "SELECT * FROM leave_management WHERE emp_id = '".$checkstaffleave."' 
  AND status = '1' 
  AND close = '1' 
  AND leave_status = '2' 
  AND ((MONTH(half_day_leave_date) = MONTH('".$shiftdate."') AND YEAR(half_day_leave_date) = YEAR('".$shiftdate."')) 
  OR (MONTH(full_day_leave_date) = MONTH('".$shiftdate."') AND YEAR(full_day_leave_date) = YEAR('".$shiftdate."')) 
  OR ('".$shiftdate."' BETWEEN multi_days_leave_date_from AND multi_days_leave_date_to))";

  $get_data_ex = mysqli_query($con, $get_mngr_data);

  if (mysqli_num_rows($get_data_ex) > 0) {
    echo "This staff is on Leave in the selected Month on date/s:<br>";
    foreach ($get_data_ex as $row) {
      if ($row['half_day_leave_date'] != '0000-00-00') {
        echo $row['half_day_leave_date']."<br>";
      }
      if ($row['full_day_leave_date'] != '0000-00-00') {
        echo $row['full_day_leave_date']."<br>";
      }
      if ($row['multi_days_leave_date_from'] != '0000-00-00') {
        echo "From:". $row['multi_days_leave_date_from'] ."To:". $row['multi_days_leave_date_to']."<br>";
      }
    }
  }else{
    echo "true";
  }
}




if (isset($_POST['checksectorstaff'])) {
  $selected_sector = $_POST['checksectorstaff'];
  $select_query = "SELECT * from wt_users JOIN staff_sector ON wt_users.id = staff_sector.wt_user_id WHERE wt_users.status = '1' AND wt_users.close='1'";
  $select_query_ex = mysqli_query($con,$select_query);
  if($select_query_ex){
    ?> <option value disabled selected>---- Select Staff ----</option>
    <?php foreach ($select_query_ex as $row){

      if($row['sector_id'] == $selected_sector){
        ?>

        <option value="<?php echo $row['id'] ?>"><?php echo ucwords($row['f_name']." ".$row['l_name']) ?></option>
        <?php
      }
    }
  }
}







if (isset($_POST['checkalreadyresshift'])) {
  $checkalreadyresshift = $_POST['checkalreadyresshift'];
  $shiftdate = $_POST['shiftdate'];
  $starttime = $_POST['starttime'];
  $endtime = $_POST['endtime'];

  $select_query_res = "SELECT * FROM shifts WHERE status = '1' AND close='1' AND s_shiftdate = '".$shiftdate."'";
  $select_query_res_ex = mysqli_query($con, $select_query_res);

  foreach ($select_query_res_ex as $row1) {
    $existingStartTime = $row1['s_starttime'];
    $existingEndTime = $row1['s_endtime'];

    if (($starttime >= $existingStartTime && $starttime <= $existingEndTime) || ($endtime >= $existingStartTime && $endtime <= $existingEndTime)) {
      echo "Shift already added for the same staff on the same date and timing.";
      return;
    }
  }
}


?>
<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");

//////////////////////service_name_chk////////////////////////////
if (isset($_POST['service_name_chk'])) {
  $service_name = $_POST['service_name_chk'];
  $select_query = "SELECT * from services WHERE status = '1' AND close='1'";
  $select_query_ex = mysqli_query($con,$select_query);
  if($select_query_ex){
    foreach ($select_query_ex as $row){
      if ($row['service_name'] == $service_name) {
        echo "yes";
    }
}
}
else{
    echo "error";
}
}


////////////////////service_del//////////////////////////////////
if (isset($_POST['service_del'])) {
  $ser_id = $_POST['service_del'];
  $close = 0;
  $del_query = "UPDATE services SET close = '".$close."' WHERE ser_id = '".$ser_id."'";
  $del_query_ex = mysqli_query($con,$del_query);
}


// service_edit

if (isset($_POST['service_edit'])) {
  $ser_id = $_POST['service_edit'];
  $get_data = "SELECT * FROM `services` WHERE `ser_id`='".$ser_id."' AND status = '1' AND close = '1'";
  $get_data_ex =  mysqli_query($con,$get_data);
  ?>
  <form action="" method="post" enctype="multipart/form-data">
    <fieldset class="scheduler-border">
        <legend class="scheduler-border">
           Service Name <span class="req-data">*</span>
        </legend>
    <div class="row">
      <?php
      foreach ($get_data_ex as $row) {
        ?>
        
        <div class="form-group col-md-12">
          <input value="<?php echo $ser_id?>" type="hidden" name="ser_id">
          <label>Service <span class="req-data text-danger">*</span></label>
          <input value="<?php echo $row['service_name']?>" type="text" class="form-control prevent" name="service_name_u" id="service_name_u" data-required="true" placeholder="" required="required" autocomplete="off" onkeyup="service_name_checking_u();">
      </div>
      <div id="already-msg-u" class="form-group col-md-12"></div>
    </div>
    </fieldset>
    <div class="modal-footer">
                              <button type="submit" id="updatep" name="updatep" class="btn btn-customs"><span class="btn-label"><i class="fa fa-spinner"></i></span> Update</button>
                          </div>
      

      <?php 
  }
  ?>

</div>
</form>
<?php   
}
?>
<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");



if (isset($_POST['sdate'])) {
    $sdate = $_POST['sdate'];
    $edate = $_POST['edate'];
    $date1=date_create($sdate);
	$date2=date_create($edate);
	$diff=date_diff($date1,$date2);
	$days_diff = $diff->format("%a");

	$date = $sdate;
	$total_iteration = 0;
	$labels = array();
	$pending_array = array();
	for ($i=1; $i <= $days_diff; $i++) { 
	    $select_query1 = "SELECT COUNT(*),month(sd_date) from shift_dates WHERE sd_date = '".$date."' AND status = '1' AND close='1' AND sd_complete = '0' GROUP BY month(sd_date),year(sd_date)";
	    $select_query1_ex = mysqli_query($con,$select_query1);
	    if (mysqli_num_rows($select_query1_ex) != 0) {
	      foreach($select_query1_ex as $pending){
	        $pending_val = $pending['COUNT(*)'];
	        array_push($pending_array, $pending_val); 
	      }
	    }
	    else{
	      array_push($pending_array, 0);
	    }
	    array_push($labels, $date);
	    $total_iteration++;
	    $date = date('Y-m-d', strtotime($date . ' +1 day'));
	  }

      $data2 = $pending_array;


      $date = $sdate;
	$cancel_array = array();
	for ($i=1; $i <= $days_diff; $i++) { 
	    $select_query1 = "SELECT COUNT(*),month(sd_date) from shift_dates WHERE sd_date = '".$date."' AND status = '1' AND close='1' GROUP BY month(sd_date),year(sd_date)";
	    $select_query1_ex = mysqli_query($con,$select_query1);
	    if (mysqli_num_rows($select_query1_ex) != 0) {
	      foreach($select_query1_ex as $pending){
	        $pending_val = $pending['COUNT(*)'];
	        array_push($cancel_array, $pending_val); 
	      }
	    }
	    else{
	      array_push($cancel_array, 0);
	    }
	    $date = date('Y-m-d', strtotime($date . ' +1 day'));
	  }

      $data3 = $cancel_array;



      $date = $sdate;
	$complete_array = array();
	for ($i=1; $i <= $days_diff; $i++) { 
	    $select_query1 = "SELECT COUNT(*),month(sd_date) from shift_dates WHERE sd_date = '".$date."' AND status = '1' AND close='1' AND sd_complete = '1' GROUP BY month(sd_date),year(sd_date)";
	    $select_query1_ex = mysqli_query($con,$select_query1);
	    if (mysqli_num_rows($select_query1_ex) != 0) {
	      foreach($select_query1_ex as $pending){
	        $pending_val = $pending['COUNT(*)'];
	        array_push($complete_array, $pending_val); 
	      }
	    }
	    else{
	      array_push($complete_array, 0);
	    }
	    $date = date('Y-m-d', strtotime($date . ' +1 day'));
	  }

      $data4 = $complete_array;

      $comp_data = array();
      $comp_data['iteration'] = array($total_iteration);
      $comp_data['labels'] = [$labels];
      $comp_data['pending'] = [$data2];
      $comp_data['cancel'] = [$data3];
      $comp_data['complete'] = [$data4];
      echo json_encode($comp_data);
}



?>
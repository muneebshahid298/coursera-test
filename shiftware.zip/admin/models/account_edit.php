<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");

if (isset($_POST['account_edit'])) {
    $acc_id = $_POST['account_edit'];
     $accountEdit = "SELECT * FROM accounts WHERE acc_id = '".$acc_id."'";
    $accountEdit_ex = mysqli_query($con,$accountEdit);
    foreach($accountEdit_ex as $row){
      ?>
        <div class="row">
            <div class="form-group col-md-12">
                <input type="hidden" name="acc_id" value="<?php echo $row['acc_id'] ?>">
                <label for="profile_img">Account Name</label>
                <input type="text" name="acc_name" value="<?php echo $row['acc_name'] ?>" class="form-control" data-required="true" required="required">
            </div>
            <div class="form-group col-md-12">
                <label for="acc_type">Account Type</label>
                <select class="form-control" name="acc_type" id="acc_type" data-required="true" required="required" autofocus autocomplete="off">
                    <option value="<?php echo $row['acc_type'] ?>"><?php echo ucwords($row['acc_type']) ?></option>
                    <option value='income'>Income</option>
                    <option value='other income'>Other Income</option>
                    <option value='expense'>Expense</option>
                    <option value='other expense'>Other Expense</option>
                    <option value='cost of sales'>Cost of Sales</option>
                    <option value='asset'>Asset</option>
                    <option value='liability'>Liability</option>
                </select>
            </div>
        </div>
    <?php 
    }  
}

if (isset($_POST['account_del'])) {
    $account_del = $_POST['account_del'];
    $close = 0;

    $accountDel = "UPDATE accounts SET close = '".$close."' WHERE acc_id = '".$account_del."'";
    $accountDel_ex = mysqli_query($con,$accountDel);
}
?>
<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");

    // same_useremail_chk
if(isset($_POST['same_chk2'])){
    $user_email = $_POST['same_chk2'];
    $select_query = "SELECT * from wt_users WHERE status = '1' AND close='1' AND user_name = '".$user_email."'";
    $select_query_ex = mysqli_query($con , $select_query);
    if(mysqli_num_rows($select_query_ex) > 0){
        echo "<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>User Name</strong> Already Exists!!</div>";
    }else{
        echo true;
    }
}
    // same_empno_chk
if(isset($_POST['same_chk3'])){
    $user_empNo = $_POST['same_chk3'];
    $select_query = "SELECT * from wt_users WHERE status = '1' AND close='1' AND emp_no = '".$user_empNo."'";
    $select_query_ex = mysqli_query($con , $select_query);
    if(mysqli_num_rows($select_query_ex) > 0){
        echo "<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>Employee No</strong> Already Exists!!</div>";
    }else{
        echo true;
    }
}
    // same_email_chk
if(isset($_POST['same_chk4'])){
    $user_email = $_POST['same_chk4'];
    $select_query = "SELECT * from wt_users WHERE status = '1' AND close='1' AND email = '".$user_email."'";
    $select_query_ex = mysqli_query($con , $select_query);
    if(mysqli_num_rows($select_query_ex) > 0){
        echo "<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>Email</strong> Already Exists!!</div>";
    }else{
        echo true;
    }
}
if (isset($_POST['client_edit'])) {
    $clientid = $_POST['client_edit'];
    $userEdit = "SELECT * FROM wt_users JOIN client ON wt_users.id=client.wt_user_id WHERE wt_users.id = '".$clientid."' AND wt_users.close = '1' AND wt_users.status = '1'";
    $userEdit_ex = mysqli_query($con,$userEdit);
    foreach($userEdit_ex as $row){
       $prefix= $row['prefix'];
       if ($prefix == '0') {
          $prefix_ex = 'Mrs.';
      }
      else {
          $prefix_ex = 'Mr.';
      }
      ?>
      <div class="row">
        <div class="form-group col-md-12">
          <label for="profile_img">Profile Image</label>
          <input id="profile_img" type="file" name="profile_img_u" class="dropify" data-required="true" required="required" data-default-file="../assets/img/<?php echo $row['profile_img']; ?>">
      </div>
      <script>
        $(document).ready(function(){
            $('.dropify').dropify();
            });
    </script>
        <div class="form-group col-md-6">
            <input type="hidden" name="clientid" value="<?php echo $clientid; ?>">
            <label for="prefix">Prefix</label>
            <select class="form-control" name="prefix_u" id="prefix" data-required="true" required="required" autofocus autocomplete="off">
                <option value disabled selected><?php echo $prefix_ex; ?></option>
                <option value='1'>Mr.</option>
                <option value='0'>Mrs.</option>

            </select>
        </div>
        <div class="form-group col-md-6">
            <label for="fname_u">First Name</label>
            <input type="text" id="fname_u" name="fname_u" value="<?php echo $row['f_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6">
            <label for="mname">Middle Name</label>
            <input type="text" id="mname" name="mname_u" value="<?php echo $row['m_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6">
            <label for="lname_u">Family Name</label>
            <input type="text" id="lname_u" name="lname_u" value="<?php echo $row['l_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6">
            <label for="phone_u">Contact</label>
            <input type="number" id="phone_u" name="phone_u" value="<?php echo $row['phone'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6">
            <label for="mobile_u">Mobile</label>
            <input type="number" id="mobile" name="mobile_u" value="<?php echo $row['mobile'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6">
            <label for="dob_u">DOB</label>
            <input type="date" id="dob_u" name="dob_u" value="<?php echo $row['dob'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6">
            <label for="useremail">Email</label>
            <input type="email" id="useremail" name="email_u" value="<?php echo $row['email'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onkeyup="useremailchk();">
        </div>
        <div class="form-group col-md-12" id="alert_msg4">
        </div>

        <div class="form-group col-md-12">
            <label for="address_u">Address</label>
            <input type="text" id="address_u" name="address_u" value="<?php echo $row['address'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-12">
            <label for="aprt_num">Unit/Appartment Number</label>
            <input type="text" id="aprt_num" name="aprt_num_u" value="<?php echo $row['apprt_num'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
        </div>
        <div class="form-group col-md-6">
            <label for="marital_status">Merital Status</label>
            <select class="form-control" name="marital_status_u" id="marital_status" data-required="true" required="required" autofocus autocomplete="off">
              <option value disabled selected><?php echo $row['marital_status']; ?></option>
              <option value='single'>Single</option>
              <option value='married'>Married</option>
              <option value='other'>Other</option>

          </select>
      </div>
      <div class="form-group col-md-6"></div>
      <div class="form-group col-md-6">
        <label for="religion">Religion</label>
        <input type="text" id="religion" name="religion_u" value="<?php echo $row['religion'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
    </div>
    <div class="form-group col-md-6">
        <label for="nationality">Nationality</label>
        <input type="text" id="nationality" name="nationality_u" value="<?php echo $row['nationality'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
    </div>
    <div class="form-group col-md-6">
        <label for="language">Language Spoken</label>
        <input type="text" id="language" name="language_u" value="<?php echo $row['language'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
    </div>
</div>
<div class="modal-footer">
    <button type="submit" id="submitclient" name="editclient" class="btn btn-success"><span class="btn-label"><i class="fa fa-spinner"></i></span> Update</button>
</div>

<?php   
}
}
if (isset($_POST['update_status'])) {
    $i_id = $_POST['update_status'];
     $statusEdit = "SELECT * FROM item WHERE i_id = '".$i_id."'";
    $statusEdit_ex = mysqli_query($con,$statusEdit);
    foreach($statusEdit_ex as $row){
      ?>
    <div class="modal-body">
        <div class="row">
            <div class="col-md-12 form-group p-0">
                <label for="item_status">Select Status</label>
                <input type="hidden" name="i_id" value="<?php echo $row['i_id'] ?>">
                <select id="item_status" name="item_status" value="" class="form-control" required="required">
                    <option class="text-center" value selected disabled>---- Select an Option ----</option>
                    <option value="0">Active</option>
                    <option value="1">Inactive</option>
                </select>
            </div>
        </div>
    </div>
    <?php 
    }  
}
?>
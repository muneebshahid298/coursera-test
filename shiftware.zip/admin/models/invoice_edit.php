<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");

if (isset($_POST['update_paid'])) {
    $i_id = $_POST['update_paid'];
     $invoiceEdit = "SELECT * FROM invoice WHERE in_id = '".$i_id."'";
    $invoiceEdit_ex = mysqli_query($con,$invoiceEdit);
    foreach($invoiceEdit_ex as $row){
      ?>
        <div class="row">
            <div class="form-group col-md-12 p-3">
                <input type="hidden" name="in_id" value="<?php echo $row['in_id']; ?>">
                <label for="profile_img">Paid Amount</label>
                <input type="number" step="0.01" name="paid_amount" value="<?php echo $row['in_paid_amount'] ?>" class="form-control" data-required="true" required="required">
            </div>
        </div>
    <?php 
    }  
}
?>
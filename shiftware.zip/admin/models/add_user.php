<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");

// same_useremail_chk
if(isset($_POST['same_chk2'])){
    $user_email = $_POST['same_chk2'];
    $select_query = "SELECT * from wt_users WHERE status = '1' AND close='1' AND user_name = '".$user_email."'";
    $select_query_ex = mysqli_query($con , $select_query);
    if(mysqli_num_rows($select_query_ex) > 0){
        echo "<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>User Name</strong> Already Exists!!</div>";
    }else{
        echo true;
    }
}
    // same_empno_chk
if(isset($_POST['same_chk3'])){
    $user_empNo = $_POST['same_chk3'];
    $select_query = "SELECT * from wt_users WHERE status = '1' AND close='1' AND emp_no = '".$user_empNo."'";
    $select_query_ex = mysqli_query($con , $select_query);
    if(mysqli_num_rows($select_query_ex) > 0){
        echo "<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>Employee No</strong> Already Exists!!</div>";
    }else{
        echo true;
    }
}
    // same_email_chk
if(isset($_POST['same_chk4'])){
    $user_email = $_POST['same_chk4'];
    $select_query = "SELECT * from wt_users WHERE status = '1' AND close='1' AND email = '".$user_email."'";
    $select_query_ex = mysqli_query($con , $select_query);
    if(mysqli_num_rows($select_query_ex) > 0){
        echo "<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>Email</strong> Already Exists!!</div>";
    }else{
        echo true;
    }
}
if (isset($_POST['user_edit'])) {
    $user_id = $_POST['user_edit'];
    $userEdit = "SELECT * FROM wt_users WHERE id = '".$user_id."' AND close = '1' AND status = '1'";
    $userEdit_ex = mysqli_query($con,$userEdit);
    foreach($userEdit_ex as $row){
        ?>
    <fieldset class="scheduler-border">
        <legend class="scheduler-border">
            User Details <span class="req-data">*</span>
        </legend>
        <div class="row">
            <div class="form-group col-md-6">
                <input type="hidden" name="userid" value="<?php echo $user_id; ?>">
                <label for="fusername">First Name</label>
                <input type="text" id="fusername" name="fusername" value="<?php echo $row['f_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
            </div>
            <div class="form-group col-md-6">
                <label for="lusername">Last Name</label>
                <input type="text" id="lusername" name="lusername" value="<?php echo $row['l_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
            </div>
            <div class="form-group col-md-6">
                <label for="phone_u">Contact</label>
                <input type="number" id="phone_u" name="phone_u" value="<?php echo $row['phone'] ?>" class="form-control prevent" data-required="true" required="required" autofocus autocomplete="off">
            </div>
            <div class="form-group col-md-6">
                <label for="mobile_u">Mobile</label>
                <input type="number" id="mobile" name="mobile_u" value="<?php echo $row['mobile'] ?>" class="form-control prevent" data-required="true" required="required" autofocus autocomplete="off">
            </div>
            <div class="form-group col-md-6">
                <label for="dob_u">DOB</label>
                <input type="date" id="dob_u" name="dob_u" value="<?php echo $row['dob'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
            </div>
            <div class="form-group col-md-6">
                <label for="useremail">Email</label>
                <input type="email" id="useremail" name="email_u" value="<?php echo $row['email'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onkeyup="useremailchk();">
            </div>
            <div class="form-group col-md-12" id="alert_msg4">
            </div>

            <div class="form-group col-md-12">
                <label for="address_u">Address</label>
                <input type="text" id="address_u" name="address_u" value="<?php echo $row['address'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
            </div>
        </div>
    </fieldset>
    <div class="modal-footer">
        <button type="submit" id="editUser" name="editUser" class="btn btn-customs"><span class="btn-label"><i class="fa fa-spinner"></i></span> Update</button>
    </div>

<?php   
    }
}
if (isset($_POST['user_view'])) {
    $user_id = $_POST['user_view'];
    $userEdit = "SELECT * FROM wt_users WHERE id = '".$user_id."' AND close = '1' AND status = '1'";
    $userEdit_ex = mysqli_query($con,$userEdit);
    foreach($userEdit_ex as $row){
        ?>
        <div class="modal-body">
            <fieldset class="scheduler-border">
                <legend class="scheduler-border">
                    User Details <span class="req-data">*</span>
                </legend>
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="fusername">First Name</label>
                        <input readonly type="text" id="fusername" name="fusername" value="<?php echo $row['f_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="lusername">Last Name</label>
                        <input readonly type="text" id="lusername" name="lusername" value="<?php echo $row['l_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="phone_u">Contact</label>
                        <input type="number" id="phone_u" name="phone_u" readonly="" value="<?php echo $row['phone'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="mobile_u">Mobile</label>
                        <input type="number" id="mobile" name="mobile_u" readonly="" value="<?php echo $row['mobile'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="dob_u">DOB</label>
                        <input type="date" id="dob_u" name="dob_u" readonly="" value="<?php echo $row['dob'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="useremail">Email</label>
                        <input type="email" id="useremail" name="email_u" readonly="" value="<?php echo $row['email'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onkeyup="useremailchk();">
                    </div>
                    <div class="form-group col-md-12">
                        <label for="address_u">Address</label>
                        <input type="text" id="address_u" name="address_u" readonly="" value="<?php echo $row['address'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                    </div>
                </div>
            </fieldset>
        </div>

        <?php   
    }
}
if (isset($_POST['user_del'])) {
    $userid = $_POST['user_del'];
    $close = 0;
    
    $userDel = "UPDATE wt_users SET close = '".$close."' WHERE id = '".$userid."'";
    $userDel_ex = mysqli_query($con,$userDel);
}
?>
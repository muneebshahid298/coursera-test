<?php 
	// extract($_POST);
	// $db_table_name = $_POST['name'];
	// echo $db_table_name;
	// select_fun($db_table_name);
 	function select($db_table_name,$con){
		$select_query = "SELECT * from ".$db_table_name." WHERE status = '1' AND close='1'";
		$select_query_ex = mysqli_query($con,$select_query)or die( mysqli_error($con));
		return $select_query_ex;
	}
	function select_id($db_table_name,$cus_id,$con){
		$select_query = "SELECT * FROM ".$db_table_name." WHERE cus_id = '".$cus_id."' AND status = '1' AND close = '1'";
    	$select_query_ex = mysqli_query($con,$select_query);
		return $select_query_ex;
	}
	function select_cat_id($db_table_name,$test_category,$con){
		$select_query = "SELECT * FROM ".$db_table_name." WHERE c_id = '".$test_category."' AND status = '1' AND close = '1'";
    	$select_query_ex = mysqli_query($con,$select_query);
		return $select_query_ex;
	}
	
	
?>
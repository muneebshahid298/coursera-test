 <?php 
 ob_start();
 session_start();
 include_once("../../env/main_config.php");


 if (isset($_POST['event_del'])) {
  $event_del = $_POST['event_del'];
  //echo $event_del;
  $close = 0;
  $shiftDel = "UPDATE events SET close = '".$close."' WHERE event_id = '".$event_del."'";
  $shiftDel_ex = mysqli_query($con,$shiftDel);
}








if (isset($_POST['event_edit'])) {
  $eventid = $_POST['event_edit'];
  $eventEdit = "SELECT * FROM events WHERE event_id = '".$eventid."' AND close = '1' AND status = '1'";
  $eventEdit_ex = mysqli_query($con,$eventEdit);
  foreach($eventEdit_ex as $row){
    ?>
    <div class="row">
      <input type="hidden" id="event_id" name="event_id" value="<?php echo $eventid; ?>">
     <div class="form-group col-md-12">
      <label>Event</label>
      <input type="text" id="event_name_u" name="event_name_u" value="<?php echo $row['event_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
    </div> 
    <div class="form-group col-md-12">
      <label>Event Date</label>
      <input type="date" id="event_date_u" name="event_date_u" value="<?php echo $row['event_date'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
    </div> 
  </div>
  <div class="modal-footer">
    <button type="submit" id="editevent" name="editevent" class="btn btn-success"><span class="btn-label"><i class="fa fa-spinner"></i></span> Update</button>
  </div>

  <?php   
}
}









if (isset($_POST['show_events'])) {
 $event_date = date('Y-m-d',strtotime($_POST['show_events']));
 $select_event = "SELECT * FROM events WHERE event_date = '".$event_date."' AND close = '1' AND status = '1'";
 $select_event_ex = mysqli_query($con,$select_event);

 foreach ($select_event_ex as $row) {
   $event_id = $row['event_id'];
   ?>
   <div class="col-md-12 mb-3">
    <div class="py-2" style="border: 1px solid #ced4da; border-radius: 0.25rem; height: auto;">
      <div class="form-group col-md-12">
        <label>Event</label>
        <input type="text" id="event_name_u" name="event_name_u" value="<?php echo $row['event_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
      </div> 
      <div class="form-group col-md-12">
        <label>Event Date</label>
        <input type="date" id="event_date_u" name="event_date_u" value="<?php echo $row['event_date'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
      </div> 
    </div>
    <div class="row">
      <div class="col-md-6">
        <button class="form-control text-white btn btn-success" onclick="edit_event(<?php echo $row['event_id']; ?>)"><i class="fa fa-edit fa-lg"></i></button>
      </div>
      <div class="col-md-6">
        <button class="form-control text-white btn btn-danger" onclick="del(delS,<?php echo $row['event_id']; ?>)"><i class="fa fa-trash fa-lg"></i></button>
      </div>
    </div>
  </div>
  <?php
}
}
?>
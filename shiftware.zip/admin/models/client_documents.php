<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");

if (isset($_POST['client_doc_del'])) {
    $client_doc_del = $_POST['client_doc_del'];
    $close = 0;
    $clientDocDel = "UPDATE client_documents SET close = '".$close."' WHERE cl_doc_id = '".$client_doc_del."'";
    $clientDocDel_ex = mysqli_query($con,$clientDocDel);
}


if (isset($_POST['document_download'])){
    $doc_id = $_POST['document_download'];
    $client = "SELECT * FROM client_documents WHERE close = '1' AND status = '1' AND cl_doc_id = '".$doc_id."' ";
    $photo_view_mem = mysqli_query($con,$client);
    foreach($photo_view_mem as $row2){
        $clientdoc =  $row2['cl_doc_document'];
        echo $clientdoc;
    }
}

?>
<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");

$select_client = "SELECT * FROM client WHERE close = '1' AND status = '1'";
$select_client_ex = mysqli_query($con,$select_client);

$select_staff = "SELECT * FROM wt_users WHERE user_type = 'staff' AND close = '1' AND status = '1'";
$select_staff_ex = mysqli_query($con,$select_staff);

if (isset($_POST['item_details'])) {
    $item_id = $_POST['item_details'];
    $close = 0;
    $select_item = "SELECT * FROM item WHERE i_id = '".$item_id."'";
    $select_item_ex = mysqli_query($con,$select_item);
    foreach ($select_item_ex as $select_item_ex1) {
      $description = $select_item_ex1['i_description'];
      $sellitem = $select_item_ex1['i_sell_item'];
      $buyitem = $select_item_ex1['i_buy_item'];
      if ($sellitem == '1') {
        $unit = $select_item_ex1['i_selling_measure_unit'];
        $price = $select_item_ex1['i_selling_price'];
        $taxcode = $select_item_ex1['i_selling_tax_code'];
      }
      elseif ($buyitem == '1') {
        $unit = $select_item_ex1['i_buying_measure_unit'];
        $price = $select_item_ex1['i_buying_price'];
        $taxcode = $select_item_ex1['i_buying_tax_code'];
      }
      else{
        $unit = "";
        $price = "";
        $taxcode = "";
      }
    }
    echo $description."/".$unit."/".$price."/".$taxcode;
}
?>
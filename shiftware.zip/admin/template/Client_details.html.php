<style type="text/css">
  @media only screen and (max-width: 768px) {
  .mediaquerytopdivs {
    margin-left: 20px;
    margin-right: 20px; 
    margin-bottom: 10px;
  }
  .mediaquerymargin{
     margin-left: 20px;
    margin-right: 20px; 
  }
  .mediaquerymargintop{
    top: 10px;
  }
}
</style>

<?php 
$client_id = $_GET['client_id'];
?>
    <div class="main-panel">
      <div class="content">
        <div class="page-inner">
        			<div class="row" id="pagerow">
		          <div class="form-group col-md-4">
          			<h3 style="font-weight: bolder;">Profile Detail</h3>
          			<h6>Welcome to Shiftware name of trust</h6>
          		</div>
              <div class="form-group col-md-4"></div>
              <div class="form-group col-md-4">
                
              </div>
              <?php 
                $client_det = "SELECT * FROM wt_users JOIN client ON wt_users.id=client.wt_user_id WHERE wt_users.id = '".$client_id."' AND wt_users.close = '1' AND wt_users.status = '1'";
                $client_det_ex = mysqli_query($con,$client_det);
                foreach($client_det_ex as $row){
                   $prefix= $row['prefix'];
                   if ($prefix == '0') {
                      $prefix_ex = 'Mrs.';
                  }
                  else {
                      $prefix_ex = 'Mr.';
                  }
                  ?>
          		<div class="form-group col-md-12">
          			<div class="row">
          				<div class="form-group col-md-2"></div>
          				<div class="form-group col-md-2 mediaquerytopdivs" style="padding: 15px 0px 5px 20px; background: #B4DAF7; font-weight: bold; border-radius: 10px; margin-right: 10px;">
          					<p>Total</p>
          					<p>2</p>
          				</div>
          				<div class="form-group col-md-2 mediaquerytopdivs" style="padding: 15px 0px 5px 20px; background: #B1EBC4; font-weight: bold; border-radius: 10px; margin-right: 10px;">
          					<p>Booked</p>
          					<p>2</p>
          				</div>
          				<div class="form-group col-md-2 mediaquerytopdivs" style="padding: 15px 0px 5px 20px; background: #FF937A; font-weight: bold; border-radius: 10px; margin-right: 10px;">
          					<p>Cancelled</p>
          					<p>2</p>
          				</div>
          				<div class="form-group col-md-2 mediaquerytopdivs" style="padding: 15px 0px 5px 20px; background: #FDF4BD; font-weight: bold; border-radius: 10px; margin-right: 10px;">
          					<p>Pending</p>
          					<p>2</p>
          				</div>
          				
          			</div>
          		</div>
              

              <div class="form-group col-md-12">
                <div class="row">
                  <div class="form-group col-md-4 mediaquerymargin" style=" border-radius:10px; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); height: 400px; padding: 20px 10px 10px 10px; ">
                    <div class="row">
                      <div class="form-group col-md-12" style="text-align: center;">
                     <img style="border-radius: 50%; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); overflow: hidden;" src="../assets/img/<?php echo $row['profile_img']; ?>" width="100px;" height="100px;">
                        
                      </div>

                      <div class="form-group col-md-12">
                        <div class="row">
                          <div class="form-group col-md-12" style="padding-left: 30px; padding-right: 30px"><i class="fa fa-user mr-1" aria-hidden="true"></i>Name
                          <span style="font-weight: bold; float: right;"><?php echo ucwords($row['f_name']." ".$row['m_name']." ".$row['l_name']); ?></span></div>
                        
                          <div class="form-group col-md-12" style="padding-left: 30px; padding-right: 30px"><i class="fa fa-transgender-alt mr-1" aria-hidden="true"></i>Gender
                          <span style="font-weight: bold; float: right;"><?php echo $prefix_ex; ?></span></div>

                          <div class="form-group col-md-12" style="padding-left: 30px; padding-right: 30px"><i class="fa fa-flag mr-1" aria-hidden="true"></i>Nationality
                          <span style="font-weight: bold; float: right;"><?php echo $row['nationality']; ?></span></div>
                       
                        </div>
                      </div>
                    


                    </div>
                  </div>
               

                  <div class="form-group col-md-4 mediaquerymargin" style="top: -10px;">
                  <div class="form-group col-md-12 mediaquerymargintop" style=" border-radius:10px; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); height: 190px; padding: 20px 10px 10px 10px; margin-bottom: 20px;">
                    <p style="border-bottom: 2px solid #91C6F1;"><i class="fa fa-file mr-2" aria-hidden="true"></i> <span style="font-weight: bolder;">Contact Details</span></p>

                          <div class="form-group col-md-12" style="padding-left: 30px; padding-right: 30px; font-size: 12px; top: -20px;"><i class="fa fa-phone mr-2" aria-hidden="true"></i>Phone<span style="font-weight: bold; float: right;"><?php echo $row['phone']; ?></span></div>


                         <div class="form-group col-md-12" style="padding-left: 30px; padding-right: 30px; font-size: 12px; top: -30px;"><i class="fa fa-mobile mr-2" aria-hidden="true"></i>Mobile<span style="font-weight: bold; float: right;"><?php echo $row['mobile']; ?></span></div>

                          <div class="form-group col-md-12" style="padding-left: 30px; padding-right: 30px; font-size: 12px; top: -30px;"><i class="fa fa-envelope mr-2" aria-hidden="true"></i>Email<span style="font-weight: bold; float: right;"><?php echo $row['email']; ?></span></div>


                         <div class="form-group col-md-12" style="padding-left: 30px; padding-right: 30px; font-size: 12px; top: -30px;"><i class="fa fa-building mr-2" aria-hidden="true"></i>Address<span style="font-weight: bold; float: right;"><?php echo $row['address']; ?></span></div>

                  </div>


                  <div class="form-group col-md-12" style=" border-radius:10px; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); height: 190px; padding: 20px 10px 10px 10px; ">
                    <p style="border-bottom: 2px solid #91C6F1;"><i class="fa fa-info-circle mr-2" aria-hidden="true"></i> <span style="font-weight: bolder;">Other Details</span></p>

                          <div class="form-group col-md-12" style="padding-left: 30px; padding-right: 30px; font-size: 12px; top: -20px;"><i class="fa fa-calendar mr-2" aria-hidden="true"></i>DOB<span style="font-weight: bold; float: right;"><?php echo $row['dob']; ?></span></div>


                         <div class="form-group col-md-12" style="padding-left: 30px; padding-right: 30px; font-size: 12px; top: -30px;"><i class="fa fa-user mr-2" aria-hidden="true"></i>Marital Status<span style="font-weight: bold; float: right;"><?php echo $row['marital_status']; ?></span></div>

                          <div class="form-group col-md-12" style="padding-left: 30px; padding-right: 30px; font-size: 12px; top: -30px;"><i class="fa fa-id-card mr-2" aria-hidden="true"></i>Religion<span style="font-weight: bold; float: right;"><?php echo $row['religion']; ?></span></div>


                         <div class="form-group col-md-12" style="padding-left: 30px; padding-right: 30px; font-size: 12px; top: -30px;"><i class="fa fa-globe mr-2" aria-hidden="true"></i>Language Spoken<span style="font-weight: bold; float: right;"><?php echo $row['language']; ?></span></div>
                  </div>
                  </div>



                  <div class="form-group col-md-4 mediaquerymargin" style=" border-radius:10px; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); height: 400px; padding: 20px 0px 10px 0px; ">
                      <div class="form-group col-md-12" style="padding-left: 20px; padding-right: 20px; "><i class="fa fa-dot-circle mr-2" aria-hidden="true"></i>Haider  <span style="font-weight: bold; float: right; color: #91C6F1; ">Transport</span><p style="font-size: 12px;">2023-01-14 to 2023-01-15</p><hr></div>
                  </div>

                </div>
              </div>
            <?php } ?>

               </div>
              </div>
			

		</div>
</div>


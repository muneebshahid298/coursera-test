
<div class="main-panel">
  <div class="content">
    <div class="page-inner">
     <div class="row">
        <div class="form-group col-md-12">
            <h3 style="font-weight: bolder;">Create Item</h3>
        </div>
       
<!-- ///////////////////////////////////////////////////////////////////////////////////////////// -->
        <div class="form-group col-md-12 pr-5" style="background: #FFFFFF;">
            <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                <div class="form-group col-md-12" style="border-bottom: 1px solid #000;">
                    <h2>Details</h2>
                    <div class="row">
                        <div class="form-group col-md-6"></div>
                        <div class="form-group col-md-6">
                            <div class="form-group col-md-12">
                                <label for="itemname">Name</label>
                                <input type="text" id="itemname" name="itemname" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="itemdesc">Description</label>
                                <textarea id="itemdesc" name="itemdesc" value="" class="form-control" data-required="true" required="required"></textarea>
                            </div>
                            <div class="form-group col-md-12">
                                <input type="checkbox" id="usedesc" name="usedesc[]" value="0">
                                <input type="hidden" name="usedesc[]" value="0">
                                <label for="usedesc"> Use item description on sales and purchases</label>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="itemid">Item Id *</label>
                                <input type="text" id="itemid" name="itemid" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                            </div>
                            <div class="form-group col-md-12">
                                <input type="checkbox" id="inactiveitem" name="inactiveitem[]" value="0">
                                <input type="hidden" name="inactiveitem[]" value="0">
                                <label for="inactiveitem"> Inactive Item</label>
                            </div>
                        </div>
                    </div>
                </div>

<!--     ////////////////////////////////////////////////////////////////////////////////////////// -->        
                <div class="form-group col-md-12" style="height: auto; border-bottom: 1px solid #000;">
                    <h2>Selling</h2>
                    <div class="row">
                        <div class="form-group col-md-6"></div>
                        <div class="form-group col-md-6">
                            <div class="form-group col-md-12">
                                <input type="checkbox" id="sellitem" name="sellitem" value="1" checked="" onclick="disablePurchases();">
                                <label for="sellitem"> I sell this item.</label>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="selling_price">Selling Price ($)</label>
                                <input type="text" id="selling_price" name="selling_price" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off"> 
                            </div>
                            <div class="form-group col-md-12">
                                <label for="tax_status">Selling Price is</label><br>
                                <input type="radio" id="tax_inclusive" name="tax_status" value="selling_tax_inclusive">
                                <label for="tax_inclusive">Tax Inclusive</label>
                                <input type="radio" id="tax_exclusive" name="tax_status" value="selling_tax_exclusive" checked="">
                                <label for="tax_exclusive">Tax Exclusive</label>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="measure_unit">Unit of measure</label>
                                <select id="measure_unit" name="measure_unit" value="" class="form-control" required="required">
                                    <option class="text-center" value selected disabled>---- Select an Option ----</option>
                                    <option value="each">Each</option>
                                    <option value="hour">Hour</option>
                                </select> 
                            </div>
                            <div class="form-group col-md-12">
                                <label for="track_sale_account">Income account for tracking sales *</label>
                                <select id="track_sale_account" name="track_sale_account" value="" class="form-control" data-required="true" required="required">
                                    <option class="text-center" value selected disabled>---- Select an Option ----</option>
                                    <?php
                                    foreach ($select_account_ex as $select_account_ex1) {
                                    ?>
                                    <option value="<?php echo $select_account_ex1['acc_id'] ?>"><?php echo ucwords($select_account_ex1['acc_name']) ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                             <div class="form-group col-md-12" style="display: none;">
                                <input type="hidden" value="" class="form-control"> 
                            </div>
                            <div class="form-group col-md-12">
                                <label for="tax_code">Tax Code *</label>
                                <select id="tax_code" name="tax_code" value="" class="form-control" data-required="true" required="required">
                                    <option class="text-center" value selected disabled>---- Select an Option ----</option>
                                    <option value="abn/-47">ABN&emsp;&emsp;No ABN Withholding&emsp;&emsp;&emsp;-47%</option>
                                    <option value="CAP/10">CAP&emsp;&emsp;Capital Acqisitions&emsp;&emsp;&emsp;&emsp;&#160;10%</option>
                                    <option value="EXP/0">EXP&emsp;&emsp;&#160;GST Free Exports&emsp;&emsp;&emsp;&emsp;&emsp;0%</option>
                                    <option value="FRE/0">FRE&emsp;&emsp;&#160;GST Free&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&#160;&#160;&#160;0%</option>
                                    <option value="GNR/0">GNR&emsp;&emsp;GST (Non-Registered)&emsp;&emsp;&emsp;0%</option>
                                    <option value="GST/10">GST&emsp;&emsp;Goods & Services Tax&emsp;&emsp;&emsp;&#160;&#160;10%</option>
                                    <option value="GW/0">GW&emsp;&emsp;&#160;Consolidated WEG & WET&emsp;0%</option>
                                    <option value="INP/10">INP&emsp;&emsp;&#160;Input Taxed&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&#160;&#160;&#160;10%</option>
                                    <option value="ITS/0">ITS&emsp;&emsp;&#160;&#160;Input Taxed Sales&emsp;&emsp;&emsp;&emsp;&emsp;&#160;&#160;0%</option>
                                    <option value="LCG/0">LCG&emsp;&emsp;Consolidated LCT & GST&emsp;&emsp;0%</option>
                                </select>
                            </div>
                            <div class="form-group col-md-12" style="display: none;">
                                <input type="hidden" value="" class="form-control"> 
                            </div>
                        </div>
                    </div>
                </div>
<!-- /////////////////////////////////////////////////////////////////////////////////////////// -->
                <div class="form-group col-md-12" style="height: auto; border-bottom: 1px solid #000;">
                    <h2>Buying</h2>
                    <div class="row">
                        <div class="form-group col-md-6"></div>
                        <div class="form-group col-md-6">
                            <div class="form-group col-md-12">
                                <input type="checkbox" id="buyitem" name="buyitem" value="0" onclick="disableselling();">
                                <label for="buyitem"> I buy this item.</label>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="buying_price">Buying Price ($)</label>
                                <input type="text" id="buying_price" name="buying_price" value="" class="form-control"> 
                            </div>
                            <div class="form-group col-md-12">
                                <label for="tax_status">Buying Price is</label><br>
                                <input type="radio" id="tax_inclusive" name="buying_tax_status" value="buying_tax_inclusive">
                                <label for="tax_inclusive">Tax Inclusive</label>
                                <input type="radio" id="tax_exclusive" name="buying_tax_status" value="buying_tax_exclusive" checked="">
                                <label for="tax_exclusive">Tax Exclusive</label>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="buying_measure_unit">Unit of measure</label>
                                <select id="buying_measure_unit" name="buying_measure_unit" value="" class="form-control">
                                    <option class="text-center" value selected disabled>---- Select an Option ----</option>
                                    <option value="each">Each</option>
                                    <option value="hour">Hour</option>
                                </select> 
                            </div>
                            <div class="form-group col-md-12">
                                <label for="track_purchase_account">Income account for tracking Purchases *</label>
                                <select id="track_purchase_account" name="track_purchase_account" value="" class="form-control">
                                    <option class="text-center" value selected disabled>---- Select an Option ----</option>
                                    <?php
                                    foreach ($select_account_ex as $select_account_ex1) {
                                    ?>
                                    <option value="<?php echo $select_account_ex1['acc_id'] ?>"><?php echo ucwords($select_account_ex1['acc_name']) ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group col-md-12" style="display: none;">
                                <input type="hidden" value="" class="form-control"> 
                            </div>
                            <div class="form-group col-md-12">
                                <label for="buying_tax_code">Tax Code *</label>
                                <select id="buying_tax_code" name="buying_tax_code" value="" class="form-control">
                                    <option class="text-center" value selected disabled>---- Select an Option ----</option>
                                    <option value="abn/-47">ABN&emsp;&emsp;No ABN Withholding&emsp;&emsp;&emsp;-47%</option>
                                    <option value="CAP/10">CAP&emsp;&emsp;Capital Acqisitions&emsp;&emsp;&emsp;&emsp;&#160;10%</option>
                                    <option value="EXP/0">EXP&emsp;&emsp;&#160;GST Free Exports&emsp;&emsp;&emsp;&emsp;&emsp;0%</option>
                                    <option value="FRE/0">FRE&emsp;&emsp;&#160;GST Free&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&#160;&#160;&#160;0%</option>
                                    <option value="GNR/0">GNR&emsp;&emsp;GST (Non-Registered)&emsp;&emsp;&emsp;0%</option>
                                    <option value="GST/10">GST&emsp;&emsp;Goods & Services Tax&emsp;&emsp;&emsp;&#160;&#160;10%</option>
                                    <option value="GW/0">GW&emsp;&emsp;&#160;Consolidated WEG & WET&emsp;0%</option>
                                    <option value="INP/10">INP&emsp;&emsp;&#160;Input Taxed&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&#160;&#160;&#160;10%</option>
                                    <option value="ITS/0">ITS&emsp;&emsp;&#160;&#160;Input Taxed Sales&emsp;&emsp;&emsp;&emsp;&emsp;&#160;&#160;0%</option>
                                    <option value="LCG/0">LCG&emsp;&emsp;Consolidated LCT & GST&emsp;&emsp;0%</option>
                                </select>
                            </div>
                            <div class="form-group col-md-12" style="display: none;">
                                <input type="hidden" value="" class="form-control"> 
                            </div>
                            <div class="form-group col-md-12">
                                <label for="buying_sup_item_id">Supplier Item ID</label>
                                <input type="text" id="buying_sup_item_id" name="buying_sup_item_id" value="" class="form-control"> 
                            </div>
                        </div>
                    </div>
                </div>

<!--     ////////////////////////////////////////////////////////////////////////////////////////// -->
                <div class="form-group col-md-12">
                    <div class="col-md-2 float-right p-0">
                        <button class="form-control btn btn-success" type="submit" name="submititem">Submit</button>
                    </div>
                </div>

            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <button id="editstatus1" type="button" data-toggle="modal" data-target="#updatestatus" class="btn btn-success" hidden><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Update Status</button>

            <!-- Modal -->
              <div class="modal fade" id="updatestatus" tabindex="-1" role="dialog" aria-labelledby="updatestatuslabel1" aria-hidden="true">
               <div class="modal-dialog" role="document">
                 <div class="modal-content">
                   <div class="modal-header">
                     <h5 class="modal-title modal-head" id="updatestatuslabel1">Update Status</h5>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                       <span aria-hidden="true">&times;</span>
                     </button>
                   </div>
                   <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                    <div class="modal-body editstatus">
              
                    </div>
                    <div class="modal-footer">
                        <button type="submit" id="submitstatus" name="submitstatus" class="btn btn-success"><span class="btn-label"><i class="fa fa-spinner"></i></span> Update</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
        </div>
    </div>
    <div class="row mt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                <?php
                if (isset($_GET['item'])) {
                  $i_id = $_GET['item'];

                  $res_data1 = "SELECT * FROM item WHERE i_id = '".$i_id."'";
                  $res_data1_ex = mysqli_query($con,$res_data1);
                  foreach ($res_data1_ex as $res_data1_ex1) {
                      $item = $res_data1_ex1['i_name'];
                      $i_sell_item = $res_data1_ex1['i_sell_item'];
                      $i_buy_item = $res_data1_ex1['i_buy_item'];
                  }
                ?>
                  <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                      <tr>
                        <th colspan="8" class="text-center"><?php echo $item ?><br>
                            <?php
                            if ($i_sell_item == '1') {
                                echo 'Selling';
                            }
                            elseif ($i_buy_item == '1') {
                                echo 'Buying';
                            }
                            ?>
                        </th>
                      </tr>
                      <tr>
                        <th class="text-center">S/No</th>
                        <th class="text-center">Unit Price</th>
                        <th class="text-center">Measurement Unit</th>
                        <th class="text-center">Tax Status</th>
                        <th class="text-center">Income Account</th>
                        <th class="text-center">Tax Code</th>
                        <!-- <th>Options</th> -->
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $sr = 1;
                      foreach ($res_data1_ex as $row) {
                        ?>
                        <tr id="<?php echo $row['i_id']; ?>">
                            <?php
                            if ($row['i_sell_item'] == '1') {
                            ?>
                                <td class="text-center"><?php echo $sr ?></td>
                                <td class="text-center"><?php echo $row['i_selling_price'] ?></td>
                                <td class="text-center"><?php echo ucwords($row['i_selling_measure_unit']) ?></td>
                                <td class="text-center"><?php echo $row['i_selling_tax_status'] ?></td>
                                <td class="text-center">
                                <?php
                                $select_account = "SELECT * FROM accounts WHERE acc_id = '".$row['i_track_sale_account']."'";
                                $select_account_ex = mysqli_query($con,$select_account);
                                foreach ($select_account_ex as $select_account_ex1) {
                                    echo $select_account_ex1['acc_name'];
                                }
                                ?>
                                </td>

                                <td class="text-center"><?php echo $row['i_selling_tax_code'] ?></td>
                            <?php
                            }
                            elseif ($row['i_buy_item'] == '1') {
                            ?>
                                <td class="text-center"><?php echo $sr ?></td>
                                <td class="text-center"><?php echo $row['i_buying_price'] ?></td>
                                <td class="text-center"><?php echo ucwords($row['i_buying_measure_unit']) ?></td>
                                <td class="text-center"><?php echo $row['i_buying_tax_status'] ?></td>

                                <td class="text-center">
                                <?php
                                $select_account = "SELECT * FROM accounts WHERE acc_id = '".$row['i_track_purchase_account']."'";
                                $select_account_ex = mysqli_query($con,$select_account);
                                foreach ($select_account_ex as $select_account_ex1) {
                                    echo $select_account_ex1['acc_name'];
                                }
                                ?>
                                </td>

                                <td class="text-center"><?php echo $row['i_buying_tax_code'] ?></td>
                            <?php
                            }
                            ?>
                        </tr>
                        <?php 
                        $sr++;
                      }?>
                    </tbody>
                  </table>
                <?php
                }
                else{
                ?>
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                  <thead>
                    <tr>
                      <th class="text-center">S/No</th>
                      <th class="text-center">Item Name</th>
                      <th class="text-center">Status</th>
                      <th class="text-center">Type</th>
                      <th class="text-center">Description</th>
                      <th class="text-center">Options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $sr = 1;
                    foreach ($select_item_ex as $row) {
                      ?>
                      <tr id="<?php echo $row['i_id']; ?>">
                        <td class="text-center"><?php echo $sr ?></td>
                        <td class="text-center"><?php echo ucwords($row['i_name']) ?></td>
                        <td class="text-center"><button class="btn" type="button" onclick="update_status(<?php echo $row['i_id'] ?>)">
                            <?php
                            if ($row['i_inactive'] == '0') {
                                echo '<span class="text-success">Active</span>';
                            }
                            elseif ($row['i_inactive'] == '1') {
                                echo '<span class="text-danger">Inactive</span>';
                            }
                            ?>        
                        </button></td>
                        <td class="text-center">
                            <?php
                            if ($row['i_sell_item'] == '1') {
                                echo 'Selling';
                            }
                            elseif ($row['i_buy_item'] == '1') {
                                echo 'Buying';
                            }
                            ?>
                        </td>
                        <td class="text-center"><textarea class="form-control" disabled=""><?php echo $row['i_description'] ?></textarea></td>

                        <td class="text-center"><a href="Create-item?item=<?php echo $row['i_id'] ?>"><button class="btn btn-success" style="padding: 4px 4px; border-radius: 3px;"><i class="ml-1 fa fa-eye fa-lg" aria-hidden="true"></i></button></a></td>
                      </tr>
                      <?php
                      $sr++;
                    }?>
                  </tbody>
                </table>
                <?php
                }
                ?>
              </div>
            </div>
        </div>
    </div>
   </div>


 </div>
</div>

<script>
    const Printcol = [0,1,2,3,4];
  var title = '<img src="../assets/img/logo.jpg" width="170"><h4 class="page-title text-center"><?php  echo $head_title1 = ucwords(substr(strstr(str_replace("_", " ", $head_title)," "), 1));  ?>s</h4>';
</script>

<script type="text/javascript">
    function disablePurchases() {
        var value_sell = $("#sellitem").val();
        if (value_sell == 0) {
            $("#sellitem").val(1);
            $("#selling_price").attr('required',true);
            $("#measure_unit").attr('required',true);
            $("#track_sale_account").attr('required',true);
            $("#tax_code").attr('required',true);
            var value_purchase = $("#buyitem").val();
            if (value_purchase == 1) {
                $("#buyitem").trigger('click');
            }
        }
        else if (value_sell == 1) {
            $("#sellitem").val(0);
            $("#selling_price").attr('required',false);
            $("#measure_unit").attr('required',false);
            $("#track_sale_account").attr('required',false);
            $("#tax_code").attr('required',false);
        }
    }
    function disableselling() {
        var value_purchase = $("#buyitem").val();
        if (value_purchase == 0) {
            $("#buyitem").val(1);
            $("#buying_price").attr('required',true);
            $("#buying_measure_unit").attr('required',true);
            $("#track_purchase_account").attr('required',true);
            $("#buying_tax_code").attr('required',true);
            $("#buying_sup_item_id").attr('required',true);
            var value_sell = $("#sellitem").val();
            if (value_sell == 1) {
                $("#sellitem").trigger('click');
            }
        }
        else if (value_purchase == 1) {
            $("#buyitem").val(0);
            $("#buying_price").attr('required',false);
            $("#buying_measure_unit").attr('required',false);
            $("#track_purchase_account").attr('required',false);
            $("#buying_tax_code").attr('required',false);
            $("#buying_sup_item_id").attr('required',false);
        }
    }

function update_status(iditem) {
    var iditem = iditem;
    $.ajax({
      type:"POST",
      url:"models/item_edit.php",
      data: 'update_status='+iditem,
      success:function(data) {
        $(".editstatus").html(data);
        $('#editstatus1').trigger('click');
      }
    });
}
</script>


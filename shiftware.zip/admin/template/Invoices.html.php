		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<!-- Card -->
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="card-head-row">
										<a href="create-invoice"><button type="button" class="btn btn-success"><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Add Invoice</button></a>
									</div>

              <button id="updatepaid1" type="button" data-toggle="modal" data-target="#updatepaidamount1" class="btn btn-success" hidden><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Update Client</button>

              <!-- Modal -->
              <div class="modal fade" id="updatepaidamount1" tabindex="-1" role="dialog" aria-labelledby="updatepaidamountlabel1" aria-hidden="true">
               <div class="modal-dialog" role="document">
                 <div class="modal-content">
                   <div class="modal-header">
                     <h5 class="modal-title modal-head" id="updatepaidamountlabel1">Update Paid Amount</h5>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                       <span aria-hidden="true">&times;</span>
                     </button>
                   </div>
                   <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                    <div class="modal-body updatpaidamount">
              
                    </div>
                    <div class="modal-footer">
                        <button type="submit" id="submitpaidamount" name="submitpaidamount" class="btn btn-success"><span class="btn-label"><i class="fa fa-spinner"></i></span> Submit</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="card-body">
            <?php
            if (isset($_GET['view_invoice'])) {
              $in_id = $_GET['view_invoice'];

              $res_data1 = "SELECT * FROM invoice JOIN invoice_items ON invoice.in_id=invoice_items.it_in_id JOIN client ON invoice.in_c_id = client.c_id JOIN item ON invoice_items.it_i_id = item.i_id WHERE invoice_items.it_in_id = '".$in_id."' AND invoice.close = '1' AND invoice.status = '1'";
              $res_data1_ex = mysqli_query($con,$res_data1);
            ?>
              <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                  <!-- <tr>
                    <th></th>
                  </tr> -->
                  <tr>
                    <th>S/No</th>
                    <th>Item</th>
                    <th>Account</th>
                    <th>Unit</th>
                    <th>Number of Unit</th>
                    <th>Unit Price</th>
                    <th>Discount</th>
                    <th>Amount</th>
                    <!-- <th>Options</th> -->
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $sr = 1;
                  foreach ($res_data1_ex as $row) {
                    ?>
                    <tr id="<?php echo $row['it_id']; ?>">
                      <td><?php echo $sr ?></td>
                      <td><?php echo ucwords($row['i_name']) ?></td>
                      <td><?php echo $row['it_account'] ?></td>

                      <?php
                      if ($row['i_sell_item'] == 1) {
                      ?>
                        <td><?php echo ucwords($row['i_selling_measure_unit']) ?></td>
                      <?php
                      }
                      elseif ($row['i_buy_item'] == 1) {
                      ?>
                        <td><?php echo ucwords($row['i_buying_measure_unit']) ?></td>
                      <?php
                      }
                      ?>

                      <td><?php echo $row['it_unit_nmbers'] ?></td>

                      <?php
                      if ($row['i_sell_item'] == 1) {
                      ?>
                        <td><?php echo $row['i_selling_price'] ?></td>
                      <?php
                      }
                      elseif ($row['i_buy_item'] == 1) {
                      ?>
                        <td><?php echo $row['i_selling_price'] ?></td>
                      <?php
                      }
                      ?>

                      <td><?php echo $row['it_discount'] ?></td>
                      <td><?php echo $row['it_amount'] ?><input type="hidden" id="id-item" value="<?php echo $row['it_id'] ?>"></td>

                      <!-- <td><button class="btn btn-info btn-edit" style="padding: 4px 4px; border-radius: 3px;"><i class="ml-1 fa fa-edit fa-lg" aria-hidden="true"></i></button> &nbsp;<button class="btn btn-danger btn-del" title="Remove"  style="padding: 4px 4px; border-radius: 3px;" onclick="del(delU,<?php echo $row['it_id']; ?>);"><i class="ml-1 fa fa-trash fa-lg" aria-hidden="true"></i></button></td> -->
                    </tr>
                    <?php 
                    $sr++;
                  }?>
                </tbody>
                <tfoot>
                  <tr>
                    <th>S/No</th>
                    <th>Item</th>
                    <th>Account</th>
                    <th>Unit</th>
                    <th>Number of Unit</th>
                    <th>Unit Price</th>
                    <th>Discount</th>
                    <th>Amount</th>
                    <!-- <th>Options</th> -->
                  </tr>
                </tfoot>
              </table>
            <?php
            }
            else{
            ?>
            <table id="example" class="table table-striped table-bordered" style="width:100%">
              <thead>
                <tr>
                  <th>S/No</th>
                  <th>Customer</th>
                  <th>Due Date</th>
                  <th>Amount Paid</th>
                  <th>Balance Due</th>
                  <th>Options</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $sr = 1;
                foreach ($res_data_ex as $row) {
                  ?>
                  <tr id="<?php echo $row['in_id']; ?>">
                    <td><?php echo $sr ?></td>
                    <td><?php echo ucwords($row['m_name']) ?></td>
                    <td><?php echo date('d-M-Y',strtotime($row['in_due_date'])) ?></td>
                    <td><button class="btn" type="button" onclick="update_paid_amount(<?php echo $row['in_id'] ?>);"><?php echo $row['in_paid_amount'] ?></button></td>
                    <td><?php echo round($row['in_balance_due'],2) ?><input type="hidden" id="id-invoice" value="<?php echo $row['in_id'] ?>"></td>

                    <td><a href="invoices?view_invoice=<?php echo $row['in_id'] ?>"><button class="btn btn-success" style="padding: 4px 4px; border-radius: 3px;"><i class="ml-1 fa fa-eye fa-lg" aria-hidden="true"></i></button></a></td>
                  </tr>
                  <?php
                  $sr++;
                }?>
              </tbody>
              <tfoot>
                <tr>
                  <th>S/No</th>
                  <th>Customer</th>
                  <th>Due Date</th>
                  <th>Amount Paid</th>
                  <th>Balance Due</th>
                  <th>Options</th>
                </tr>
              </tfoot>
            </table>
            <?php
            }
            ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script>
	const Printcol = [0,1,2,3,4];
  var title = '<img src="../assets/img/logo.jpg" width="170"><h4 class="page-title text-center"><?php  echo $head_title1 = ucwords(substr(strstr(str_replace("_", " ", $head_title)," "), 1));  ?>s Report</h4>';

function update_paid_amount(id) {
  $.ajax({
    type: "post",
    url: "models/invoice_edit.php",
    data: 'update_paid='+id,
    success: function(data){
      $(".updatpaidamount").html(data);
      $('#updatepaid1').trigger('click');
    }
  })
}
</script>
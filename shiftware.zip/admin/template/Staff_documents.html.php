    <div class="main-panel">
      <div class="content">
        <div class="page-inner">
          <!-- Card -->
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header">
                  <div class="card-head-row">
                     <div class="form-group col-md-8 col-lg-4">
                      <form action="" method="get" enctype="multipart/form-data">
                        <div class="row">
                          <div class="form-group col-md-9">
                            <select class="form-control" name="staffid" data-required="true" required="required" autocomplete="off">
                              <option value disabled selected class="text-center">---- Select Account ----</option>
                              <?php 
                              $res_data = "SELECT * FROM wt_users WHERE close = '1' AND status = '1' AND archieved = '0' AND user_type ='staff'";
                              $res_data_ex = mysqli_query($con,$res_data);
                              foreach ($res_data_ex as $row) {
                                ?>
                                <option value="<?php echo $row['id']; ?>"><?php echo ucwords($row['prefix']." ".$row['f_name']." ".$row['l_name']);?></option>
                                <?php
                              }
                              ?>
                            </select>
                          </div>
                          <div class="form-group col-md-3">
                            <button class="btn btn-danger search search_btn" id="btn1" type="submit" name="search"><i class="fa fa-search"></i> Search</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>

              <button id="updateUser1" type="button" data-toggle="modal" data-target="#exampleModal1" class="btn btn-success" hidden><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Update Client</button>

              <!-- Modal -->
              <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
               <div class="modal-dialog" role="document">
                 <div class="modal-content">
                   <div class="modal-header">
                     <h5 class="modal-title modal-head" id="exampleModalLabel1">Update Client</h5>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                       <span aria-hidden="true">&times;</span>
                     </button>
                   </div>
                   <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                    <div class="modal-body updateuser">

                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>



      <?php
      if(isset($_GET['staffid']) || isset($_GET['search'])) {
      $staffid = $_GET['staffid'];
      ?>
       <div class="card-body">
             <table id="example" class="table table-striped table-bordered text-center" style="width:100%">
              <thead>
                <tr>
                  <th>S/No</th>
                  <th>Client</th>
                  <th>Document</th>
                  <th>Upload Date</th>
                  <th>Options</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $sr = 1;
                $res_data = "SELECT * FROM staff_documents JOIN wt_users ON wt_users.id=staff_documents.staff_id WHERE staff_documents.close = '1' AND staff_documents.status = '1' AND staff_documents.staff_id = '".$staffid."' AND wt_users.close = '1' AND wt_users.status = '1'";
                $res_data_ex = mysqli_query($con,$res_data);
                foreach ($res_data_ex as $row) {
                  $upload_date=  date("d-m-Y", strtotime($row['stf_doc_date']));
                  ?>
                  <tr id="<?php echo $row['staff_dco_id']; ?>">
                    <?php 
                    echo "<td>".$sr."</td><td>".ucwords($row['prefix']." ".$row['f_name']." ".$row['l_name'])."</td><td>".$row['stf_doc_document']."</td><td>".$upload_date."<input type='hidden' id='staff_dco_id' value='".$row['staff_dco_id']."'></td>";
                    ?>
                    <td><button class="btn btn-danger btn-del" title="Remove"  style="padding: 9px 5px; border-radius: 3px;" onclick="del(delU,<?php echo $row['staff_dco_id']; ?>);"><i class="ml-1 fa fa-trash fa-lg" aria-hidden="true"></i></button>&nbsp;<button class="btn btn-success btn-download" title="download"  style="padding: 9px 5px; border-radius: 3px;" onclick="download(<?php echo $row['staff_dco_id']; ?>);"><i class="ml-1 fa fa-download fa-lg" aria-hidden="true"></i></button></td>
                  </tr>
                  <?php 
                  $sr++;
                }?>
              </tbody>
              <tfoot>
                <tr>
                  <th>S/No</th>
                  <th>Client</th>
                  <th>Nationality</th>
                  <th>Upload Date</th>
                  <th>Options</th>
                </tr>
              </tfoot>
            </table>
          </div><hr>
      <?php
    }
    else{
      ?>
       <div class="card-body">
             <table id="example" class="table table-striped table-bordered" style="width:100%">
              <thead>
                <tr>
                  <th>S/No</th>
                  <th>Client</th>
                  <th>No. of Documents</th>
                  <th>Options</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $sr = 1;
                $res_data = "SELECT *,COUNT(*) FROM staff_documents JOIN wt_users ON wt_users.id=staff_documents.staff_id WHERE staff_documents.close = '1' AND staff_documents.status = '1' AND wt_users.close = '1' AND wt_users.status = '1' Group BY staff_id";
                $res_data_ex = mysqli_query($con,$res_data);
                foreach ($res_data_ex as $row) {
                  $docno = $row['COUNT(*)'];
                  ?>
                  <tr id="<?php echo $row['staff_dco_id']; ?>">
                    <?php 
                    echo "<td>".$sr."</td><td>".ucwords($row['prefix']." ".$row['f_name']." ".$row['l_name'])."</td><td>".$docno."<input type='hidden' id='staff_dco_id' value='".$row['staff_dco_id']."'></td>";
                    ?>
                    <td><a href="staffdocuments?staffid=<?php echo $row['staff_id'];?>" id="btn-views" class="btn btn-success btn-views" title="view record for this date"><i class="fa fa-eye fa-lg" aria-hidden="true"></i></a></td>
                  </tr>
                  <?php 
                  $sr++;
                }?>
              </tbody>
              <tfoot>
                <tr>
                  <th>S/No</th>
                  <th>Client</th>
                  <th>No. of Documents</th>
                  <th>Options</th>
                </tr>
              </tfoot>
            </table>
          </div><hr>
      <?php
    }
    ?>
  
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script>
  const Printcol = [0,1,2,3,4];
  var title = '<img src="../assets/img/logo.jpg" width="170"><h4 class="page-title text-center"><?php  echo $head_title1 = ucwords(substr(strstr(str_replace("_", " ", $head_title)," "), 1));  ?>s Report</h4>';
 
  function delU(iduser) {
    var iduser = iduser;
    $.ajax({
      type:"POST",
      url:"models/add_staff.php",
      data: 'staff_doc_del='+iduser,
      success:function(data) {
        var rowh = "#"+iduser;
        $(rowh).remove();
        Swal.fire(
          'Deleted!',
          'Record has been deleted.',
          'success'
          )
      }
    });
  }


  function download(iddoc){
        var iddoc = iddoc;
        //alert(iddoc);
        $.ajax({
            type: "POST",
            url: "models/add_staff.php",
            data:'document_download='+iddoc,
            // dataType: "json",
            success: function(data){
                var source = '';
                source = "../assets/img/"+data;
                download_image(source);
                // alert(source);
            }
        });
    }
  function download_image(source){
      const fileName = source.split('/').pop();
      var el = document.createElement("a");
      el.setAttribute("href", source);
      el.setAttribute("download", fileName);
      document.body.appendChild(el);
      el.click();
      el.remove();
  };
  
</script>
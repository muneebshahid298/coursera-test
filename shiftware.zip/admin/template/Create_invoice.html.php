<style type="text/css">
    .table td{
        padding: 0px !important;
    }
</style>
<div class="main-panel">
  <div class="content">
    <div class="page-inner">
     <div class="row" id="pagerow">
       <div class="form-group col-md-12">
         <h3 style="font-weight: bolder;">Create Invoice</h3>
       </div>
       
<!-- ///////////////////////////////////////////////////////////////////////////////////////////// -->
        <div class="form-group col-md-12 pr-5" style="background: #FFFFFF;">
            <form action="" method="post" enctype="multipart/form-data" class="" autocomplete="off">
            <div class="form-group col-md-12" style="border-bottom: 1px solid #000;">
                <div class="row">
                    <div class="form-group col-md-4">
                        <div class="form-group col-md-12">
                            <label for="customer">Customer *</label>
                            <select id="customer" name="customer" value="" class="form-control" data-required="true" required="required">
                                <option value selected disabled>---- Select an option ----</option>
                                <?php
                                foreach ($select_client_ex as $select_client_ex1) {
                                ?>
                                <option value="<?php echo $select_client_ex1['c_id'] ?>"><?php echo ucwords($select_client_ex1['m_name']) ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group col-md-4"></div>
                    <div class="form-group col-md-4">
                        <div class="form-group col-md-12">
                            <label for="invoice_num">Invoice Number</label>
                            <input type="number" id="invoice_num" name="invoice_num" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="cus_po">Customer PO Number</label>
                            <input type="number" id="cus_po" name="cus_po" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="issue_date">Issue Date</label>
                            <input type="date" id="issue_date" name="issue_date" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="due_date">Due date</label>
                            <input type="date" id="due_date" name="due_date" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
                        </div>
                        <!-- <div class="form-group col-md-12">
                            <i class="fas fa-id-card"></i> <i class="fas fa-id-card"></i> <i class="fas fa-id-card"></i>
                            <label for="due_date">Start Getting Paid Online</label>
                        </div> -->
                        <div class="form-group col-md-12">
                            <label>Amounts are</label><br>
                            <input type="radio" id="tax_inclusive" name="tax_status" value="tax_inclusive">
                            <label for="tax_inclusive">Tax Inclusive</label>
                            <input type="radio" id="tax_exclusive" name="tax_status" value="tax_exclusive" checked="">
                            <label for="tax_exclusive">Tax Exclusive</label>
                        </div>
                    </div>
                </div>
            </div>
<!-- /////////////////////////////////////////////////////////////////////////////////////////////// -->
            <div class="form-group col-md-12" style="border-bottom: 1px solid #000; overflow-x: auto;">
                <table class="table table-bordered" style="width:100%;">
                    <thead>
                      <tr>
                        <th>Item ID</th>
                        <th>Description</th>
                        <th>Account</th>
                        <th>Unit</th>
                        <th>Number of Units</th>
                        <th>Unit Price</th>
                        <th>Discount(%)</th>
                        <th>Amount ($)</th>
                        <th>Job</th>
                        <th>Tax Code</th>
                        <th>Option</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                        <select id="item0" name="item[]" value="" class="form-control item" onchange="selected_item('0');" required="">
                            <option value selected disabled></option>
                            <?php
                            foreach ($select_item_ex as $select_item_ex1) {
                            ?>
                            <option value="<?php echo $select_item_ex1['i_id'] ?>"><?php echo $select_item_ex1['i_name'] ?></option>
                            <?php
                            }
                            ?>
                        </select>
                        </td>
                        <td><textarea id="description0" name="description[]" value="" class="form-control description"></textarea></td>
                        <td>
                        <select id="account0" name="account[]" value="" class="form-control account" required="">
                            <option class="text-center" value selected disabled>---- Select an Option ----</option>
                            <?php
                            foreach ($select_account_ex as $select_account_ex1) {
                            ?>
                            <option value="<?php echo $select_account_ex1['acc_id'] ?>"><?php echo ucwords($select_account_ex1['acc_name']) ?></option>
                            <?php
                            }
                            ?>
                        </select>
                        </td>
                        <td><input type="text" id="unit0" name="unit[]" value="" class="form-control unit"></td>
                        <td><input type="number" id="number_unit0" name="number_unit[]" value="0" class="form-control number_unit" onkeyup="calculate_subtotal(0);" required=""></td>
                        <td><input type="number" step="0.01" id="unit_price0" name="unit_price[]" value="0" class="form-control unit_price" readonly="" required=""></td>
                        <td><input type="number" id="discount0" name="discount[]" value="0" class="form-control discount" onkeyup="calculate_subtotal(0);" required=""></td>
                        <td><input type="number" step="0.01" id="amount0" name="amount[]" value="0" class="form-control amount" readonly="" required=""></td>
                        <td>
                        <select id="job0" name="job[]" value="" class="form-control job">
                        <option></option>
                        </select>
                        </td>
                        <td>
                        <input type="text" id="taxcode0" name="taxcode[]" value="" class="form-control taxcode">
                        </td>
                        <td></td>
                      </tr>
                    </tbody>
                    <tbody id="itemadd">
        
                    </tbody>
                </table>
                <div class='form-group col-md-12' id='errormsg0'>
                                
                </div>
                <div id="itemadd_error"></div>
                <div class="form-group col-md-12 p-0">
                    <div class="col-md-2 float-left p-0">
                        <button id="" type="button" class="btn btn-success search green_back form-control" style="float: right; border-radius: 3px;border-radius: 10px; padding: 12px;" onclick="additem();"><i class="fa fa-plus"></i>Add Item</button>
                    </div>
                </div>
            </div>

<!--  //////////////////////////////////////////////////////////////////////////////// -->

            <div class="form-group col-md-12">
                <div class="row">
                    <div class="form-group col-md-4">
                        <div class="form-group col-md-12">
                            <label for="notes_cus">Notes to Customer</label>
                            <!-- <span style="float: right;">
                            <input type="checkbox" id="savedefault" name="savedefault" value="Bike" >
                            <label for="savedefault" > Save as Default</label>
                            </span> -->
                            <!-- <select id="notes_cus" name="notes_cus" value="" class="form-control" data-required="true" required="required">
                                <option value selected disabled>---- Select an option ----</option>
                                <?php
                                foreach ($select_client_ex as $select_client_ex1) {
                                ?>
                                <option value="<?php echo $select_client_ex1['c_id'] ?>"><?php echo ucwords($select_client_ex1['m_name']) ?></option>
                                <?php
                                }
                                ?>
                            </select><br> -->
                            <textarea id="" name="customer_note" value="" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="form-group col-md-4"></div>
                    <div class="form-group col-md-4">
                        <div class="form-group col-md-12">
                            <p>Subtotal<input id="subtotal" style="border:none; float: right;" type="" value="0.00" name="subtotal" readonly=""><span style="float: right;">$</span></p>
                            <!-- <p>Freight ($)<span style="float: right;">Set up freight account</span></p> -->
                            <p>Tax<input id="total_tax" style="border:none; float: right;" type="" value="0.00" name="totaltax" readonly=""><span style="float: right;">$</span></p>
                            <p>Total<input id="totalamount" style="border:none; float: right;" type="" value="0.00" name="totalamount" readonly=""><span style="float: right;">$</span></p>
                            <p>Amount Paid ($)<span style="float: right;"><input type="text" id="amount_paid" name="amount_paid" value="0" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onkeyup="final_calculation();"> </span></p><br>
                            <p>Balance Due<input id="balancedue" style="border:none; float: right;" type="" value="0.00" name="balancedue" readonly=""><span style="float: right;">$</span></p>
                        </div>
                    </div>        
                </div>
            </div>

<!--  //////////////////////////////////////////////////////////////////////////////// -->
            <div class="modal-footer">
                <!-- <button type="submit" id="cancelinvoice" name="cancelinvoice" class="btn"><span class="btn-label"></span> Cancel</button> -->
                <button type="submit" id="submitinvoice" name="submitinvoice" class="btn btn-success"><span class="btn-label"><i class="fa fa-spinner"> </i> </span> Save</button>
            </div>
            </form>
        </div>
     </div>
   </div>


 </div>
</div>

<script type="text/javascript">
function selected_item(id) {
    var item_id = $("#item"+id).val();
    $.ajax({
      type: "POST",
      url: "models/invoice.php",
      data:'item_details='+item_id,
      success: function(data){
        var array = data.split('/');
        $("#description"+id).html(array[0]);
        $("#unit"+id).val(array[1]);
        $("#unit_price"+id).val(array[2]);
        $("#taxcode"+id).val(array[3]+"/"+array[4]);
        calculate_subtotal(id);
      }
    });
    
}

function calculate_subtotal(id) {
    var number_of_unit = 0;
    var unit_price = 0;
    var discount = 0;
    var amount = 0;

    for (var i = id; i >= 0; i--) {
        var number_of_unit = $("#number_unit"+i).val();
        var unit_price = $("#unit_price"+i).val();
        var discount = $("#discount"+i).val();
        var amount_without_percent = number_of_unit * unit_price;
        var required_percent_amount = (amount_without_percent/100);
        var required_percent_amount1 = Math.round(required_percent_amount * discount);
        // alert(required_percent_amount);
        var amount = amount_without_percent - required_percent_amount1;
        $("#amount"+i).val(amount);
    }
    final_calculation();
}

function final_calculation() {
    var amount = 0;
    var sub_total = 0;
    var total_tax = 0;

    var amount = new Array();
    $('.amount').each(function() {
        amount.push($(this).val());
    });
    for (var i = 0; i < amount.length; i++) {
        sub_total += parseInt(amount[i]);
    };

    $("#subtotal").val(Math.round(sub_total));

    var taxcode = new Array();
    $('.taxcode').each(function() {
        taxcode.push($(this).val());
    });
    for (var i = 0; i < taxcode.length; i++) {
        tax_code = taxcode[i];
        var array = tax_code.split('/');
        var tax_percentage = array[1];
        var tax = (amount[i]/100) * tax_percentage;
        total_tax += tax;
    };
    $("#total_tax").val(Math.round(total_tax));

    var total_amount = sub_total + total_tax;
    $("#totalamount").val(total_amount);

    var amount_paid = $("#amount_paid").val();
    var Balance_due = total_amount - amount_paid;
    $("#balancedue").val(Balance_due);

}


var x = 1;
var y = 1;
var m = 1;
var l = 0,r=0;
function additem() {   
   if($("#item"+l).find("option:selected").val() == '' || $("#account"+l).find("option:selected").val() == ''){
            $("#errormsg"+l).empty();
            $("#errormsg"+l).html("<div class='alert alert-danger' style = 'text-align : center;'><strong>Please</strong> fill the above feilds!</div>");
        }else{
            var p = $("#item"+l).find("option:selected").val();
        $("#errormsg"+l).empty();
        $("#itemadd").append("<tr id='row"+x+"'><td><select id='item"+y+"' name='item[]' value='' class='form-control item' onchange='selected_item("+y+");' required=''><option value selected disabled></option><?php foreach ($select_item_ex as $select_item_ex1) { ?> <option value='<?php echo $select_item_ex1['i_id'] ?>'><?php echo $select_item_ex1['i_name'] ?></option> <?php } ?> </select> </td> <td><textarea id='description"+y+"' name='description[]' value='' class='form-control description'></textarea></td> <td> <select id='account"+y+"' name='account[]' value='' class='form-control account' required=''><option class='text-center' value selected disabled>---- Select an Option ----</option><?php foreach ($select_account_ex as $select_account_ex1) { ?> <option value='<?php echo $select_account_ex1["acc_id"] ?>'><?php echo ucwords($select_account_ex1['acc_name']) ?></option> <?php } ?></select> </td> <td><input type='text' id='unit"+y+"' name='unit[]' value='' class='form-control unit'></td> <td><input type='number' id='number_unit"+y+"' name='number_unit[]' value='0' class='form-control number_unit' onkeyup='calculate_subtotal("+y+");' required=''></td><td><input type='number' step='0.01' id='unit_price"+y+"' name='unit_price[]' value='0' class='form-control unit_price' readonly='' required=''></td><td><input type='number' id='discount"+y+"' name='discount[]' value='0' class='form-control discount' onkeyup='calculate_subtotal("+y+")' required=''></td><td><input type='number' step='0.01' id='amount"+y+"' name='amount[]' value='0' class='form-control amount' readonly='' required=''></td><td><select id='job"+y+"' name='job[]' value='' class='form-control job'><option></option></select></td><td><input type='text' id='taxcode"+y+"' name='taxcode[]' value='' class='form-control taxcode'></td><td class='text-center'><button type='button' name='remove' id='"+x+"' class='btn btn-danger btn_remove'>X</button></td></tr><div class='form-group col-md-12' id='errormsg"+y+"'></div>");

        $("#itemadd_error").append("<div class='form-group col-md-12' id='errormsg"+y+"'></div>");
            x++;
            y++;
            l++;
            m++;
            
        }
        if(m!=1){
                r = m-1;
                $("#"+r+"").remove();
            }
        
        // var id = "#suittype"+y;
}

$(document).on('click', '.btn_remove', function(){  
    var button_id = $(this).attr("id");
    $('#row'+button_id+'').remove();
    final_calculation();
});
</script>


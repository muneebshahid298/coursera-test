<div class="main-panel">
	<div class="content">
		<div class="page-inner">
		<!-- Card -->
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<div class="card-head-row float-right">
								<button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-customs"><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Add User</button>
							</div><!-- Modal -->
							<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
								<div class="modal-dialog modal-dialog-centered modal-lg">
									<div class="modal-content">
										<div class="modal-header">
											<h3 class="modal-title" id="exampleModalLabel">Add User</h3>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
											<div class="modal-body">
												<fieldset class="scheduler-border">
						                            <legend class="scheduler-border">
						                               	User Details <span class="req-data">*</span>
						                            </legend>
													<div class="row">
														<div class="form-group col-md-6">
															<label for="fusername">First Name</label>
															<input type="text" id="fusername" name="fusername" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
														</div>
														<div class="form-group col-md-6">
															<label for="lusername">Last Name</label>
															<input type="text" id="lusername" name="lusername" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
														</div>

														<div class="form-group col-md-6">
															<label for="phone">Contact</label>
															<input type="number" id="phone" name="phone" value="" class="form-control prevent" data-required="true" required="required" autofocus autocomplete="off" onkeyup="empNochk();">
														</div>
														<div class="form-group col-md-6">
															<label for="mobile">Mobile</label>
															<input type="number" id="mobile" name="mobile" value="" class="form-control prevent" data-required="true" required="required" autofocus autocomplete="off" onkeyup="empNochk();">
														</div>
														<div class="form-group col-md-6">
															<label for="dob">DOB</label>
															<input type="date" id="dob" name="dob" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
														</div>
														<div class="form-group col-md-6">
															<label for="useremail">Email</label>
															<input type="email" id="useremail" name="email" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onkeyup="useremailchk();">
														</div>
														<div class="form-group col-md-12" id="alert_msg4">
														</div>
														<div class="form-group col-md-12">
															<label for="address">Address</label>
															<input type="text" id="address" name="address" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
														</div>
														<div class="form-group col-md-12">
															<label for="userloginname">User Name(Login)</label>
															<input type="text" id="userloginname" name="userloginnamee" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onkeyup="userloginnamechk();">
														</div>
														<div class="form-group col-md-12" id="alert_msg2"></div>
			                                          	<div class="form-group col-md-12">
			                                          		<label for="password">Password</label>
			                                          		<input type="password" id="password" name="password" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
			                                          	</div>
	                                      			</div>
	                                      		</fieldset>
                                  			</div>
		                                  	<div class="modal-footer">
		                                  		<button type="submit" id="submitUser" name="submitUser" class="btn btn-customs"><span class="btn-label"><i class="fa fa-spinner"></i></span> Submit</button>
		                                 	</div>
                              			</form>
                         	 		</div>
                      			</div>
                  			</div>
                  			<button id="updateUser1" type="button" data-toggle="modal" data-target="#exampleModal1" class="btn btn-success" hidden><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Update User</button>
                  			<!-- Modal -->
                  			<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
                  				<div class="modal-dialog modal-dialog-centered modal-lg">
                  					<div class="modal-content">
                  						<div class="modal-header">
                  							<h3 class="modal-title modal-head" id="exampleModalLabel1">Update User</h3>
                  							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  								<span aria-hidden="true">&times;</span>
                  							</button>
                  						</div>
                  						<form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                  							<div class="modal-body updateuser">
                  								
                  							</div>
                  						</form>
                  					</div>
                  				</div>
                  			</div>
              			</div>
              			<div class="card-body">
              				<table id="example" class="table table-striped table-bordered text-center" style="width:100%">
              					<thead>
              						<tr>
              							<th>S/No</th>
              							<th>Name</th>
              							<th>User Name</th>
              							<th>Email</th>
              							<th>Options</th>
              						</tr>
              					</thead>
              					<tbody>
              						<?php
              						$sr = 1;
              						foreach ($res_data_ex as $row) {
              							?>
              							<tr id="<?php echo $row['id']; ?>">
              								<?php 
              								echo "<td>".$sr."</td><td>".ucwords($row['f_name']." ".$row['l_name'])."</td><td>".$row['user_name']."</td><td>".$row['email']."</td><input type='hidden' id='id-user' value='".$row['id']."'></td>";
              								?>
              								<td><button class="btn btn-success btn-view" style="padding:9px 5px; border-radius: 3px;"><i class="ml-1 fa fa-eye fa-lg" aria-hidden="true"></i></button> &nbsp;<button class="btn btn-info btn-edit" style="padding:9px 5px; border-radius: 3px;"><i class="ml-1 fa fa-edit fa-lg" aria-hidden="true"></i></button> &nbsp;<button class="btn btn-danger btn-del" title="Remove"  style="padding:9px 5px; border-radius: 3px;" onclick="del(delU,<?php echo $row['id']; ?>);"><i class="ml-1 fa fa-trash fa-lg" aria-hidden="true"></i></button></td>
              							</tr>
              							<?php 
              							$sr++;
              						}?>
              					</tbody>
              					<tfoot>
              						<tr>
              							<th>S/No</th>
              							<th>Name</th>
              							<th>User Name</th>
              							<th>Email</th>
              							<th>Options</th>
              						</tr>
              					</tfoot>
              				</table>
              			</div>
              		</div>
              	</div>
            </div>
        </div>
    </div>
</div>
<script>
	const Printcol = [0,1,2,3,4];
	var title = '<img src="../assets/img/logo.jpg" width="170"><h4 class="page-title text-center"><?php  echo $head_title1 = ucwords(substr(strstr(str_replace("_", " ", $head_title)," "), 1));  ?>s Report</h4>';
	$(document).ready(function(){
		$('.btn-edit').click(function(e){
			$('.modal-head').text('Update User');
			e.preventDefault();
			var iduser = $(this).closest("tr").find("#id-user").val();
			$.ajax({
				type: "POST",
				url: "models/add_user.php",
				data:'user_edit='+iduser,
				success: function(data){
					$(".updateUser").html(data);
					$('#updateUser1').trigger('click');  
				}
			});
		});
		$('.btn-view').click(function(e){
			$('.modal-head').text('View User');
			e.preventDefault();
			var iduser = $(this).closest("tr").find("#id-user").val();
			$.ajax({
				type: "POST",
				url: "models/add_user.php",
				data:'user_view='+iduser,
				success: function(data){
					$(".updateUser").html(data);
					$('#updateUser1').trigger('click');  
				}
			});
		});
	});
	function delU(iduser) {
		var iduser = iduser;
		$.ajax({
			type:"POST",
			url:"models/add_user.php",
			data: 'user_del='+iduser,
			success:function(data) {
				var rowh = "#"+iduser;
				$(rowh).remove();
				Swal.fire(
					'Deleted!',
					'Record has been deleted.',
					'success'
					)
			}
		});
	}
	function userloginnamechk(){
		var userloginnamechk = document.getElementById('userloginname').value;

		$.ajax({
			type: "POST",
			url: "models/add_user.php",
			data:'same_chk2='+userloginnamechk,
			success: function(data){
				if (data == true) {
					$('#alert_msg2').empty();
					$('#submitUser').attr('disabled', false);
					$('#useremail').attr('disabled', false);
					$('#empNo').attr('disabled', false);
				}
				else{
					$('#alert_msg2').empty();
					$('#alert_msg2').html(data);
					$('#submitUser').attr('disabled', true);
					$('#useremail').attr('disabled', true);
					$('#empNo').attr('disabled', true);
				}     
			}
		});
	}
	function empNochk(){
		var empNochk = document.getElementById('empNo').value;

		$.ajax({
			type: "POST",
			url: "models/add_user.php",
			data:'same_chk3='+empNochk,
			success: function(data){
				if (data == true) {
					$('#alert_msg3').empty();
					$('#submitUser').attr('disabled', false);
					$('#useremail').attr('disabled', false);
					$('#userloginname').attr('disabled', false);
				}
				else{
					$('#alert_msg3').empty();
					$('#alert_msg3').html(data);
					$('#submitUser').attr('disabled', true);
					$('#useremail').attr('disabled', true);
					$('#userloginname').attr('disabled', true);
				}     
			}
		});
	}
	function useremailchk(){
		var useremailchk = document.getElementById('useremail').value;

		$.ajax({
			type: "POST",
			url: "models/add_user.php",
			data:'same_chk4='+useremailchk,
			success: function(data){
				if (data == true) {
					$('#alert_msg4').empty();
					$('#submitUser').attr('disabled', false);
					$('#empNo').attr('disabled', false);
					$('#userloginname').attr('disabled', false);
				}
				else{
					$('#alert_msg4').empty();
					$('#alert_msg4').html(data);
					$('#submitUser').attr('disabled', true);
					$('#empNo').attr('disabled', true);
					$('#userloginname').attr('disabled', true);
				}     
			}
		});
	}
</script>
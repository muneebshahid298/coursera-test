<?php 
if(mysqli_num_rows($execuit)>0){
	?>
	<style type="text/css">
		.chart-total{
			text-align: center;
			color: white;
			margin-top: 30px;
			margin-bottom: 20px;
			width: 100%;
			height: 50px;
			padding: 10px 0px;
			background: linear-gradient(to bottom, rgba(86, 171, 47,1) 0%,rgba(30, 113, 69,1) 100%);
			cursor: pointer;
			border-radius: 5px;
		}
		.chart-total1{
			text-align: center;
			color: white;
			margin-top: 30px;
			margin-bottom: 20px;
			width: 100%;
			height: 50px;
			padding: 10px 0px;
			background: linear-gradient(to bottom, rgba(86, 171, 47,1) 0%,rgba(30, 113, 69,1) 100%);
			cursor: pointer;
			border-radius: 5px;
		}
		.chart-color1 {
			background: linear-gradient(to bottom, rgba(183, 3, 3,1) 0%,rgba(128, 0, 0,1) 100%);
		}
		.chart-color2 {
			background: linear-gradient(to bottom, rgba(255, 193, 7,1) 0%,rgba(219, 166, 8,1) 100%);
		}

		.m_box{
			padding: 8px 10px;
			height: 185px;
		}
		.m_box h2{
			text-align: center;
		}
		.box{
			height: 130px;
			padding-top: 20px;
			color: #fff!important;
			background: white!important;
			overflow: hidden;
			margin-bottom: 5px;
		}
		.bg-border-green{
			border: 5px solid;
			border-image-slice: 1;
			border-radius: 20px;
		}
		.bg-border-green:hover{
			border: 5px solid;
			border-image-slice: 1;
			color: white!important;
		} 
	</style>
	<div class="main-panel">
		<div class="content">
			<div class="panel-header bg-primary-gradient">
				<div class="page-inner">

				</div>
			</div>
			<div class="page-inner mt--5">
				<div class="row mt--2">
					<div class="col-sm-6 col-md-3">
						<div class="card card-stats card-round">
							<div class="card-body ">
								<div class="row align-items-center">
									<div class="col-icon">
										<div class="icon-big text-center icon-danger bubble-shadow-small">
											<i class="flaticon-users"></i>
										</div>
									</div>
									<div class="col col-stats ml-3 ml-sm-0">
										<div class="numbers">
											<p class="card-category">No. of Staff</p>
											<h4 class="card-title"><?php echo $total_staff_sector;?></h4>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-3">
						<div class="card card-stats card-round">
							<div class="card-body">
								<div class="row align-items-center">
									<div class="col-icon">
										<div class="icon-big text-center icon-success bubble-shadow-small">
											<i class="flaticon-interface-6"></i>
										</div>
									</div>
									<div class="col col-stats ml-3 ml-sm-0">
										<div class="numbers">
											<p class="card-category">Total Clients</p>
											<h4 class="card-title"><?php echo $total_client;?></h4>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-3">
						<div class="card card-stats card-round">
							<div class="card-body">
								<div class="row align-items-center">
									<div class="col-icon">
										<div class="icon-big text-center icon-warning bubble-shadow-small">
											<i class="flaticon-graph"></i>
										</div>
									</div>
									<div class="col col-stats ml-3 ml-sm-0">
										<div class="numbers">
											<p class="card-category">Total Services</p>
											<h4 class="card-title"><?php echo $total_services; ?></h4>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-3">
						<div class="card card-stats card-round">
							<div class="card-body">
								<div class="row align-items-center">
									<div class="col-icon">
										<div class="icon-big text-center icon-secondary bubble-shadow-small" style="background: #343a40!important;">
											<i class="flaticon-success"></i>
										</div>
									</div>
									<div class="col col-stats ml-3 ml-sm-0">
										<div class="numbers">
											<p class="card-category">Total Sector</p>
											<h4 class="card-title"><?php echo $total_sectors;?></h4>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="col-md-6">
						<div class="card full-height">
							<div class="modal-header" style="background-color: #005431; color: #fff;">
								<h4 class="modal-title">Overall Statistics</h4>
							</div>
							<div class="card-body">
								<div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
									<div class="px-2 pb-2 pb-md-0 text-center">
										<a href="shifts" style="color: #57597A!important;"><div id="circles-1"></div></a>
										<h6 class="fw-bold mt-3 mb-0">Total Shifs</h6>
									</div>
									<div class="px-2 pb-2 pb-md-0 text-center">
										<a href="shifts" style="color: #57597A!important;"><div id="circles-2"></div></a>
										<h6 class="fw-bold mt-3 mb-0">Worked Hours</h6>
									</div>
									<div class="px-2 pb-2 pb-md-0 text-center">
										<a href="shifts" style="color: #57597A!important;"><div id="circles-3"></div></a>
										<h6 class="fw-bold mt-3 mb-0">Rejected Shifts</h6>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="card full-height">
							<div class="modal-header" style="background-color: #005431; color: #fff;">
								<h4 class="modal-title">Most Provided Services</h4>
							</div>
							<div class="card-body">
								<div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
									<div class="px-2 pb-2 pb-md-0">
										<h5 class="fw-bold mt-3 mb-0 text-center">Weekly</h5>
										<ol class="activity-feed">
											<?php
											for ($i=1; $i <= count($weekly_repeated_shifts); $i++) { 
												?>
												<li class="feed-item feed-item-success">
													<span class="text">
														<?php
															echo ucwords($weekly_repeated_shifts[$i]);
														?>
													</span>
												</li>
												<?php
											}
											?>
										</ol>

									</div>
									<div class="px-2 pb-2 pb-md-0">
										<h5 class="fw-bold mt-3 mb-0 text-center">Monthly</h5>
										<ol class="activity-feed">
											<?php
											for ($j=1; $j <= count($monthly_repeated_shifts); $j++) { 
												?>
												<li class="feed-item feed-item-success">
													<span class="text">
														<?php
															echo ucwords($monthly_repeated_shifts[$j]);
														?>
													</span>
												</li>
												<?php
											}
											?>
										</ol>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-7">
						<div class="card">
							<div class="card-header" style="background:#005431;">
								<div class="card-title text-white">Shifts Current Month</div>
							</div>
							<div class="card-body pb-0">
								<div class="d-flex">
									<div class="flex-1 pt-4 pb-4 ml-2">
										<h4 class="fw-bold mb-1">Shifts For <?php echo $current_month2 ?></h4>
									</div>
									<?php 
									$current_date = date('Y-m-d');
									$shifts = "SELECT * FROM shifts WHERE MONTH(s_shiftdate) = MONTH('".$current_date."') AND close = '1' AND status = '1' ";
									$shifts_ex = mysqli_query($con, $shifts);
									$total_shifts = mysqli_num_rows($shifts_ex);
									?>
									<div class="d-flex ml-auto align-items-center">
										<h3 class="text-info fw-bold"><?php echo $total_shifts;?></h3>
									</div>
								</div>
								<div class="separator-dashed"></div>
								<div class="d-flex">
									<div class="flex-1 pt-4 pb-4 ml-2">
										<h4 class="fw-bold mb-1">Open Shifts</h4>
									</div>
									<?php 
									$current_date = date('Y-m-d');
									$shifts = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id WHERE MONTH(shifts.s_shiftdate) = MONTH('".$current_date."') AND shifts.close = '1' AND shifts.status = '1' AND shift_dates.sd_complete !='2' ";
									$shifts_ex = mysqli_query($con, $shifts);
									$total_shifts2 = mysqli_num_rows($shifts_ex);
									?>
									<div class="d-flex ml-auto align-items-center">
										<h3 class="text-info fw-bold"><?php echo $total_shifts2;?></h3>
									</div>
								</div>
								<div class="separator-dashed"></div>
								<div class="d-flex">
									<div class="flex-1 pt-4 pb-4 ml-2">
										<h4 class="fw-bold mb-1">Closed Shifts</h4>
									</div>
									<?php 
									$current_date = date('Y-m-d');
									$shifts = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id WHERE MONTH(shifts.s_shiftdate) = MONTH('".$current_date."') AND shifts.close = '1' AND shifts.status = '1' AND shift_dates.sd_complete ='2' ";
									$shifts_ex = mysqli_query($con, $shifts);
									$total_shifts3 = mysqli_num_rows($shifts_ex);
									?>
									<div class="d-flex ml-auto align-items-center">
										<h3 class="text-info fw-bold"><?php echo $total_shifts3;?></h3>
									</div>
								</div>
								<div class="separator-dashed"></div>
							</div>
						</div>
					</div>
					<div class="col-md-5">
						<div class="card">
							<div class="card-body">
								<div class="col-md-6 m_box p-2 float-left">
									<a href="shifts" style="text-decoration: none;"><div class=" col-md-12 box bg-border-green text-center">
										<img src="../files/shift-icon.png">
									</div></a>
									<h2><b>Shifts</b></h2>
								</div>

								<div class="col-md-6 m_box p-2 float-left">
									<a href="leavemanagement" style="text-decoration: none;"><div class="col-md-12 box bg-border-green text-center" >
										<img src="../files/leave-management-icon.png">

									</div></a>
									<h3 class="text-center"><b>Leave Management</b></h3>
								</div>

								<div class="col-md-6 m_box p-2 float-left">
									<a href="staff" style="text-decoration: none;"><div class="col-md-12 box bg-border-green text-center" >
										<img src="../files/employee-icon.png">

									</div></a>
									<h2><b>Employees</b></h2>
								</div>

								<div class="col-md-6 m_box p-2 float-left">
									<a href="events" style="text-decoration: none;"><div class="col-md-12 box bg-border-green text-center" >
										<img src="../files/event-icon.png">
									</div></a>
									<h2><b>Events</b></h2>
								</div>

							</div>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header" style="background: #005431;">
								<div class="card-title text-white">Total Shifts</div>
							</div>
							<div class="card-body pb-0" style="height: 300px;">
								<canvas id="statisticsChart"></canvas>
							</div>
						</div>
					</div>
				</div>

				<div class="row mt--2">
					<div class="col-md-12">
						<div class="card">
							<div class="card-body">
								<table id="example" class="table table-striped table-bordered text-center" style="width:100%">
									<thead>
										<tr>
											<th>S/No</th>
											<th>Name</th>
											<th>Hours</th>
										</tr>
									</thead>
									<tbody>
										<?php
										$sr = 1;
										foreach ($select_staff_with_most_hours_ex as $row) {
											?>
											<tr id="<?php echo $row['id']; ?>">
												<?php 
												echo "<td class='btn-det'>".$sr."</td><td class='btn-det'>".ucwords($row['f_name']." ".$row['l_name'])."</td><td class='btn-det'>".$row['SUM(sd_hour)']."<input type='hidden' id='id-client' value='".$row['id']."'></td>";
												?>
											</tr>
											<?php 
											$sr++;
										}?>
									</tbody>
									<tfoot>
										<tr>
											<th>S/No</th>
											<th>Name</th>
											<th>Hours</th>
										</tr>
									</tfoot>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php 	
}else{
	header('Location:../login');
}
?>
<script>
	const Printcol = [0,1,2,3];
	var title = '<img src="../assets/img/logo.jpg" width="170"><h4 class="page-title text-center"><?php  echo $head_title1 = ucwords(substr(strstr(str_replace("_", " ", $head_title)," "), 1));  ?>s Report</h4>';
</script>
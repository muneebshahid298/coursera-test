		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<!-- Card -->
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="card-head-row">
										<button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-success"><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Add Account</button>
									</div>

									<!-- Modal -->
									<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                   <div class="modal-dialog" role="document">
                     <div class="modal-content">
                       <div class="modal-header">
                         <h5 class="modal-title" id="exampleModalLabel">Add Account</h5>
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                       <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                        <div class="modal-body">
                         <div class="row px-1">
                          <div class="form-group col-md-12">
                              <label for="profile_img">Account Name</label>
                              <input type="text" name="acc_name" class="form-control" data-required="true" required="required">
                          </div>
                          <div class="form-group col-md-12">
                            <label for="acc_type">Account Type</label>
                            <select class="form-control" name="acc_type" id="acc_type" data-required="true" required="required" autofocus autocomplete="off">
                              <option value disabled selected>-----Select Type-----</option>
                              <option value='income'>Income</option>
                              <option value='other income'>Other Income</option>
                              <option value='expense'>Expense</option>
                              <option value='other expense'>Other Expense</option>
                              <option value='cost of sales'>Cost of Sales</option>
                              <option value='asset'>Asset</option>
                              <option value='liability'>Liability</option>

                            </select>
                          </div>

                        </div>

                      </div>
                      <div class="modal-footer">
                        <button type="submit" id="submitaccount" name="submitaccount" class="btn btn-success"><span class="btn-label"><i class="fa fa-spinner"></i></span> Submit</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <button id="updateaccount1" type="button" data-toggle="modal" data-target="#exampleModal1" class="btn btn-success" hidden><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Update Account</button>

              <!-- Modal -->
              <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
               <div class="modal-dialog" role="document">
                 <div class="modal-content">
                   <div class="modal-header">
                     <h5 class="modal-title modal-head" id="exampleModalLabel1">Update Account</h5>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                       <span aria-hidden="true">&times;</span>
                     </button>
                   </div>
                   <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                    <div class="modal-body updateaccount">

                    </div>
                    <div class="modal-footer">
                      <button type="submit" id="updateaccount" name="updateaccount" class="btn btn-success"><span class="btn-label"><i class="fa fa-spinner"></i></span> Update</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="card-body">
            <table id="example" class="table table-striped table-bordered" style="width:100%">
              <thead>
                <tr>
                  <th>S/No</th>
                  <th>Name</th>
                  <th>Type</th>
                  <th>Options</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $sr = 1;
                foreach ($res_data_ex as $row) {
                  ?>
                  <tr id="<?php echo $row['acc_id']; ?>">
                    <?php 
                    echo "<td>".$sr."</td><td>".ucwords($row['acc_name'])."</td><td>".ucwords($row['acc_type'])."<input type='hidden' id='id-account' value='".$row['acc_id']."'></td>";
                    ?>
                    <td><button class="btn btn-info btn-edit" style="padding: 4px 4px; border-radius: 3px;"><i class="ml-1 fa fa-edit fa-lg" aria-hidden="true"></i></button> &nbsp;<button class="btn btn-danger btn-del" title="Remove"  style="padding: 4px 4px; border-radius: 3px;" onclick="del(delA,<?php echo $row['acc_id']; ?>);"><i class="ml-1 fa fa-trash fa-lg" aria-hidden="true"></i></button></td>
                  </tr>
                  <?php 
                  $sr++;
                }?>
              </tbody>
              <tfoot>
                <tr>
                  <th>S/No</th>
                  <th>Name</th>
                  <th>Type</th>
                  <th>Options</th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script>
	const Printcol = [0,1,2,3,4];
  var title = '<img src="../assets/img/logo.jpg" width="170"><h4 class="page-title text-center"><?php  echo $head_title1 = ucwords(substr(strstr(str_replace("_", " ", $head_title)," "), 1));  ?>s Report</h4>';

  $(document).ready(function(){
    $('.btn-edit').click(function(e){
     $('.modal-head').text('Update Account');
     e.preventDefault();
     var iduser = $(this).closest("tr").find("#id-account").val();
     $.ajax({
      type: "POST",
      url: "models/account_edit.php",
      data:'account_edit='+iduser,
      success: function(data){
        $(".updateaccount").html(data);
        $('#updateaccount1').trigger('click');
      }
    });
   });
  });
  function delA(idacc) {
    var idacc = idacc;
    $.ajax({
      type:"POST",
      url:"models/account_edit.php",
      data: 'account_del='+idacc,
      success:function(data) {
        var rowh = "#"+idacc;
        $(rowh).remove();
        Swal.fire(
          'Deleted!',
          'Record has been deleted.',
          'success'
          )
      }
    });
  }
  function userloginnamechk(){
    var userloginnamechk = document.getElementById('userloginname').value;

    $.ajax({
      type: "POST",
      url: "models/add_staff.php",
      data:'same_chk2='+userloginnamechk,
      success: function(data){
        if (data == true) {
          $('#alert_msg2').empty();
          $('#submitclient').attr('disabled', false);
          $('#useremail').attr('disabled', false);
          $('#empNo').attr('disabled', false);
        }
        else{
          $('#alert_msg2').empty();
          $('#alert_msg2').html(data);
          $('#submitclient').attr('disabled', true);
          $('#useremail').attr('disabled', true);
          $('#empNo').attr('disabled', true);
        }     
      }
    });
  }

  function useremailchk(){
    var useremailchk = document.getElementById('useremail').value;

    $.ajax({
      type: "POST",
      url: "models/add_staff.php",
      data:'same_chk4='+useremailchk,
      success: function(data){
        if (data == true) {
          $('#alert_msg4').empty();
          $('#submitclient').attr('disabled', false);
          $('#empNo').attr('disabled', false);
          $('#userloginname').attr('disabled', false);
        }
        else{
          $('#alert_msg4').empty();
          $('#alert_msg4').html(data);
          $('#submitclient').attr('disabled', true);
          $('#empNo').attr('disabled', true);
          $('#userloginname').attr('disabled', true);
        }     
      }
    });
  }


     $('.btn-det').click(function(e){
      e.preventDefault();
      var idclient = $(this).closest("tr").find("#id-client").val();
      //alert(idclient);
        location.href = "client_details?client_id="+idclient;
    });
</script>
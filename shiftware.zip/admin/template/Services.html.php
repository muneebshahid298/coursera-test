    <div class="main-panel">
      <div class="content">
        <div class="page-inner">
          <!-- Card -->
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header">
                  <div class="card-head-row float-right">
                    <button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-customs"><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Add Service</button>
                  </div>

                  <!-- Modal -->
                  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                   <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                     <div class="modal-content">
                      <div class="modal-header">
                        <h3 class="model-title">Add Service</h3><button type="button" class="close" data-dismiss="modal">&times;</button> <br>
                      </div>
                      <div class="modal-body">
                        <form action="" method="post" enctype="multipart/form-data" class="was-validated">
                          <fieldset class="scheduler-border">
                            <legend class="scheduler-border">
                              Service Name <span class="req-data">*</span>
                            </legend>
                            <div class="row">
                             <div class="form-group col-md-12">
                              <label>Service <span class="req-data text-danger">*</span></label>
                              <input type="text" class="form-control" name="service_name" id="service_name" data-required="true" required="required" autocomplete="off" onkeyup="service_name_checking();">
                            </div>
                            <div id="already-msg" class="form-group col-md-12"></div>
                          </div>
                        </fieldset>
                        <div class="modal-footer">
                          <button type="submit" id="submitp" name="submitp" class="btn btn-customs"><span class="btn-label"><i class="fa fa-spinner"></i></span> Submit</button>
                        </div>
                      </form>
                    </div>    
                  </div> 
                </div>
              </div>





              <button id="updateUser1" type="button" data-toggle="modal" data-target="#exampleModal1" class="btn btn-success" hidden><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Update Service</button>

              <!-- Modal -->
              <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                 <div class="modal-content">
                   <div class="modal-header">
                     <h3 class="modal-title modal-head" id="exampleModalLabel1">Update Service</h3>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                       <span aria-hidden="true">&times;</span>
                     </button>
                   </div>
                   <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                    <div class="modal-body updateuser">

                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>



          <div class="card-body">
            <table id="example" class="table table-striped table-bordered text-center" style="width:100%"> 
              <thead >
                <tr>
                  <th>Sr No.</th>
                  <th>Service</th>
                  <th>Option</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $res_data = select("services",$con);
                $sr = 1;
                foreach ($res_data as $row) {
                  ?>
                  <tr id="<?php echo $row['ser_id']; ?>">
                    <?php 
                    echo "<td>".$sr."</td><td>".ucwords($row['service_name'])."<input type='hidden' id='id-ser' value='".$row['ser_id']."'></td>";
                    ?>
                    <td><button class="btn btn-info btn-edit" style="padding: 9px 5px; border-radius: 3px;"><i class="fa fa-edit fa-lg" aria-hidden="true"></i></button> &nbsp;<button class="btn btn-danger btn-del" title="Remove"  style="padding: 9px 5px; border-radius: 3px;" onclick="del(delC,<?php echo $row['ser_id']; ?>);"><i class="fa fa-trash fa-lg" aria-hidden="true"></i></button></td>
                  </tr>
                  <?php 
                  $sr++;
                }?>
              </tbody>
              <thead >
                <tr>
                  <th>Sr No.</th>
                  <th>Service</th>
                  <th>Option</th>
                </tr>
              </thead>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script type="text/javascript">
  const Printcol = [0,1,2,3,4];
  var title = '<img src="../assets/img/logo.jpg" width="170"><h4 class="page-title text-center"><?php  echo $head_title1 = ucwords(substr(strstr(str_replace("_", " ", $head_title)," "), 1));  ?>s Report</h4>';
  $(document).ready(function(){
    $('.btn-edit').click(function(e){
      e.preventDefault();
      var idcus = $(this).closest("tr").find("#id-ser").val();
      // alert(idcus);
      $.ajax({
        type: "POST",
        url: "models/services.php",
        data:'service_edit='+idcus,
        success: function(data){
          $(".updateuser").html(data);
          $('#updateUser1').trigger('click');  
          // alert(data);
        }
      });
    });
  });


  function delC(idcus) {
    var idcus = idcus;
    $.ajax({
      type:"POST",
      url:"models/services.php",
      data: 'service_del='+idcus,
      success:function(data) {
        var rowh = "#"+idcus;
        $(rowh).remove();
        Swal.fire(
          'Deleted!',
          'Record has been deleted.',
          'success'
          )
      }
    });
  }

  function service_name_checking(){
    var val1 = document.getElementById('service_name').value;
     //alert(val1);
     if (val1 != "") {
      $.ajax({
        type: "POST",
        url: "models/services.php",
        data: {service_name_chk:val1,},
        success: function(data){
          //alert(data);
          if (data == "") {
            $('#submitp').attr('disabled', false);
            $('#already-msg').empty();
          }
          else{
            $('#submitp').attr('disabled', true);
            $('#already-msg').html("<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>Service Name</strong> Already Exists!</div>");
          }     
        }
      });
    }
  }



  function service_name_checking_u(){
    var val1 = document.getElementById('service_name_u').value;
    /* alert(val1);*/
    if (val1 != "") {
      $.ajax({
        type: "POST",
        url: "models/services.php",
        data: {service_name_chk:val1,},
        success: function(data){
          /*alert(data);*/
          if (data == "") {
            $('#updatep').attr('disabled', false);
            $('#already-msg-u').empty();
          }
          else{
            $('#updatep').attr('disabled', true);
            $('#already-msg-u').html("<div class='alert alert-danger text-danger' style = 'text-align : center;'><strong>Service Name</strong> Already Exists!</div>");
          }     
        }
      });
    }
  }
</script>
		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<!-- Card -->
					<div class="row">
						<div class="col-md-12">
							<div class="card">
	
          <div class="card-body" style="overflow-x: scroll;">
            <table id="example" class="table table-striped table-bordered" style="width:100%; overflow-x: scroll;">
              <thead>
                <tr>
                  <th colspan="1" rowspan="2" class="text-center">S/No</th>
                  <th colspan="1" rowspan="2" class="text-center">Name</th>
                  <th colspan="3" class="text-center">Daily</th>
                  <th colspan="3" class="text-center">Weekly</th>
                  <th colspan="3" class="text-center">Monthly</th>
                </tr>
                <tr>
                  <th>hours</th>
                  <th>Milage</th>
                  <th>Expenses</th>
                  <th>hours</th>
                  <th>Milage</th>
                  <th>Expenses</th>
                  <th>hours</th>
                  <th>Milage</th>
                  <th>Expenses</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $sr = 1;
                foreach ($res_data_ex as $row) {
                  ?>
                  <tr>
                    <td><?php echo $sr ?></td>
                    <td><?php echo ucwords($row['f_name']." ".$row['l_name']) ?></td>
                    <?php
                    if ($row['s_recurrance'] == 'daily') {
                    ?>
                      <td><?php echo $row['SUM(sd_hour)'] ?></td>
                      <td><?php echo $row['SUM(sd_milage)'] ?></td>
                      <td><?php echo $row['SUM(sd_expense)'] ?></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                    <?php
                    }
                    elseif ($row['s_recurrance'] == 'weekly') {
                    ?>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td><?php echo $row['SUM(sd_hour)'] ?></td>
                      <td><?php echo $row['SUM(sd_milage)'] ?></td>
                      <td><?php echo $row['SUM(sd_expense)'] ?></td>
                      <td></td>
                      <td></td>
                      <td></td>
                    <?php
                    }
                    elseif ($row['s_recurrance'] == 'monthly') {
                    ?>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td><?php echo $row['SUM(sd_hour)'] ?></td>
                      <td><?php echo $row['SUM(sd_milage)'] ?></td>
                      <td><?php echo $row['SUM(sd_expense)'] ?></td>
                    <?php
                    }
                    else{
                    ?>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                    <?php
                    }
                    ?>
                  </tr>
                  <?php 
                  $sr++;
                }?>
              </tbody>
              <tfoot>
                <tr>
                  <th colspan="1" rowspan="2" class="text-center">S/No</th>
                  <th colspan="1" rowspan="2" class="text-center">Name</th>
                  <th colspan="3" class="text-center">Daily</th>
                  <th colspan="3" class="text-center">Weekly</th>
                  <th colspan="3" class="text-center">Monthly</th>
                </tr>
                <tr>
                  <th>hours</th>
                  <th>Milage</th>
                  <th>Expenses</th>
                  <th>hours</th>
                  <th>Milage</th>
                  <th>Expenses</th>
                  <th>hours</th>
                  <th>Milage</th>
                  <th>Expenses</th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <div class="card-head-row">
              <div class="card-title">Accepted And Pending Shifts Ratio</div>
            </div>
          </div>
          <div class="card-body">
            <div class="chart-container" style="min-height: 375px">
              <canvas id="pieChart"></canvas>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script>
	const Printcol = [0,1,2,3,4];
  var title = '<img src="../assets/img/logo.jpg" width="170"><h4 class="page-title text-center"><?php  echo $head_title1 = ucwords(substr(strstr(str_replace("_", " ", $head_title)," "), 1));  ?></h4>';
</script>
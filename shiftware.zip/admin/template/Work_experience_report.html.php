		<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
    <div class="main-panel">
     <div class="content">
      <div class="page-inner pt-1">
     

      <!--///////////////////////////////////////////////////////////////////// -->
     

    <div class="row">
        <div class="col-md-12">
          <form action="" method="get" enctype="multipart/form-data">
            <div class="row">
             <div class="form-group col-md-3 pl-3 py-0">
              <select class="form-control" name="shift_type" data-required="true" autocomplete="off" required="required">
                <option selected="" value="staff">Staff</option>
                <option value="client">Clients</option>
              </select>
            </div>
            <div class="form-group col-md-3 py-0">
              <input  id="sdate" value="" class="form-control" size="16" type="date" name="s_shift_date" autocomplete="off">
            </div>
            <div class="form-group col-md-3 py-0">
              <input  id="edate" value="" class="form-control" size="16" type="date" name="e_end_date" min="" autocomplete="off">
            </div>
            <div class="form-group col-md-2 py-0">
              <input id="btn1" type="submit" name="search" class="btn btn-danger" value="Search">
            </div>
          </div>
        </form>
      </div>
    </div>


    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header py-1">
            <div class="card-head-row">
              <div class="card-title">Activities</div>
            </div>
          </div>
          <div class="card-body">
            <div class="card-body py-0">
              <div class="row">
                <div class="col-md-9">
                  <canvas id="second_chart" height="100px"></canvas>
                </div>
                <div class="col-md-3">
                  <canvas id="pieChart2"></canvas>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div> 




    <!--     ///////////////////////////////////////////////////////////////////////////////////////// -->

  
  <?php
  if (isset($_GET['shift_type'])) {
    $shift_type = $_GET['shift_type'];
    $s_date = $_GET['s_shift_date'];
    $e_date = $_GET['e_end_date'];
    if ($shift_type == 'client' && $s_date == null && $e_date == null) {
    ?>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header py-1">
              <div class="card-head-row">
                <div class="card-title">Details</div>
              </div>
            </div>
            <div class="card-body py-0">

               <table class="table table-bordered" id="example">
                <thead>
                  <tr>
                    <th>Client</th>
                    <th>Completed</th>
                    <th>Pending</th>
                    <th>Cancelled</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $db->Select('*');
                  $db->From("client");
                  $db->Where("close = '1' AND status = '1'");
                  $rese_data_ex = $db->result();
                  foreach ($rese_data_ex as $row) {
                    $client_id = $row['c_id'];
                    ?>
                    <tr>
                      <td><?php echo $row['m_name']; ?></td>
                      <?php 
                      $db->Select('COUNT(*)');
                      $db->From("shifts");
                      $db->Join("shift_dates");
                      $db->ON("shifts.s_id","shift_dates.sd_s_id");
                      $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_client = '".$client_id."' AND shift_dates.sd_complete = '2' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                      $rese_data1_ex = $db->result();
                      foreach ($rese_data1_ex as $row1) {
                        $complete = $row1['COUNT(*)'];
                        ?>
                        <td> <?php echo $complete; ?> </td>
                      <?php }  
                      $db->Select('COUNT(*)');
                      $db->From("shifts");
                      $db->Join("shift_dates");
                      $db->ON("shifts.s_id","shift_dates.sd_s_id");
                      $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_client = '".$client_id."' AND shift_dates.sd_complete = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                      $rese_data2_ex = $db->result();
                      foreach ($rese_data2_ex as $row2) {
                        $pending = $row2['COUNT(*)'];
                        ?>
                        <td> <?php echo $pending; ?> </td>
                      <?php }
                      $db->Select('COUNT(*)');
                      $db->From("shifts");
                      $db->Join("shift_dates");
                      $db->ON("shifts.s_id","shift_dates.sd_s_id");
                      $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_client = '".$client_id."' AND shift_dates.sd_reject = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                      $rese_data3_ex = $db->result();
                      foreach ($rese_data3_ex as $row3) {
                        $cancel = $row3['COUNT(*)'];
                        ?>
                        <td> <?php echo $cancel; ?> </td>
                      <?php } ?> 
                    </tr>
                    <?php 
                  } 
                  ?>

                </tbody>
              </table>
          </div>
        </div>
      </div>
    </div>
    <?php
    }
    elseif ($shift_type == 'client' && $s_date != null && $e_date != null) {
    ?>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header py-1">
              <div class="card-head-row">
                <div class="card-title">Details</div>
              </div>
            </div>
            <div class="card-body py-0">

               <table class="table table-bordered" id="example">
                <thead>
                  <tr>
                    <th>Client</th>
                    <th>Completed</th>
                    <th>Pending</th>
                    <th>Cancelled</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $db->Select('*');
                  $db->From("client");
                  $db->Where("close = '1' AND status = '1'");
                  $rese_data_ex = $db->result();
                  foreach ($rese_data_ex as $row) {
                    $client_id = $row['c_id'];
                    ?>
                    <tr>
                      <td><?php echo $row['m_name']; ?></td>
                      <?php 
                      $db->Select('COUNT(*)');
                      $db->From("shifts");
                      $db->Join("shift_dates");
                      $db->ON("shifts.s_id","shift_dates.sd_s_id");
                      $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_client = '".$client_id."' AND shift_dates.sd_date BETWEEN '".$s_date."' AND '".$e_date."' AND shift_dates.sd_complete = '2' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                      $rese_data1_ex = $db->result();
                      foreach ($rese_data1_ex as $row1) {
                        $complete = $row1['COUNT(*)'];
                        ?>
                        <td> <?php echo $complete; ?> </td>
                      <?php }  
                      $db->Select('COUNT(*)');
                      $db->From("shifts");
                      $db->Join("shift_dates");
                      $db->ON("shifts.s_id","shift_dates.sd_s_id");
                      $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_client = '".$client_id."' AND shift_dates.sd_date BETWEEN '".$s_date."' AND '".$e_date."' AND shift_dates.sd_complete = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                      $rese_data2_ex = $db->result();
                      foreach ($rese_data2_ex as $row2) {
                        $pending = $row2['COUNT(*)'];
                        ?>
                        <td> <?php echo $pending; ?> </td>
                      <?php }
                      $db->Select('COUNT(*)');
                      $db->From("shifts");
                      $db->Join("shift_dates");
                      $db->ON("shifts.s_id","shift_dates.sd_s_id");
                      $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_client = '".$client_id."' AND shift_dates.sd_date BETWEEN '".$s_date."' AND '".$e_date."' AND shift_dates.sd_reject = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                      $rese_data3_ex = $db->result();
                      foreach ($rese_data3_ex as $row3) {
                        $cancel = $row3['COUNT(*)'];
                        ?>
                        <td> <?php echo $cancel; ?> </td>
                      <?php } ?> 
                    </tr>
                    <?php 
                  } 
                  ?>

                </tbody>
              </table>
          </div>
        </div>
      </div>
    </div>
    <?php
    }
    elseif ($shift_type == 'staff' && $s_date == null && $e_date == null) {
    ?>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header py-1">
              <div class="card-head-row">
                <div class="card-title">Details</div>
              </div>
            </div>
            <div class="card-body py-0">

               <table class="table table-bordered" id="example">
                <thead>
                  <tr>
                    <th>Staff</th>
                    <th>Completed</th>
                    <th>Pending</th>
                    <th>Cancelled</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $db->Select('*');
                  $db->From("wt_users");
                  $db->Where("close = '1' AND status = '1' AND user_type = 'staff'");
                  $rese_data_ex = $db->result();
                  foreach ($rese_data_ex as $row) {
                    $staff_id = $row['id'];
                    ?>
                    <tr>
                      <td><?php echo $row['f_name']." ".$row['l_name']; ?></td>
                      <?php 
                      $db->Select('COUNT(*)');
                      $db->From("shifts");
                      $db->Join("shift_dates");
                      $db->ON("shifts.s_id","shift_dates.sd_s_id");
                      $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_staff = '".$staff_id."' AND shift_dates.sd_complete = '2' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                      $rese_data1_ex = $db->result();
                      foreach ($rese_data1_ex as $row1) {
                        $complete = $row1['COUNT(*)'];
                        ?>
                        <td> <?php echo $complete; ?> </td>
                      <?php }  
                      $db->Select('COUNT(*)');
                      $db->From("shifts");
                      $db->Join("shift_dates");
                      $db->ON("shifts.s_id","shift_dates.sd_s_id");
                      $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_staff = '".$staff_id."' AND shift_dates.sd_complete = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                      $rese_data2_ex = $db->result();
                      foreach ($rese_data2_ex as $row2) {
                        $pending = $row2['COUNT(*)'];
                        ?>
                        <td> <?php echo $pending; ?> </td>
                      <?php }
                      $db->Select('COUNT(*)');
                      $db->From("shifts");
                      $db->Join("shift_dates");
                      $db->ON("shifts.s_id","shift_dates.sd_s_id");
                      $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_staff = '".$staff_id."' AND shift_dates.sd_reject = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                      $rese_data3_ex = $db->result();
                      foreach ($rese_data3_ex as $row3) {
                        $cancel = $row3['COUNT(*)'];
                        ?>
                        <td> <?php echo $cancel; ?> </td>
                      <?php } ?> 
                    </tr>
                    <?php 
                  } 
                  ?>

                </tbody>
              </table>
          </div>
        </div>
      </div>
    </div>
    <?php
    }
    elseif ($shift_type == 'staff' && $s_date != null && $e_date != null) {
    ?>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header py-1">
              <div class="card-head-row">
                <div class="card-title">Details</div>
              </div>
            </div>
            <div class="card-body py-0">

               <table class="table table-bordered" id="example">
                <thead>
                  <tr>
                    <th>Staff</th>
                    <th>Completed</th>
                    <th>Pending</th>
                    <th>Cancelled</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $db->Select('*');
                  $db->From("wt_users");
                  $db->Where("close = '1' AND status = '1' AND user_type = 'staff'");
                  $rese_data_ex = $db->result();
                  foreach ($rese_data_ex as $row) {
                    $staff_id = $row['id'];
                    ?>
                    <tr>
                      <td><?php echo $row['f_name']." ".$row['l_name']; ?></td>
                      <?php 
                      $db->Select('COUNT(*)');
                      $db->From("shifts");
                      $db->Join("shift_dates");
                      $db->ON("shifts.s_id","shift_dates.sd_s_id");
                      $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_staff = '".$staff_id."' AND shift_dates.sd_date BETWEEN '".$s_date."' AND '".$e_date."' AND shift_dates.sd_complete = '2' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                      $rese_data1_ex = $db->result();
                      foreach ($rese_data1_ex as $row1) {
                        $complete = $row1['COUNT(*)'];
                        ?>
                        <td> <?php echo $complete; ?> </td>
                      <?php }  
                      $db->Select('COUNT(*)');
                      $db->From("shifts");
                      $db->Join("shift_dates");
                      $db->ON("shifts.s_id","shift_dates.sd_s_id");
                      $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_staff = '".$staff_id."' AND shift_dates.sd_date BETWEEN '".$s_date."' AND '".$e_date."' AND shift_dates.sd_complete = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                      $rese_data2_ex = $db->result();
                      foreach ($rese_data2_ex as $row2) {
                        $pending = $row2['COUNT(*)'];
                        ?>
                        <td> <?php echo $pending; ?> </td>
                      <?php }
                      $db->Select('COUNT(*)');
                      $db->From("shifts");
                      $db->Join("shift_dates");
                      $db->ON("shifts.s_id","shift_dates.sd_s_id");
                      $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_staff = '".$staff_id."' AND shift_dates.sd_date BETWEEN '".$s_date."' AND '".$e_date."' AND shift_dates.sd_reject = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                      $rese_data3_ex = $db->result();
                      foreach ($rese_data3_ex as $row3) {
                        $cancel = $row3['COUNT(*)'];
                        ?>
                        <td> <?php echo $cancel; ?> </td>
                      <?php } ?> 
                    </tr>
                    <?php 
                  } 
                  ?>

                </tbody>
              </table>
          </div>
        </div>
      </div>
    </div>
    <?php
    }
  }
  else{
  ?>
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header py-1">
          <div class="card-head-row">
            <div class="card-title">Details</div>
          </div>
        </div>
        <div class="card-body py-0 pt-1">

           <table class="table table-bordered" id="example">
            <thead>
              <tr>
                <th>Staff</th>
                <th>Completed</th>
                <th>Pending</th>
                <th>Cancelled</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $db->Select('*');
              $db->From("wt_users");
              $db->Where("close = '1' AND status = '1' AND user_type = 'staff' ");
              $rese_data_ex = $db->result();
              foreach ($rese_data_ex as $row) {
                $staff_id = $row['id'];
                ?>
                <tr>
                  <td><?php echo $row['f_name']." ".$row['l_name']; ?></td>
                  <?php 
                  $db->Select('COUNT(*)');
                  $db->From("shifts");
                  $db->Join("shift_dates");
                  $db->ON("shifts.s_id","shift_dates.sd_s_id");
                  $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_staff = '".$staff_id."' AND shift_dates.sd_complete = '2' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                  $rese_data1_ex = $db->result();
                  foreach ($rese_data1_ex as $row1) {
                    $complete = $row1['COUNT(*)'];
                    ?>
                    <td> <?php echo $complete; ?> </td>
                  <?php }  
                  $db->Select('COUNT(*)');
                  $db->From("shifts");
                  $db->Join("shift_dates");
                  $db->ON("shifts.s_id","shift_dates.sd_s_id");
                  $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_staff = '".$staff_id."' AND shift_dates.sd_complete = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                  $rese_data2_ex = $db->result();
                  foreach ($rese_data2_ex as $row2) {
                    $pending = $row2['COUNT(*)'];
                    ?>
                    <td> <?php echo $pending; ?> </td>
                  <?php }
                  $db->Select('COUNT(*)');
                  $db->From("shifts");
                  $db->Join("shift_dates");
                  $db->ON("shifts.s_id","shift_dates.sd_s_id");
                  $db->Where("shifts.close = '1' AND shifts.status = '1' AND shifts.s_staff = '".$staff_id."' AND shift_dates.sd_reject = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'");
                  $rese_data3_ex = $db->result();
                  foreach ($rese_data3_ex as $row3) {
                    $cancel = $row3['COUNT(*)'];
                    ?>
                    <td> <?php echo $cancel; ?> </td>
                  <?php } ?> 
                </tr>
                <?php 
              } 
              ?>

            </tbody>
          </table>
      </div>
    </div>
  </div>
</div>
<?php
}
?>


</div>
</div>
</div>
<script>
	const Printcol = [0,1,2,3,4];
  var title = '<img src="../assets/img/logo.jpg" width="170"><h4 class="page-title text-center"><?php  echo $head_title1 = ucwords(substr(strstr(str_replace("_", " ", $head_title)," "), 1));  ?></h4>';
</script>

<script type="text/javascript">
  var ctxL = document.getElementById("second_chart").getContext('2d');

  var barColors = [
  "#E79495",
  "#ED9347",
  "#9BCD9A",
  "#00aba9",
  "#000000"
  ];
  var myLineChart = new Chart(ctxL, {
    type: 'line',
    data: {<?php
      $current_year = date("Y");
      $current_month = date("m");
      $days_in_month = cal_days_in_month(CAL_GREGORIAN,$current_month,$current_year);
      ?>
      labels: [<?php
        $mon = [];
        $year = [];
        $output1 = [];
        $date1 = $current_year.'-'.$current_month.'-01';
        $date2 = $current_year.'-'.$current_month.'-'.$d;
        $output = [];
        $time   = strtotime($date1);
        $last   = date('d-m-Y', strtotime($date2));
        do {
          $day = date('d-m-Y', $time);
          $total = date('t', $time);
          $output[] = "'".$day."'".",";
          $output1[] = "'".$day."'".",";
          $time = strtotime('+1 day', $time);
        } while ($day != $last);
        echo implode(" ", $output);
        ?>],
        datasets: [{
          label: "Cancelled",
          data: [<?php
            for ($i=1; $i <= $d; $i++) { 
              $select_query = "SELECT COUNT(*),month(sd_date) from shift_dates WHERE day(sd_date) = '".$i."' AND month(sd_date) = '".$current_month."' AND year(sd_date) = '".$current_year."' AND status = '1' AND close='1' AND sd_reject = '1' GROUP BY month(sd_date),year(sd_date)";
              $select_query_ex = mysqli_query($con,$select_query);
              if (mysqli_num_rows($select_query_ex) != 0) {
                foreach($select_query_ex as $cancel){
                  echo $cancel['COUNT(*)'].",";
                }
              }
              else{
                echo "0,";
              }
            }
            ?>],
            backgroundColor: ['#E79495',],
            borderColor: ['#b7000f',],
          },
          {
            label: "Pending",
            data: [<?php
              for ($i=1; $i <= $d; $i++) { 
                $select_query1 = "SELECT COUNT(*),month(sd_date) from shift_dates WHERE day(sd_date) = '".$i."' AND month(sd_date) = '".$current_month."' AND year(sd_date) = '".$current_year."' AND status = '1' AND close='1' AND sd_complete = '1' GROUP BY month(sd_date),year(sd_date)";
                $select_query1_ex = mysqli_query($con,$select_query1);
                if (mysqli_num_rows($select_query1_ex) != 0) {
                  foreach($select_query1_ex as $pending){
                    echo $pending['COUNT(*)'].",";
                  }
                }
                else{
                  echo "0,";
                }
              }
              ?>],
              backgroundColor: ['#ED9347',],
              borderColor: ['#87201E',],
            },
            {
              label: "Completed",
              data: [<?php
                for ($i=1; $i <= $d; $i++) { 
                  $select_query1 = "SELECT COUNT(*),month(sd_date) from shift_dates WHERE day(sd_date) = '".$i."' AND month(sd_date) = '".$current_month."' AND year(sd_date) = '".$current_year."' AND status = '1' AND close='1' AND sd_complete = '2' GROUP BY month(sd_date),year(sd_date)";
                  $select_query1_ex = mysqli_query($con,$select_query1);
                  if (mysqli_num_rows($select_query1_ex) != 0) {
                    foreach($select_query1_ex as $complete){
                      echo $complete['COUNT(*)'].",";
                    }
                  }
                  else{
                    echo "0,";
                  }
                }
                ?>],
                backgroundColor: ['#9BCD9A',],
                borderColor: ['#082F1F',],
              }
              ]
            },
            options: {
              responsive: true
            }
          });
        </script>



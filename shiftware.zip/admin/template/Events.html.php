<style type="text/css">
  .md-event-listing-cont {
    position: relative;
    padding-left: 50px;
  }

  .md-event-listing-avatar {
    position: absolute;
    max-height: 50px;
    max-width: 50px;
    top: 21px;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    left: 20px;
  }

  .md-event-listing-name {
    font-size: 16px;
  }

  .md-event-listing-title {
    font-size: 12px;
    margin-top: 5px;
  }

  .md-event-listing .mbsc-segmented {
    max-width: 350px;
    margin: 0 auto;
    padding: 1px;
  }

  .md-event-listing-picker {
    flex: 1 0 auto;
  }

  .md-event-listing-nav {
    width: 200px;
  }

  /* material header order */

  .mbsc-material.md-event-listing-prev {
    order: 1;
  }

  .mbsc-material.md-event-listing-next {
    order: 2;
  }

  .mbsc-material.md-event-listing-nav {
    order: 3;
  }

  .mbsc-material .md-event-listing-picker {
    order: 4;
  }

  .mbsc-material .md-event-listing-today {
    order: 5;
  }

  /* windows header order */

  .mbsc-windows.md-event-listing-nav {
    order: 1;
  }

  .mbsc-windows.md-event-listing-prev {
    order: 2;
  }

  .mbsc-windows.md-event-listing-next {
    order: 3;
  }

  .mbsc-windows .md-event-listing-picker {
    order: 4;
  }

  .mbsc-windows .md-event-listing-today {
    order: 5;
  }


  .modal-dialog-slideout {min-height: 100%; margin: 0 0 0 auto;background: #fff;}
  .modal.fade .modal-dialog.modal-dialog-slideout {-webkit-transform: translate(100%,0)scale(1);transform: translate(100%,0)scale(1);}
  .modal.fade.show .modal-dialog.modal-dialog-slideout {-webkit-transform: translate(0,0);transform: translate(0,0);display: flex;align-items: stretch;-webkit-box-align: stretch;}
  .modal.fade.show .modal-dialog.modal-dialog-slideout .modal-body{overflow-y: auto;overflow-x: hidden;}
  .modal-dialog-slideout .modal-content{border: 0;}
  .modal-dialog-slideout .modal-header, .modal-dialog-slideout .modal-footer {height: 69px; display: block;} 
  .modal-dialog-slideout .modal-header h5 {float:left;}

</style>
<div class="main-panel">
  <div class="content">
    <div class="page-inner">
      <!-- Card -->
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <div class="card-head-row float-right">
                <button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-success"><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Add Event</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal -->
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
       <div class="modal-dialog" role="document">
         <div class="modal-content">
           <div class="modal-header">
             <h5 class="modal-title" id="exampleModalLabel">Add Client</h5>
             <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
             </button>
           </div>
           <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
            <div class="modal-body">
             <div class="row">
               <div class="form-group col-md-12">
                <label>Event</label>
                <input type="text" id="event_name" name="event_name" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
              </div> 
              <div class="form-group col-md-12">
                <label>Event Date</label>
                <input type="date" id="event_date" name="event_date" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off">
              </div> 
            </div>

          </div>
          <div class="modal-footer">
            <button type="submit" id="submitevent" name="submitevent" class="btn btn-success"><span class="btn-label"><i class="fa fa-spinner"></i></span> Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <button class="btn btn-Success search green_back" style="float: right; border-radius: 3px;" data-toggle="modal" data-target="#shiftslot" id="shiftslot1" hidden>aaaaa</button>
  <div class="modal fade" id="shiftslot" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-light">
          <h4 class="modal-title">View Shifts</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body selected_start_time">

        </div>     
      </div>
    </div>
  </div>

  <button class="btn btn-Success search green_back" style="float: right; border-radius: 3px;" data-toggle="modal" data-target="#exampleModal1" id="updateShift1" hidden>aaaaa</button>
  <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-light">
          <h4 class="modal-title">Update Shift</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
          <div class="modal-body updateShift">

          </div>
        </form>     
      </div>
    </div>
  </div>

  <div class="card-body">
    <div id='calendar'></div>
            <!-- <div class="md-event-listing">
                <div id="demo-event-listing"></div>
              </div> -->
            </div>

          </div>
        </div>
      </div>

      <script type="text/javascript">
       function checkstaffleave() {
        var selectstaff = $("#selectstaff").val();
        var shiftdate = $("#shiftdate").val();
        $.ajax({
          type: "POST",
          url: "models/shifts_edit.php",
          data:{
           checkstaffleave:selectstaff,
           shiftdate:shiftdate
         },
         success: function(data){
          if (data == "true") {
            $('#staffleavewarning').empty();
          }
          else{
            $('#staffleavewarning').html("<div style='background:#f8d7da; padding-top:2%;' class='form-group col-md-12'><p class='col-md-12 text-center' style='color: #C82333; font-weight:bolder;'>"+data+"</p></div>");
          } 
        }
      });
      }

      function checkrepeat() {
        var repeat_value = $("#repeat").val();
        if (repeat_value == 0) {
          $("#repeat").val(1);
          $("#repeat2").val(1);
          $("#repeatyes").show();
          $("#recurrance").attr('required',true);
        }
        else if (repeat_value == 1) {
          $("#repeat").val(0);
          $("#repeat2").val(0);
          $("#repeatyes").hide();
          $("#recurrance").attr('required',false);
        }
      }

      function checkrecurrance() {
        var recurrance_value = $("#recurrance").val();
        if (recurrance_value == 'daily') {
          $("#daily").show();
          $("#weekly").hide();
          $("#monthly").hide();
        }
        else if (recurrance_value == 'weekly') {
          $("#daily").hide();
          $("#weekly").show();
          $("#monthly").hide();
        }
        else if (recurrance_value == 'monthly') {
          $("#daily").hide();
          $("#weekly").hide();
          $("#monthly").show();
        }
        $("#end").show();
      }

      function checkday(id) {
        var value = $("#"+id).val();
        if (value == '0') {
          $("#"+id).val('1');
        }
        else if (value == '1') {
          $("#"+id).val('0');
        }
      }

      function checkfinishnextday() {
        var val = $("#finish_next_day").val();
        if (val == '0') {
          $("#finish_next_day").val('1');
          $("#finish_next_day2").val('1');
        }
        else if (val == '1') {
          $("#finish_next_day").val('0');
          $("#finish_next_day2").val('0');
        }
      }

      function checkopenshift(val) {
        if (val == '0') {
          $("#open_shift").val('1');
          $("#selectstaff").attr("multiple", true);
          $("#selectstaff option[disabled]").attr("selected", false);
        }
        else if (val == '1') {
          $("#open_shift").val('0');
          $("#selectstaff").attr("multiple", false);
          $("#selectstaff option[disabled]").attr("selected", true);
        }
      }

      function checkopenshift_up(val) {
        if (val == '0') {
          $("#open_shift_up").val('1');
          $("#selectstaff_up").attr("multiple", true);
          $("#selectstaff_up option[disabled]").attr("selected", false);
        }
        else if (val == '1') {
          $("#open_shift_up").val('0');
          $("#selectstaff_up").attr("multiple", false);
          $("#selectstaff_up option[disabled]").attr("selected", true);
        }
      }

      function edit_event(idevent) {
        $.ajax({
          type: "POST",
          url: "models/add_events.php",
          data:'event_edit='+idevent,
          success: function(data){
            $(".updateShift").html(data);
            $('#updateShift1').trigger('click');
          }
        });
      }

      function delS(idshift) {
        var idshift = idshift;
        //alert(idshift);
        $.ajax({
          type:"POST",
          url:"models/add_events.php",
          data: 'event_del='+idshift,
          success:function(data) {
            var rowh = "#"+idshift;
            $(rowh).remove();
            Swal.fire(
              'Deleted!',
              'Record has been deleted.',
              'success'
              )
            setTimeout(function(){
              location.reload();
            },1000);
            // alert(data);
          }
        });
      }

      function add_shift() {
        $('#shiftslot1').trigger('click');
      }
    </script>

    <?php
    $select_event = "SELECT * FROM events WHERE close = '1' AND status = '1'";
    $select_event_ex = mysqli_query($con, $select_event);
    $events = array();

    foreach ($select_event_ex as $row) {
      $event = array(
        'id' => $row['event_id'],
        'title' => $row['event_name'],
        'start' => $row['event_date'],
        'display' => 'block',
        'backgroundColor' => '#4BD78A'
      );

      $events[] = $event;
    }
    ?>

    <script>
      document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');

        var calendar = new FullCalendar.Calendar(calendarEl, {
          initialView: 'dayGridMonth',
          headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
          },
          navLinks: true,
          selectable: true,
          selectMirror: true,
          select: function(arg) {
            var eventdate = arg.start;
            var eventdate1 = new Date(eventdate);
            var eventdate2 = eventdate1.toLocaleDateString();
            // var eventID = <?php echo $row['event_id']; ?>;
            // alert(eventdate2);
            $.ajax({
              type: "POST",
              url: "models/add_events.php",
              data:'show_events='+eventdate2,
              success: function(data) {
                $(".selected_start_time").html(data);
                $('#shiftslot1').trigger('click');
              }
            });
          },
          editable: false,
          dayMaxEvents: true,
          events: <?php echo json_encode($events); ?>
        });

        calendar.render();
      });
    </script>

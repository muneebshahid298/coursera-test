		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<!-- Card -->
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									
                  <button id="updateUser1" type="button" data-toggle="modal" data-target="#exampleModal1" class="btn btn-success" hidden><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Update Staff</button>

                  <!-- Modal -->
                  <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
                   <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                     <div class="modal-content ">
                       <div class="modal-header">
                         <h5 class="modal-title modal-head" id="exampleModalLabel1">Update Staff</h5>
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                       <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                        <div class="modal-body updateuser">

                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-body">
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                  <thead>
                    <tr>
                      <th>S/No</th>
                      <th>Name</th>
                      <th>User Name</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $sr = 1;
                    foreach ($res_data_ex as $row) {
                      ?>
                      <tr id="<?php echo $row['id']; ?>">
                        <?php 
                        echo "<td>".$sr."</td><td>".ucwords($row['f_name']." ".$row['l_name'])."</td><td>".$row['user_name']."</td><td>".$row['email']."</td><td>".$row['phone']."<input type='hidden' id='id-staff' value='".$row['id']."'></td>";
                        ?>
                        <td><button class="btn btn-success btn-view" style="padding: 9px 5px; border-radius: 3px;"><i class="ml-1 fa fa-eye fa-lg" aria-hidden="true"></i></button> &nbsp;<button class="btn btn-info btn-edit" style="padding: 9px 5px; border-radius: 3px;"><i class="ml-1 fa fa-edit fa-lg" aria-hidden="true"></i></button> &nbsp;<button class="btn btn-danger btn-del" title="Remove"  style="padding: 9px 5px; border-radius: 3px;" onclick="del(delU,<?php echo $row['id']; ?>);"><i class="ml-1 fa fa-trash fa-lg" aria-hidden="true"></i></button>&nbsp;<button class="btn btn-primary btn-upload-doc" style="padding: 9px 5px; border-radius: 3px;"><i class="ml-1 fa fa-upload fa-lg" aria-hidden="true"></i></button>&nbsp;<button class="btn btn-dark btn-archive" title="archive"  style="padding: 9px 5px; border-radius: 3px;" onclick="archive(<?php echo $row['id']; ?>);"><i class="ml-1 fa fa-reply fa-lg" aria-hidden="true"></i></button></td>
                      </tr>
                      <?php 
                      $sr++;
                    }?>
                  </tbody>
                  <tfoot>
                    <tr>
                      <th>S/No</th>
                      <th>Name</th>
                      <th>User Name</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Options</th>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script>
   const Printcol = [0,1,2,3,4];
   var title = '<img src="../assets/img/logo.jpg" width="170"><h4 class="page-title text-center"><?php  echo $head_title1 = ucwords(substr(strstr(str_replace("_", " ", $head_title)," "), 1));  ?>s Report</h4>';
   $(document).ready(function(){
    $('.btn-edit').click(function(e){
     $('.modal-head').text('Update Staff');
     e.preventDefault();
     var iduser = $(this).closest("tr").find("#id-staff").val();
     $.ajax({
      type: "POST",
      url: "models/add_staff.php",
      data:'staff_edit='+iduser,
      success: function(data){
        $(".updateUser").html(data);
        $('#updateUser1').trigger('click');  
      }
    });
   });
    $('.btn-view').click(function(e){
     $('.modal-head').text('View Staff');
     e.preventDefault();
     var iduser = $(this).closest("tr").find("#id-staff").val();
     $.ajax({
      type: "POST",
      url: "models/add_staff.php",
      data:'staff_view='+iduser,
      success: function(data){
        $(".updateUser").html(data);
        $('#updateUser1').trigger('click');  
      }
    });
   });
    $('.btn-upload-doc').click(function(e){
     $('.modal-head').text('Upload Staff Documents');
     e.preventDefault();
     var iduser = $(this).closest("tr").find("#id-staff").val();
     $.ajax({
      type: "POST",
      url: "models/add_staff.php",
      data:'uploadstaffdoc='+iduser,
      success: function(data){
        $(".updateUser").html(data);
        $('#updateUser1').trigger('click');
      }
    });
   });
  });
   function delU(iduser) {
    var iduser = iduser;
    $.ajax({
      type:"POST",
      url:"models/add_staff.php",
      data: 'staff_del='+iduser,
      success:function(data) {
        var rowh = "#"+iduser;
        $(rowh).remove();
        Swal.fire(
          'Deleted!',
          'Record has been deleted.',
          'success'
          )
      }
    });
  }


  function archive(iduser) {
    var iduser = iduser;
    var status = '0';
    $.ajax({
      type:"POST",
      url:"models/add_staff.php",
      data:{
        staff_archive:iduser,
        archive_status:status
      },
      success:function(data) {
        var rowh = "#"+iduser;
        $(rowh).remove();
      }
    });
  }

</script>
<style type="text/css">
    :root {
  --darkgreen: white;
  --white: #fff;
}
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}
/*/Profile setting css/*/
.tabs-to-dropdown .nav-wrapper {
padding-top: 20px;
}
.tabs-to-dropdown .nav-wrapper a {
  color: var(--darkgreen);
}
.tabs-to-dropdown .nav-pills .nav-link.active {
  background-image: linear-gradient(to left, #83fcc3, #31D78A);
  color: #fff;
}
.tabs-to-dropdown .nav-pills .nav-link{
  background: #31D78A;
  color:#fff;
}
.tabs-to-dropdown .nav-pills li:not(:last-child) {
  margin-right: 5px;
  margin-bottom: 10px;
}
.tabs-to-dropdown .tab-content .container-fluid { 
  max-width: 1250px;
  padding-top: 30px;
}
.tabs-to-dropdown .dropdown-menu {
  border: none; 
}
.tabs-to-dropdown .dropdown-item:active {
  color: var(--white);
}
@media (min-width: 1280px) {
  .tabs-to-dropdown .nav-wrapper {
    border-bottom: 3px solid  #31D78A;
  }
}
.file-upload {
  background-color: #ffffff;
  width: 600px;
  margin: 0 auto;
  padding: 20px;
}
.file-upload-btn {
  width:100%;
  color: #fff;
  background: #2a7aBe;
  border: none;
  padding: 10px 0;
  border-radius: 4px;
  border-bottom: 4px solid #2a7aBe;
  transition: all .2s ease;
  outline: none;
  text-transform: uppercase;
  font-weight: 700;
}
.file-upload-btn:active {
  border: 0;
  transition: all .2s ease;
}
.file-upload-content {
  display: none;
  text-align: center;
  padding-bottom: 30px;
}
.file-upload-input {
  position: absolute;
  margin: 0;
  padding: 0;
  outline: none;
  opacity: 0;
  cursor: pointer;
}
.image-upload-wrap {
  padding-bottom: 30px;
  position: relative;
}
.image-dropping:hover {
  background-color: #2a7aBe;
  border: 4px dashed #ffffff;
}
.image-title-wrap {
  color: #2a7aBe;
}
.drag-text{
  text-align: center;
}
.drag-text h4{
  font-weight: 100;
  text-transform: uppercase;
  color: #2a7aBe;
  padding: 60px 0;
}
</style>
<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <!-- <div class="page-wrapper">
                <div class="page-body"> -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="tabs-to-dropdown">
                                          <div class="nav-wrapper d-flex align-items-center justify-content-between" >
                                            <ul class="nav nav-pills  d-md-flex" id="pills-tab" role="tablist">
                                              <li class="nav-item" role="presentation">
                                                <a class="nav-link active" id="pills-company-tab" data-toggle="pill" href="#user" role="tab" aria-controls="pills-company" aria-selected="true"><i class="fa fa-user"></i> User info</a>
                                              </li>
                                              <li class="nav-item" role="presentation">
                                                <a class="nav-link" id="pills-product-tab" data-toggle="pill" href="#company" role="tab" aria-controls="pills-product" aria-selected="false"><i class="fa fa-building"></i> Company info</a>
                                              </li>
                                              <li class="nav-item" role="presentation">
                                                <a class="nav-link" id="pills-news-tab" data-toggle="pill" href="#bank" role="tab" aria-controls="pills-news" aria-selected="false"><i class="fa fa-bank"></i> Bank info</a>
                                              </li>
                                              <li class="nav-item" role="presentation">
                                                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#sms" role="tab" aria-controls="pills-contact" aria-selected="false"><i class="fa fa-comment-o"></i> Sms</a>
                                              </li>
                                            </ul>

                                            
                                          </div>

                                          <div class="tab-content" id="pills-tabContent">
                                            <div class="tab-pane fade show active" id="user" role="tabpanel" aria-labelledby="pills-company-tab">
                                              <div class="container-fluid">
                                                <?php if(!empty($message)){
                                                            ?>
                                                            <p style="color: red; text-align: center;"><?php echo $message; ?></p>
                                                            <?php
                                                        } ?>
                                                <form action="" method="post" enctype="multipart/form-data">
                                                     <div class="row">
                                                         <?php while ($user_row = mysqli_fetch_array($user_update)){ ?>
                                                    <div class="col-md-12">
                                                        <div class="form-group col-md-6">
                                                        <label >First Name <span class="req-data">*</span></label>
                                                        <input value="<?php echo $user_row['f_name'];?>" type="text" class="form-control" name="fname" data-required="true" required="required" >
                                                        </div>
                                                         <div class="form-group col-md-6">
                                                        <label >Last Name <span class="req-data">*</span></label>
                                                        <input value="<?php echo $user_row['l_name'];?>" type="text" class="form-control" name="lname" data-required="true" required="required" >
                                                        </div>
                                                        <!-- <div class="form-group col-md-6">
                                                        <label >Phone No <span class="req-data">*</span></label>
                                                        <input value="<?php echo $user_row['e_contact_no'];?>" type="number" class="form-control" name="phoneno" data-required="true" required="required">
                                                        </div>   -->        
                                                     <?php } ?>

                                                    <div class="col-md-12">
                                                        <hr>
                                                        <button id="submit" type="submit" name="update" class="btn btn-success btn-out btn-out search green_back"><i class="fa fa-spinner"></i> Update</button>
                                                    </div>
                                                    </div>
                                               
                                                </div>
                                                </form>
                                              </div>
                                            </div>
                                            <div class="tab-pane fade" id="company" role="tabpanel" aria-labelledby="pills-product-tab">
                                              <div class="container-fluid">
                                                <form action="" method="post" enctype="multipart/form-data">
                                                    <div class="row">
                                                        <?php 
                                                          $company = "SELECT * FROM company_info WHERE close ='1' AND status = '1'";
                                                          $company_ex = mysqli_query($con,$company);
                                                        foreach ($company_ex as $row)
                                                        {
                                                        ?>
                                                        <div class="col-md-8">
                                                            <div class="form-group col-md-12">
                                                                <label >Company Name <span class="req-data">*</span></label>
                                                                <input value="<?php echo $row['com_name'] ;?>" type="text" class="form-control" name="companyname" data-required="true" required="required" >
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label >Company Phone <span class="req-data">*</span></label>
                                                                <input value="<?php echo $row['com_phone'] ;?>" type="number" class="form-control" name="companyphone" data-required="true" required="required" >
                                                            </div>
                                                        
                                                            <div class="form-group col-md-6">
                                                                <label >Company Email <span class="req-data">*</span></label>
                                                                <input value="<?php echo $row['com_email'] ;?>" type="email" class="form-control" name="companyemail" data-required="true" required="required" >
                                                            </div>
                                                            <div class="form-group col-md-12">
                                                                <label >Company Address <span class="req-data">*</span></label>
                                                                <textarea class="form-control" name="companyaddress" data-required="true" required="required"><?php echo $row['com_address'] ;?></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-12 col-lg-3 col-md-4">
                                                          <div class="form-group col-sm-12">
                                                            <div class="S-Image text-centre" style="width: 200px; height: 200px">
                                                                <img src='../assets/img/<?php echo $row['com_logo']?>'  id='image' style="height: 180px; width: 180px;">
                                                            </div>
                                                          </div>
                                                            <label id="img_button" class="btn btn-danger" style="margin-left: 20%; margin-top: 10px;"><i class="fa fa-picture-o"></i>&nbsp;Browse<input type="file" name="logo_photo" style="display: none;"   onchange="showImage.call(this)">
                                                            </label>
                                                        </div>
                                                        <div class="col-md-12" style="padding-top: 20px;">
                                                            <hr>
                                                            <button id="submit" type="submit" name="updatecompany" class="btn btn-success btn-out search green_back"><i class="fa fa-spinner"></i> Update</button>
                                                        </div>
                                                    </div>
                                                    <?php } ?>          
                                                </form>
                                            </div>
                                        </div>
                                            <div class="tab-pane fade" id="bank" role="tabpanel" aria-labelledby="pills-news-tab">
                                              <div class="container-fluid">
                                                <form action="" method="post" enctype="multipart/form-data">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <?php foreach ($company_bank_ex as $bank){?> 
                                                            <div class="form-group col-md-6">
                                                                <label>Bank Title <span class="req-data">*</span></label>
                                                                <input value="<?php echo $bank['bank_title'] ;?>" type="text" class="form-control" name="banktitle" data-required="true" required="required" >
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label >Branch <span class="req-data">*</span></label>
                                                                <input value="<?php echo $bank['bank_branch'] ;?>" type="text" class="form-control" name="bankbranch" data-required="true" required="required" >
                                                            </div>
                                                        
                                                            <div class="form-group col-md-6">
                                                                <label >Account Title <span class="req-data">*</span></label>
                                                                <input value="<?php echo $bank['account_title'] ;?>" type="text" class="form-control" name="accounttitle" data-required="true" required="required" >
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label>Account Number <span class="req-data">*</span></label>
                                                                <input value="<?php echo $bank['account_no'] ;?>" type="text" class="form-control" name="accountno" data-required="true" required="required" >
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12" style="padding-top: 20px;">
                                                            <hr>
                                                            <button id="submit" type="submit" name="Updatebank" class="btn btn-success btn-out search green_back"><i class="fa fa-spinner"></i> Update</button>
                                                        </div>
                                                    </div> 
                                                    <?php } ?>         
                                                </form>
                                                
                                              </div>
                                            </div>
                                            <div class="tab-pane fade" id="sms" role="tabpanel" aria-labelledby="pills-contact-tab">
                                              <div class="container-fluid">
                                                <form action="" method="post" enctype="multipart/form-data">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                        <?php foreach ($sms_ex as $sms){?>
                                                            
                                                            <div class="form-group col-md-6">
                                                                <label >User Name <span class="req-data">*</span></label>
                                                                <input value="<?php echo $sms['sms_username'] ;?>" type="text" class="form-control" name="smsuname" data-required="true" required="required" >
                                                            </div>
                                                        
                                                            <div class="form-group col-md-6">
                                                                <label >Password <span class="req-data">*</span></label>
                                                                <input value="<?php echo $sms['sms_password'] ;?>" type="text" class="form-control" name="smspassword" data-required="true" required="required" >
                                                            </div>
                                                            <div class="form-group col-md-12">
                                                                <label >Link <span class="req-data">*</span></label>
                                                                <input value="<?php echo $sms['sms_link'] ;?>" type="text" class="form-control" name="smslink" data-required="true" required="required" >
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12" style="padding-top: 20px;">
                                                            <hr>
                                                            <button id="submit" type="submit" name="updatesms" class="btn btn-success search green_back"><i class="fa fa-spinner"></i> Update</button>
                                                        </div>
                                                    </div>
                                                    <?php } ?>          
                                                </form>
                                                
                                              </div>
                                            </div>
                                          </div>
                                </div>
                            </div>
                        </div>
                    <!-- </div>
                </div> -->
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
   
function showImage(){
    if(this.files && this.files[0]){
        var obj = new FileReader();
        obj.onload = function(data){
            var image = document.getElementById("image");
            image.src = data.target.result;
            image.style.display="block";
        }
        obj.readAsDataURL(this.files[0]);
    }
}

</script>
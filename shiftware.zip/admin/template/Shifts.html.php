<style type="text/css">
  .md-event-listing-cont {
    position: relative;
    padding-left: 50px;
  }

  .md-event-listing-avatar {
    position: absolute;
    max-height: 50px;
    max-width: 50px;
    top: 21px;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    left: 20px;
  }

  .md-event-listing-name {
    font-size: 16px;
  }

  .md-event-listing-title {
    font-size: 12px;
    margin-top: 5px;
  }

  .md-event-listing .mbsc-segmented {
    max-width: 350px;
    margin: 0 auto;
    padding: 1px;
  }

  .md-event-listing-picker {
    flex: 1 0 auto;
  }

  .md-event-listing-nav {
    width: 200px;
  }

  /* material header order */

  .mbsc-material.md-event-listing-prev {
    order: 1;
  }

  .mbsc-material.md-event-listing-next {
    order: 2;
  }

  .mbsc-material.md-event-listing-nav {
    order: 3;
  }

  .mbsc-material .md-event-listing-picker {
    order: 4;
  }

  .mbsc-material .md-event-listing-today {
    order: 5;
  }

  /* windows header order */

  .mbsc-windows.md-event-listing-nav {
    order: 1;
  }

  .mbsc-windows.md-event-listing-prev {
    order: 2;
  }

  .mbsc-windows.md-event-listing-next {
    order: 3;
  }

  .mbsc-windows .md-event-listing-picker {
    order: 4;
  }

  .mbsc-windows .md-event-listing-today {
    order: 5;
  }


  .modal-dialog-slideout {min-height: 100%; margin: 0 0 0 auto;background: #fff;}
  .modal.fade .modal-dialog.modal-dialog-slideout {-webkit-transform: translate(100%,0)scale(1);transform: translate(100%,0)scale(1);}
  .modal.fade.show .modal-dialog.modal-dialog-slideout {-webkit-transform: translate(0,0);transform: translate(0,0);display: flex;align-items: stretch;-webkit-box-align: stretch;}
  .modal.fade.show .modal-dialog.modal-dialog-slideout .modal-body{overflow-y: auto;overflow-x: hidden;}
  .modal-dialog-slideout .modal-content{border: 0;}
  .modal-dialog-slideout .modal-header, .modal-dialog-slideout .modal-footer {height: 69px; display: block;} 
  .modal-dialog-slideout .modal-header h5 {float:left;}

</style>
<div class="main-panel">
  <div class="content">
    <div class="page-inner">
      <!-- Card -->
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <div class="card-head-row float-right">
                <button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-customs"><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Add Shift</button>
              </div>

              <!-- Modal -->
              <div class="modal fade " id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Add Shift</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                      <div class="modal-body p-4 modal-body get_quote_view_modal_body p-4 modalbuttonopen11">
                        <div class="row p-4">
                          <div class="col-md-12" style="box-shadow: 1px 2px 10px grey!important; border-radius: 5px;">
                            <div class="row" style="margin-left: -1%!important;">
                              <div class="form-group col-md-12">
                                <i class="fa fa-user-plus mr-1" style="color: #F2686F;"></i><label>Client</label>
                              </div>
                            </div>
                            <div class="mx-1" style="border-bottom: 2px solid #90CAF9;"></div>
                            <div class="row m-1">
                              <div class="form-group col-md-4">
                                <label for="fname">Chose Client</label>
                              </div>
                              <div class="form-group col-md-8">
                                <select class="form-control" name="client" id="client" data-required="true" required="required" autofocus autocomplete="off">
                                  <option class="text-center" value disabled selected>-----Select Client-----</option>
                                  <?php
                                  $select_client = "SELECT * FROM wt_users JOIN client ON client.wt_user_id = wt_users.id WHERE wt_users.close = '1' AND wt_users.status = '1' AND wt_users.user_type = 'client'";
                                  $select_client_ex = mysqli_query($con,$select_client);
                                  foreach ($select_client_ex as $select_client_ex1) {
                                    ?>
                                    <option value="<?php echo $select_client_ex1['c_id'] ?>"><?php echo ucwords($select_client_ex1['f_name'].' '.$select_client_ex1['m_name'].' '.$select_client_ex1['l_name']) ?></option>
                                    <?php
                                  }
                                  ?>

                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="row p-4">
                          <div class="col-md-12" style="box-shadow: 1px 2px 10px grey!important; border-radius: 5px;">
                            <div class="row" style="margin-left: -1%!important;">
                              <div class="form-group col-md-12">
                                <i class="fa fa-calendar mr-1" style="color: #7FAFFF;"></i><label>Shift</label>
                              </div>
                            </div>
                            <div class="mx-1" style="border-bottom: 2px solid #59B2F6;"></div>
                            <div class="row m-1">
                              <div class="form-group col-md-4">
                                <label for="fname">Shift / Service Type</label>
                              </div>
                              <div class="form-group col-md-8">
                                <select class="form-control" name="shift_type" id="shift_type" data-required="true" required="required" autofocus autocomplete="off">
                                  <option class="text-center" value disabled selected>-----Select Shift / service Type-----</option>
                                  <?php
                                  foreach ($con->query('SELECT * FROM services WHERE close = "1" AND status = "1" ') as $rowservices){
                                    ?>
                                    <option value = '<?php echo $rowservices['ser_id']; ?>'><?php echo ucwords($rowservices['service_name']); ?></option>
                                    <?php
                                  }
                                  ?>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="row p-4">
                          <div class="col-md-12" style="box-shadow: 1px 2px 10px grey!important; border-radius: 5px;">
                            <div class="row" style="margin-left: -1%!important;">
                              <div class="form-group col-md-12">
                                <i class="fa fa-id-card mr-1" style="color: #7FAFFF;"></i><label>Staff</label>
                              </div>
                            </div>
                            <div class="mx-1" style="border-bottom: 2px solid #59B2F6;"></div>


                            <div class="row m-1">
                              <div class="form-group col-md-4">
                                <label for="">Sector</label>
                              </div>
                              <div class="form-group col-md-8">
                                <select class="form-control" name="staff_sector" id="staff_sector" data-required="true" required="required" autofocus autocomplete="off" onchange="checksectorstaff();">
                                  <option class="text-center" value disabled selected>-----Select Sector-----</option>
                                  <?php
                                  foreach ($con->query('SELECT * FROM sectors WHERE close = "1" AND status = "1" ') as $rowsector){
                                    ?>
                                    <option value = '<?php echo $rowsector['sec_id']; ?>'><?php echo ucwords($rowsector['sector_name']); ?></option>
                                    <?php
                                  }
                                  ?>
                                </select>
                              </div>
                            </div>


                            <div class="row m-1">
                              <div class="form-group col-md-4">
                                <label for="fname">Choose Staff</label>
                              </div>
                              <div class="form-group col-md-8">
                                <select id="selectstaff" class="form-control" name="staff[]" required="required" onchange="checkstaffleave();">
                                  <option class="text-center" value disabled selected>-----Select Staff-----</option>


                                </select>
                              </div>
                            <!--   <div class="form-group col-md-9"></div>
                              <div class="form-group col-md-2 pr-0">
                                <label class="float-right">Open Shift</label>
                              </div>
                              <div class="form-group col-md-1 pl-0" style="height: 20px;">
                                <input type="checkbox" id="open_shift" name="open_shift" value="0" class="form-control" onchange="checkopenshift(this.value);">
                              </div> -->
                            </div>
                          </div>
                        </div>
                        <div class="row p-4">
                          <div class="col-md-12" style="box-shadow: 1px 2px 10px grey!important; border-radius: 5px;">
                            <div class="row" style="margin-left: -1%!important;">
                              <div class="form-group col-md-12">
                                <i class="fa fa-calendar-check mr-1" style="color: #F2686F;"></i></i><label>Time & Location</label>
                              </div>
                            </div>
                            <div class="mx-1" style="border-bottom: 2px solid #90CAF9;"></div>
                            <div class="row m-1">
                              <div class="form-group col-md-4">
                                <label>Date</label>
                              </div>
                              <div class="form-group col-md-8">
                                <input type="date" id="shiftdate" name="shiftdate" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onchange="checkstaffleave();">
                              </div>
                            </div>
                            <div class="form-group col-md-12" id="staffleavewarning">

                            </div>
                            <div class="row m-1">
                              <div class="form-group col-md-8"></div>
                              <div class="form-group col-md-3">
                                <label>Shift finishes the next day</label>
                              </div>
                              <div class="form-group col-md-1" style="height: 20px;">
                                <input type="checkbox" id="finish_next_day" name="" value="0" class="form-control" onchange="checkfinishnextday();">
                                <input type="hidden" id="finish_next_day2" name="finish_next_day" value="0">
                              </div>
                            </div>
                            <div class="row m-1">
                              <div class="form-group col-md-4">
                                <label>Time</label>
                              </div>
                              <div class="form-group col-md-4">
                                <input type="time" id="starttime" name="starttime" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onchange="checkalreadyres();">
                              </div>
                              <div class="form-group col-md-4">
                                <input type="time" id="endtime" name="endtime" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off" onchange="checkalreadyres();">
                              </div>
                            </div>
                            <div id="already_res_msg"></div>
                            <div class="row m-1">
                              <div class="form-group col-md-10">

                              </div>
                              <div class="form-group col-md-1">
                                <label>Repeat</label>
                              </div>
                              <div class="form-group col-md-1" style="height: 20px;">
                                <input type="checkbox" id="repeat" name="" value="0" class="form-control" onchange="checkrepeat();">
                                <input type="hidden" id="repeat2" name="repeat" value="0">
                              </div>
                            </div>
                            <div id="repeatyes" style="display: none;">
                              <div class="row m-1">
                                <div class="form-group col-md-4">
                                  <label for="fname">Recurrance</label>
                                </div>
                                <div class="form-group col-md-8">
                                  <select class="form-control" name="recurrance" id="recurrance" onchange="checkrecurrance();">
                                    <option class="text-center" value disabled selected>-----Select Option-----</option>
                                    <option value='daily'>Daily</option>
                                    <option value='weekly'>Weekly</option>
                                    <option value='monthly'>Monthly</option>
                                  </select>
                                </div>
                              </div>
                              <div id="daily" style="display: none;">
                                <div class="row m-1">
                                  <div class="form-group col-md-4">
                                    <label>Repeat Every</label>
                                  </div>
                                  <div class="form-group col-md-7">
                                    <select class="form-control" name="daily_repeat_every" id="daily_repeat_every" data-required="true" required="required" autofocus autocomplete="off">
                                      <!-- <option class="text-center" value disabled selected>-----Select Option-----</option> -->
                                      <option selected value="1">1</option>
                                      <option value="2">2</option>
                                      <option value="3">3</option>
                                      <option value="4">4</option>
                                      <option value="5">5</option>
                                      <option value="6">6</option>
                                      <option value="7">7</option>
                                      <option value="8">8</option>
                                      <option value="9">9</option>
                                      <option value="10">10</option>
                                      <option value="11">11</option>
                                      <option value="12">12</option>
                                      <option value="13">13</option>
                                      <option value="14">14</option>
                                      <option value="15">15</option>
                                    </select>
                                  </div>
                                  <div class="form-group col-md-1">
                                    <p>Daily</p>
                                  </div>
                                </div>
                              </div>
                              <div id="weekly" style="display: none;">
                                <div class="row m-1">
                                  <div class="form-group col-md-4">
                                    <label>Repeat Every</label>
                                  </div>
                                  <div class="form-group col-md-6">
                                    <select class="form-control" name="weekly_repeat_every" id="weekly_repeat_every" data-required="true" required="required" autofocus autocomplete="off">
                                      <!-- <option class="text-center" value disabled selected>-----Select Option-----</option> -->
                                      <option selected value="1">1</option>
                                      <option value="2">2</option>
                                      <option value="3">3</option>
                                      <option value="4">4</option>
                                      <option value="5">5</option>
                                      <option value="6">6</option>
                                      <option value="7">7</option>
                                      <option value="8">8</option>
                                      <option value="9">9</option>
                                      <option value="10">10</option>
                                      <option value="11">11</option>
                                      <option value="12">12</option>
                                    </select>
                                  </div>
                                  <div class="form-group col-md-2">
                                    <p>Weekly</p>
                                  </div>
                                </div>
                                <div class="row m-1">
                                  <div class="form-group col-md-4"></div>
                                  <div class="form-group col-md-1">
                                    <label class="float-right">Mon</label>
                                  </div>
                                  <div class="form-group col-md-1" style="height: 20px;">
                                    <input type="checkbox" id="mon" name="mon" value="1" checked class="form-control" style="margin-left: -50%;" onchange="checkday('mon');">
                                  </div>
                                  <div class="form-group float-right col-md-1">
                                    <label class="float-right">Tue</label>
                                  </div>
                                  <div class="form-group col-md-1" style="height: 20px;">
                                    <input type="checkbox" id="tue" name="tue" value="0" class="form-control" style="margin-left: -50%;" onchange="checkday('tue');">
                                  </div>
                                  <div class="form-group float-right col-md-1">
                                    <label class="float-right">Wed</label>
                                  </div>
                                  <div class="form-group col-md-1" style="height: 20px;">
                                    <input type="checkbox" id="wed" name="wed" value="0" class="form-control" style="margin-left: -50%;" onchange="checkday('wed');">
                                  </div>
                                  <div class="form-group float-right col-md-1">
                                    <label class="float-right">Thu</label>
                                  </div>
                                  <div class="form-group col-md-1" style="height: 20px;">
                                    <input type="checkbox" id="thu" name="thu" value="0" class="form-control" style="margin-left: -50%;" onchange="checkday('thu');">
                                  </div>
                                  <!-- <div class="form-group col-md-1"></div> -->
                                </div>
                                <div class="row m-1">
                                  <div class="form-group col-md-5"></div>
                                  <div class="form-group col-md-1">
                                    <label class="float-right">Fri</label>
                                  </div>
                                  <div class="form-group col-md-1" style="height: 20px;">
                                    <input type="checkbox" id="fri" name="fri" value="0" class="form-control" style="margin-left: -50%;" onchange="checkday('fri');">
                                  </div>
                                  <div class="form-group float-right col-md-1">
                                    <label class="float-right">Sat</label>
                                  </div>
                                  <div class="form-group col-md-1" style="height: 20px;">
                                    <input type="checkbox" id="sat" name="sat" value="0" class="form-control" style="margin-left: -50%;" onchange="checkday('sat');">
                                  </div>
                                  <div class="form-group float-right col-md-1">
                                    <label class="float-right">Sun</label>
                                  </div>
                                  <div class="form-group col-md-1" style="height: 20px;">
                                    <input type="checkbox" id="sun" name="sun" value="0" class="form-control" style="margin-left: -50%;" onchange="checkday('sun');">
                                  </div>
                                  <div class="form-group col-md-1"></div>
                                </div>
                              </div>
                              <div id="monthly" style="display: none;">
                                <div class="row m-1">
                                  <div class="form-group col-md-4">
                                    <label>Repeat Every</label>
                                  </div>
                                  <div class="form-group col-md-6">
                                    <select class="form-control" name="monthly_repeat_every" id="monthly_repeat_every" data-required="true" required="required" autofocus autocomplete="off">
                                      <!-- <option class="text-center" value disabled selected>-----Select Option-----</option> -->
                                      <option selected value="1">1</option>
                                      <option value="2">2</option>
                                      <option value="3">3</option>
                                    </select>
                                  </div>
                                  <div class="form-group col-md-2">
                                    <p>Monthly</p>
                                  </div>
                                </div>
                                <div class="row m-1">
                                  <div class="form-group col-md-4">
                                    <label>Occures On</label>
                                  </div>
                                  <div class="form-group col-md-8">
                                    <select class="form-control" name="occures_on" id="occures_on" data-required="true" required="required" autofocus autocomplete="off">
                                      <!-- <option class="text-center" value disabled selected>-----Select Option-----</option> -->
                                      <option selected value="1">1</option>
                                      <option value="2">2</option>
                                      <option value="3">3</option>
                                      <option value="4">4</option>
                                      <option value="5">5</option>
                                      <option value="6">6</option>
                                      <option value="7">7</option>
                                      <option value="8">8</option>
                                      <option value="9">9</option>
                                      <option value="10">10</option>
                                      <option value="11">11</option>
                                      <option value="12">12</option>
                                      <option value="13">13</option>
                                      <option value="14">14</option>
                                      <option value="15">15</option>
                                      <option value="16">16</option>
                                      <option value="17">17</option>
                                      <option value="18">18</option>
                                      <option value="19">19</option>
                                      <option value="20">20</option>
                                      <option value="21">21</option>
                                      <option value="22">22</option>
                                      <option value="23">23</option>
                                      <option value="24">24</option>
                                      <option value="25">25</option>
                                      <option value="26">26</option>
                                      <option value="27">27</option>
                                      <option value="28">28</option>
                                      <option value="29">29</option>
                                      <option value="30">30</option>
                                      <option value="31">31</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="row m-1">
                              <div class="form-group col-md-4">
                                <label>Address</label>
                              </div>
                              <div class="form-group col-md-8">
                                <textarea class="form-control" name="address"></textarea>
                              </div>
                            </div>
                            <div class="row m-1">
                              <div class="form-group col-md-4">
                                <label>Apartment Number</label>
                              </div>
                              <div class="form-group col-md-8">
                                <textarea class="form-control" name="apartment"></textarea>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="row p-4">
                          <div class="col-md-12" style="box-shadow: 1px 2px 10px grey!important; border-radius: 5px;">
                            <div class="row" style="margin-left: -1%!important;">
                              <div class="form-group col-md-12">
                                <i class="fa fa-user-plus mr-1" style="color: #F2686F;"></i><label>Instructions</label>
                              </div>
                            </div>
                            <div class="mx-1" style="border-bottom: 2px solid #90CAF9;"></div>
                            <div class="row m-1">
                              <div class="form-group col-md-12">
                                <textarea class="form-control" name="instructions" rows="4"></textarea>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="submit" id="submitshift" name="submitshift" class="btn btn-customs"><span class="btn-label"><i class="fa fa-spinner"></i></span> Submit</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>

            <button class="btn btn-Success search green_back" style="float: right; border-radius: 3px;" data-toggle="modal" data-target="#shiftslot" id="shiftslot1" hidden>aaaaa</button>
            <div class="modal fade" id="shiftslot" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header bg-light">
                    <h4 class="modal-title">View Shifts</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                  </div>
                  <div class="modal-body selected_start_time">

                  </div>     
                </div>
              </div>
            </div>

            <button class="btn btn-Success search green_back" style="float: right; border-radius: 3px;" data-toggle="modal" data-target="#exampleModal1" id="updateShift1" hidden>aaaaa</button>
            <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header bg-light">
                    <h4 class="modal-title">Update Shift</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                  </div>
                  <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                    <div class="modal-body updateShift">

                    </div>
                  </form>     
                </div>
              </div>
            </div>

            <div class="card-body">
              <div id='calendar'></div>
            <!-- <div class="md-event-listing">
                <div id="demo-event-listing"></div>
              </div> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
 function checkstaffleave() {
  var selectstaff = $("#selectstaff").val();
  var shiftdate = $("#shiftdate").val();
  $.ajax({
    type: "POST",
    url: "models/shifts_edit.php",
    data:{
     checkstaffleave:selectstaff,
     shiftdate:shiftdate
   },
   success: function(data){
    if (data == "true") {
      $('#staffleavewarning').empty();
    }
    else{
      $('#staffleavewarning').html("<div style='background:#f8d7da; padding-top:2%;' class='form-group col-md-12'><p class='col-md-12 text-center' style='color: #C82333; font-weight:bolder;'>"+data+"</p></div>");
    } 
    checkalreadyres();
  }
});
}


function checkalreadyres(){
 var selectstaff = $("#selectstaff").val();
    var shiftdate = $("#shiftdate").val();
    var starttime = $("#starttime").val();
    var endtime = $("#endtime").val();

    $.ajax({
      type: "POST",
      url: "models/shifts_edit.php",
      data: {
        checkalreadyresshift: selectstaff,
        shiftdate: shiftdate,
        starttime: starttime,
        endtime: endtime
      },
      success: function(data) {
        if (data == "") {
          $('#submitshift').prop('disabled', false);
          $('#already_res_msg').empty();
        } else {
          $('#submitshift').prop('disabled', true);
          $('#already_res_msg').html("<div style='background:#f8d7da; padding-top:2%;' class='form-group col-md-12 text-center'><p class='col-md-12' style='color: #C82333; font-weight:bolder;'>Sorry, Shift already added for the same staff on the same date and timing.</p></div>");
        }
      }
    });
  }
    






    function checksectorstaff(){
      var staff_sector = $("#staff_sector").val();
      /*alert(staff_sector);*/
      $.ajax({
        type: "POST",
        url: "models/shifts_edit.php",
        data: 'checksectorstaff='+staff_sector,
        success: function(data){
          /*alert(data);*/
          $("#selectstaff").html(data);
           // alert(data);

         }
       });
    }




    function checkrepeat() {
      var repeat_value = $("#repeat").val();
      if (repeat_value == 0) {
        $("#repeat").val(1);
        $("#repeat2").val(1);
        $("#repeatyes").show();
        $("#recurrance").attr('required',true);
      }
      else if (repeat_value == 1) {
        $("#repeat").val(0);
        $("#repeat2").val(0);
        $("#repeatyes").hide();
        $("#recurrance").attr('required',false);
      }
    }

    function checkrecurrance() {
      var recurrance_value = $("#recurrance").val();
      if (recurrance_value == 'daily') {
        $("#daily").show();
        $("#weekly").hide();
        $("#monthly").hide();
      }
      else if (recurrance_value == 'weekly') {
        $("#daily").hide();
        $("#weekly").show();
        $("#monthly").hide();
      }
      else if (recurrance_value == 'monthly') {
        $("#daily").hide();
        $("#weekly").hide();
        $("#monthly").show();
      }
      $("#end").show();
    }

    function checkday(id) {
      var value = $("#"+id).val();
      if (value == '0') {
        $("#"+id).val('1');
      }
      else if (value == '1') {
        $("#"+id).val('0');
      }
    }

    function checkfinishnextday() {
      var val = $("#finish_next_day").val();
      if (val == '0') {
        $("#finish_next_day").val('1');
        $("#finish_next_day2").val('1');
      }
      else if (val == '1') {
        $("#finish_next_day").val('0');
        $("#finish_next_day2").val('0');
      }
    }

    function checkopenshift(val) {
      if (val == '0') {
        $("#open_shift").val('1');
        $("#selectstaff").attr("multiple", true);
        $("#selectstaff option[disabled]").attr("selected", false);
      }
      else if (val == '1') {
        $("#open_shift").val('0');
        $("#selectstaff").attr("multiple", false);
        $("#selectstaff option[disabled]").attr("selected", true);
      }
    }

    function checkopenshift_up(val) {
      if (val == '0') {
        $("#open_shift_up").val('1');
        $("#selectstaff_up").attr("multiple", true);
        $("#selectstaff_up option[disabled]").attr("selected", false);
      }
      else if (val == '1') {
        $("#open_shift_up").val('0');
        $("#selectstaff_up").attr("multiple", false);
        $("#selectstaff_up option[disabled]").attr("selected", true);
      }
    }

    function edit_shift(idshift) {
      $.ajax({
        type: "POST",
        url: "models/shifts_edit.php",
        data:'shift_edit='+idshift,
        success: function(data){
          $(".updateShift").html(data);
          $('#updateShift1').trigger('click');
        }
      });
    }

    function delS(idshift) {
      var idshift = idshift;
      $.ajax({
        type:"POST",
        url:"models/shifts_edit.php",
        data: 'shift_del='+idshift,
        success:function(data) {
          var rowh = "#"+idshift;
          $(rowh).remove();
          Swal.fire(
            'Deleted!',
            'Record has been deleted.',
            'success'
            )
          setTimeout(function(){
            location.reload();
          },1000);
        }
      });
    }

    function add_shift() {
      $('#shiftslot1').trigger('click');
    }
  </script>

  <script>

    document.addEventListener('DOMContentLoaded', function() {
      var calendarEl = document.getElementById('calendar');

      var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },

        // initialDate: '<?php echo $current_date ;?>',
          navLinks: true, // can click day/week names to navigate views
          selectable: true,
          selectMirror: true,
          select: function(arg){
            var shifttime = arg.start;
            var shifttime1 = new Date(shifttime);
            var shifttime2 = shifttime1.toLocaleDateString();
            $.ajax({
              type: "POST",
              url: "models/shifts_edit.php",
              data:'show_shifts='+shifttime2,
              success: function(data){
                $(".selected_start_time").html(data);
                $('#shiftslot1').trigger('click');
              }
            });
          },
          eventClick: function(arg) {
            let bgc = arg.event.backgroundColor;
            let id = arg.event.id;
            let r = arg.event.title;
            let str = arg.event.start;
            var shifttime1 = new Date(str);
            var shifttime2 = shifttime1.toLocaleDateString();
            if (bgc == '#0090ff') {
              $.ajax({
                type: "POST",
                url: "models/shifts_edit.php",
                data:{
                  show_shift2:id,
                  start_date:shifttime2
                },
                success: function(data){
                  $(".selected_start_time").html(data);
                  $('#shiftslot1').trigger('click');
                }
              });
            }
            else if (bgc == '#31d88a' || bgc == '#31D78A' || '#FFB558') {
              $.ajax({
                type: "POST",
                url: "models/shifts_edit.php",
                data:{
                  show_shift3:id,
                  start_date:shifttime2
                },
                success: function(data){
                  $(".selected_start_time").html(data);
                  $('#shiftslot1').trigger('click');
                }
              });
            }

          },
          editable: false,
          dayMaxEvents: true, // allow "more" link when too many events
          events: [
          <?php
          foreach ($select_shift_ex as $row) {
            ?>
            {
              id: '<?php echo $row['sd_id']; ?>',
              title: '<?php echo $row['s_shift_type'] ?>',
              start: '<?php echo $row['sd_date']." ".$row['s_starttime'] ;?>',
              end: '<?php echo $row['sd_date']." ".$row['s_endtime'] ;?>',
              display: 'block',
              backgroundColor: '#0090ff'
            },
            <?php
          }
          ?>

          <?php
          foreach ($select_shift2_ex as $row4) {
            $s_shift_type = $row4['s_shift_type'];
            ?>
            {
              id: '<?php echo $row4['sd_id']; ?>',
              title: '<?php echo $s_shift_type ?>',
              start: '<?php echo $row4['sd_date']." ".$row4['s_starttime'] ;?>',
              end: '<?php echo $row4['sd_date']." ".$row4['s_endtime'] ;?>',
              display: 'block',
              backgroundColor: '#31d88a'
            },
            <?php
          }
          ?>
          <?php
          foreach ($select_shift3_ex as $row5) {
            $s_shift_type = $row5['s_shift_type'];
            ?>
            {
              id: '<?php echo $row5['sd_id']; ?>',
              title: '<?php echo "✔ ".$s_shift_type ?>',
              start: '<?php echo $row5['sd_date']." ".$row5['s_starttime'] ;?>',
              end: '<?php echo $row5['sd_date']." ".$row5['s_endtime'] ;?>',
              display: 'block',
              backgroundColor: '#31D78A'
            },
            <?php
          }
          ?>
          <?php
          foreach ($select_shift4_ex as $row6) {
            $s_shift_type = $row6['s_shift_type'];
            ?>
            {
              id: '<?php echo $row6['sd_id']; ?>',
              title: '<?php echo $s_shift_type ?>',
              start: '<?php echo $row6['sd_date']." ".$row6['s_starttime'] ;?>',
              end: '<?php echo $row6['sd_date']." ".$row6['s_endtime'] ;?>',
              display: 'block',
              backgroundColor: '#FFB558'
            },
            <?php
          }
          ?>
          ]
        });

calendar.render();
});

</script> 



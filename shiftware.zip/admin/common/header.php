<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Shift Care</title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <link rel="icon" href="../assets/img/favicon.png" type="image/x-icon"/>

    <!-- Fonts and icons -->
    <script src="../assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
        WebFont.load({
            google: {"families":["Lato:300,400,700,900"]},
            custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['../assets/css/fonts.min.css']},
            active: function() {
                sessionStorage.fonts = true;
            }
        });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/atlantis.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="../assets/dropify/dist/css/dropify.css">

    <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
    <!-- datatables -->
    <link rel="stylesheet" href="../assets/css/lib/datatable/buttons.dataTables.min.css">
    <link rel="stylesheet" href="../assets/css/lib/datatable/jquery.dataTables.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Sweet Alert -->
    <script src="../assets/js/plugin/sweetalert/sweetalert2.all.min.js"></script>

    <!-- FullCalender -->
    <link href='../assets/main.css' rel='stylesheet' />
    <script src='../assets/main.js'></script>

    <!-- Calender -->
    <link href='../assets/css/mobiscroll.javascript.min.css' rel='stylesheet' />
    <script src='../assets/js/mobiscroll.javascript.min.js'></script>
</head>
<style>
.btnback {
  box-sizing: border-box;
  appearance: none;
  background-color: transparent;
  border: 2px solid #fff;
  border-radius: 0.6em;
  color: #fff;
  cursor: pointer;
  display: flex;
  align-self: center;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1;
  margin: 0px;
  padding: 12px;
  text-decoration: none;
  text-align: center;
  text-transform: uppercase;
  font-family: 'Montserrat', sans-serif;
  font-weight: 700;
}
.btnbtnback:hover, .btnbtnback:focus {
  color: #31D78A;
  outline: 0;
}
.third {
  width: 43px;
  height: 43px;
  border-radius: 50%;
  display: inline-block;
  border-color: #fff;
  color: #31D78A;
  box-shadow: 0 0 40px 40px #fff inset, 0 0 0 0 #fff;
  transition: all 150ms ease-in-out;
}
.third:hover {
  box-shadow: 0 0 10px 0 #fff inset, 0 0 10px 4px #fff;
  color: #fff;
}
.sidebar .user .info a>span, .sidebar .user .info a>span .user-level, .sidebar .user .info .caret, .sidebar .nav>.nav-item a p, .sidebar .nav>.nav-item a i, .sidebar .nav>.nav-item a .caret, .sidebar .nav .nav-section .text-section, .sidebar.sidebar-style-2 .nav .nav-item a[data-toggle=collapse][aria-expanded=true] p, .sidebar .nav>.nav-item a, .sidebar .nav-collapse li a .sub-item:before {
    color: #fff!important;
}
.sidebar.sidebar-style-2 .nav .nav-item a[data-toggle=collapse][aria-expanded=true] p, .sidebar.sidebar-style-2 .nav .nav-item a:hover p, .sidebar.sidebar-style-2 .nav .nav-item a:hover i, .sidebar.sidebar-style-2 .nav .nav-item a[data-toggle=collapse][aria-expanded=true] i{
    color: #fff!important;
}
.sidebar[data-background-color=white] .nav-collapse li a .sub-item:before, .sidebar.sidebar-style-2 .nav .nav-item a{
    color: #fff!important;
}
.sidebar .nav-collapse li a .sub-item:before{
    background-color: #fff;
}
</style>
<script type="text/javascript">
    function date_time(id)
    {
        date = new Date;
        year = date.getFullYear();
        month = date.getMonth();
        months = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
        d = date.getDate();
        day = date.getDay();
        days = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
        h = date.getHours();
        if(h<10)
        {
            h = "0"+h;
        }
        m = date.getMinutes();
        if(m<10)
        {
            m = "0"+m;
        }
        s = date.getSeconds();
        if(s<10)
        {
            s = "0"+s;
        }
        result = ''+days[day]+' <br>'+d+' '+months[month]+'<b> '+h+':'+m+'</b>:'+s;
        document.getElementById(id).innerHTML = result;
        setTimeout('date_time("'+id+'");','1000');
        return true;
    }
</script>
<style type="text/css">
    .date_time_div{
        color: white;
        float: left!important;
        margin-right: 20px!important;
        font-size: 14px!important;
        font-weight: bold!important;
    }
</style>
<?php 
// $todays_notify = date('Y-m-d');
// $notification1 = "SELECT * FROM attendance JOIN students ON attendance.att_student = students.stu_id WHERE attendance.att_date = '".$todays_notify."' AND attendance.status = '1' AND attendance.close = '1'";
// $notification1_ex = mysqli_query($con,$notification1);
// $total_notifications = 0;
?>
<body onload="myload();">
    <div class="wrapper">
        <div class="main-header">
            <div class="logo-header" data-background-color="white">
                <a href="dashboard" class="logo mt-4">
                    <img src="../assets/img/logo.png" width="170" alt="navbar brand" class="navbar-brand">
                </a>
                <button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon">
                        <i class="icon-menu"></i>
                    </span>
                </button>
                <button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
                <div class="nav-toggle mt-3">
                    <button class="btn btn-toggle toggle-sidebar">
                        <i class="icon-menu"></i></button>
                    </div>
                </div>

                <nav class="navbar navbar-header navbar-expand-lg" data-background-color="blue2">

                    <div class="container-fluid">
                        <ul class="navbar-nav topbar-nav ml-md-0 mt-2 align-items-left">
                            <li class="nav-item">
                                <a class="" href="dashboard" style="text-decoration: none;">
                                    <h4 class="page-title text-white"><?php  echo $head_title1 = ucwords(str_replace("_", " ", $head_title));
                                    ?></h4>
                                </a>
                            </li>
                            <li class="nav-item">
                                <div id="addUnitmsg"></div>
                            </li>
                        </ul>
                        <ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
                            <li class="header-notification" style="line-height: 2;">
                                <div class="date_time_div">
                                    <span id="date_time"></span>
                                    <script type="text/javascript">window.onload = date_time('date_time');</script>
                                </div>
                            </li>
                            <li class="nav-item dropdown hidden-caret">
                                <a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="false">
                                    <div class="avatar-sm">
                                        <img src="../assets/img/avatar.png" alt="..." class="avatar-img rounded-circle">
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-user animated fadeIn">
                                    <div class="dropdown-user-scroll scrollbar-outer">
                                        <li>
                                            <div class="user-box">
                                                <div class="avatar-lg"><img src="../assets/img/avatar.png" alt="image profile" class="avatar-img rounded"></div>
                                                <div class="u-text">
                                                    <h4><?php echo ucwords($_SESSION['user_name']); ?></h4>
                                                    <p class="text-muted"><?php echo $_SESSION['user_email']; ?></p>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="profile-setting">Profile Setting</a>
                                            <a class="dropdown-item" href="Changepassword">Change Password</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="logout">Logout</a>
                                        </li>
                                    </div>
                                </ul>
                            </li>
                            <li>
                                <div class="float-right" id="back-btn">
                                    <button class="btnback third" onclick="history.back()"><i class="fa fa-arrow-left fa-lg"></i></button>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="sidebar sidebar-style-2" style="background-color: #005431;">                   
                <div class="sidebar-wrapper scrollbar scrollbar-inner">
                    <div class="sidebar-content">
                        <div class="user">
                            <div class="avatar-sm float-left mr-2">
                                <img src="../assets/img/avatar.png" alt="..." class="avatar-img rounded-circle">
                            </div>
                            <div class="info">
                                <a data-toggle="collapse" href="#collapseExample" aria-expanded="true">
                                    <span>
                                        <?php echo ucwords($_SESSION['user_name']); ?>
                                        <span class="user-level"><?php echo ucwords($_SESSION['type']); ?></span>
                                        <span class="caret"></span>
                                    </span>
                                </a>
                                <div class="clearfix"></div>

                                <div class="collapse in" id="collapseExample">
                                    <ul class="nav">
                                        <li>
                                            <a href="logout"><span class="link-collapse">Logout</span></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <ul class="nav nav-primary">
                            <li class="nav-item">
                                <a href="dashboard">
                                    <i class="fas fa-home"></i>
                                    <p>Dashboard</p>
                                </a>
                            </li>
                            <li class="nav-section">
                                <span class="sidebar-mini-icon">
                                    <i class="fa fa-ellipsis-h"></i>
                                </span>
                                <h4 class="text-section">Modules</h4>
                            </li>
                            <li class="nav-item">
                                <a href="add-user">
                                    <i class="fas fa-users"></i>
                                    <p>User</p>
                                </a>
                            </li>

                            <li class="nav-item">
                                <a data-toggle="collapse" href="#servicessecttor">
                                    <i class="fas fa-microchip"></i>
                                    <p>Services & Sectors</p>
                                    <span class="caret"></span>
                                </a>
                                <div class="collapse" id="servicessecttor">
                                    <ul class="nav nav-collapse">
                                        <li>
                                            <a href="services">
                                                <span class="sub-item">Services</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="sectors">
                                                <span class="sub-item">Sectors</span>
                                            </a>
                                        </li>
                                        
                                    </ul>
                                </div>
                            </li>


                            <li class="nav-item">
                                <a data-toggle="collapse" href="#staff">
                                    <i class="fas fa-id-card"></i>
                                    <p>Staff</p>
                                    <span class="caret"></span>
                                </a>
                                <div class="collapse" id="staff">
                                    <ul class="nav nav-collapse">
                                        <li>
                                            <a href="staff">
                                                <span class="sub-item">Staff</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="staffdocuments">
                                                <span class="sub-item">Staff Documents</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="staffarchived">
                                                <span class="sub-item">Archived</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="leavemanagement">
                                                <span class="sub-item">Leave Management</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                            <li class="nav-item">
                                <a data-toggle="collapse" href="#client">
                                    <i class="fas fa-address-book"></i>
                                    <p>Client</p>
                                    <span class="caret"></span>
                                </a>
                                <div class="collapse" id="client">
                                    <ul class="nav nav-collapse">
                                        <li>
                                            <a href="client">
                                                <span class="sub-item">Client</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="clientdocuments">
                                                <span class="sub-item">Client Documents</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="clientarchived">
                                                <span class="sub-item">Archived</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="shifts">
                                    <i class="fas fa-user-clock"></i>
                                    <p>Shifts</p>
                                </a>
                            </li>


                            <li class="nav-item">
                                <a data-toggle="collapse" href="#report">
                                    <i class="fas fa-book"></i>
                                    <p>Reports</p>
                                    <span class="caret"></span>
                                </a>
                                <div class="collapse" id="report">
                                    <ul class="nav nav-collapse">
                                        <li>
                                            <a href="activity-report">
                                                <span class="sub-item">Activity Report</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="work-experience-report">
                                                <span class="sub-item">Work Experience Report</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a data-toggle="collapse" href="#setting">
                                    <i class="fas fa-cog"></i>
                                    <p>Settings</p>
                                    <span class="caret"></span>
                                </a>
                                <div class="collapse" id="setting">
                                    <ul class="nav nav-collapse">
                                        <li>
                                            <a href="profile-setting">
                                                <span class="sub-item">Profile Setting</span>
                                            </a>
                                            <a href="change-password">
                                                <span class="sub-item">Change Password</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="log-out">
                                    <i class="fas fa-sign-out-alt"></i>
                                    <p>Logout</p>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- End Sidebar -->
            <script>
                $(".notification").html(<?php echo $total_notifications; ?>);
                $("#notification").html(<?php echo $total_notifications; ?>);
            </script>
            <?php 

            if(empty($_SESSION['id'])){
                session_unset();
                header('Location: ../login');
                exit();
            }

            ?>
<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");

$select_client = "SELECT * FROM client WHERE close = '1' AND status = '1'";
$select_client_ex = mysqli_query($con,$select_client);

$select_staff = "SELECT * FROM wt_users WHERE user_type = 'staff' AND close = '1' AND status = '1'";
$select_staff_ex = mysqli_query($con,$select_staff);

if (isset($_POST['show_shifts'])) {
  $shift_time1c = date('Y-m-d',strtotime($_POST['show_shifts']));

  $select_shifts = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id JOIN client ON shifts.s_client = client.c_id JOIN wt_users ON shifts.s_staff = wt_users.id WHERE wt_users.user_type = 'staff' AND shift_dates.sd_date = '".$shift_time1c."' AND shifts.close = '1' AND shifts.status = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'";
  $select_shifts_ex = mysqli_query($con,$select_shifts);

  foreach ($select_shifts_ex as $row) {
    ?>
    <div class="col-md-12 mb-3">
      <div class="py-2" style="border: 1px solid #ced4da; border-radius: 0.25rem; height: auto;">
        <input type="hidden" name="sr_id" value="<?php echo $sd_id ?>">
        <input type="hidden" name="shift_time" value="<?php echo $shift_time ?>">
        <div class="col-md-12 mb-4">
          <div class="col-md-6 float-left"><strong>Date: </strong><?php echo date('d-M-Y',strtotime($shift_time1c)) ?></div>
          <div class="col-md-6 float-left"><strong>Type: </strong><span><?php echo ucwords($row['s_shift_type']) ?></span></div>
        </div>
        <div class="col-md-12 mb-4">
          <div class="col-md-6 float-left"><strong>Client: </strong><span class="text-info"><?php echo ucwords($row['m_name']) ?></span></div>
          <div class="col-md-6 float-left"><strong>Staff: </strong><span class="text-info"><?php echo ucwords($row['f_name']." ".$row['l_name']) ?></span></div>
        </div>
        <div class="col-md-12 mb-4">
          <div class="col-md-6 float-left"><strong>From: </strong><span class="text-success"><?php echo date('h:i A',strtotime($row['s_starttime'])) ?></span></div>
          <div class="col-md-6 float-left"><strong>To: </strong><span class="text-danger"><?php echo date('h:i A',strtotime($row['s_endtime'])) ?></span></div>
        </div>
        <div class="col-md-12 mb-4">
          <div class="col-md-12 float-left"><strong>Address: </strong><span><?php echo $row['address'] ?></span></div>
        </div>
      </div>
    </div>
    <?php
  }
}

if (isset($_POST['show_shift3'])) {
  $sd_id = $_POST['show_shift3'];
  $shift_time = date('Y-m-d',strtotime($_POST['start_date']));

  $select_shifts = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id JOIN client ON shifts.s_client = client.c_id JOIN wt_users ON shifts.s_staff = wt_users.id WHERE wt_users.user_type = 'staff' AND shift_dates.sd_id = '".$sd_id."' AND shifts.close = '1' AND shifts.status = '1'";
  $select_shifts_ex = mysqli_query($con,$select_shifts);

  foreach ($select_shifts_ex as $row) {
   $s_shiftdate = $row['s_shiftdate'];
   $create_date=  date("d-M-Y", strtotime($row['create_date']));
   $shift_time_from=  date("g:i A", strtotime($row['s_starttime']));
   $shift_time_to=  date("g:i A", strtotime($row['s_endtime']));
   ?>
   <div class="col-md-12 pt-2 pb-2">
    <input type="hidden" name="sd_id" value="<?php echo $sd_id ?>">
    <input type="hidden" name="shift_time" value="<?php echo $shift_time ?>">
    <h3 style="font-weight: bolder; margin-bottom: 0px;"><?php echo ucwords($row['s_shift_type']); ?></h3>
    <span>Created on: <?php echo $create_date; ?></span>
  </div>
  <div class="col-md-12" style="background: #E7E8EA; padding: 30px 20px;">
    <button type="button" class="btn mb-5 ml-3" style="background: #4bd78a; border-radius: 10px; color: #fff; font-weight: bolder;">#00<?php echo $row['sd_id']; ?></button>
    <div class="col-md-12" style="background: #fff; padding: 20px; border-radius: 10px;">
      <h3 style="margin-bottom: 0px; font-weight: bolder;"><?php echo ucwords($row['f_name']." ".$row['l_name']) ?></h3>
      <span class="mb-3">(Client)</span>
      <hr>
      <div class="col-md-12 mb-2" style="padding: 0px;">
        <button type="button" class="btn mb-2" style="background: #aaabaf; border-radius: 10px; color: #fff; font-weight: bolder;">Amount</button><br>
        <span style="float: left; margin-left: 5px;">Expense(Amount)</span><span style="float: right; font-weight: bolder;"><?php echo $row['sd_expense']; ?></span>
      </div>

      <div class="col-md-12" style="padding: 30px 0px 20px 0px;">
        <button type="button" class="btn mb-2" style="background: #aaabaf; border-radius: 10px; color: #fff; font-weight: bolder;">Time and Location</button><br>
        <span><i class="fa fa-clock" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $shift_time_from; ?>-<?php echo $shift_time_to; ?></span><br>
        <span><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $row['sd_date']; ?></span><br>
        <span><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $row['s_address'];; ?></span>
      </div>

      <div class="col-md-12" style="padding: 0px 0px;">
        <button type="button" class="btn mb-2" style="background: #aaabaf; border-radius: 10px; color: #fff; font-weight: bolder;">Instructions</button><br>
        <span style="text-align: justify;"><?php echo ucwords($row['s_instructions']); ?></span>
      </div>
      
    </div>

  </div>
  <?php
}
}

if (isset($_POST['show_shift_for_accept'])) {
  $sd_id = $_POST['show_shift_for_accept'];
  $shift_time = date('Y-m-d',strtotime($_POST['start_date']));

  $select_shifts = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id JOIN client ON shifts.s_client = client.c_id JOIN wt_users ON client.wt_user_id = wt_users.id WHERE shift_dates.sd_id = '".$sd_id."' AND shifts.close = '1' AND shifts.status = '1'";
  $select_shifts_ex = mysqli_query($con,$select_shifts);

  foreach ($select_shifts_ex as $row) {
    $s_shiftdate = $row['s_shiftdate'];
    $create_date=  date("d-M-Y", strtotime($row['create_date']));
    $shift_time_from=  date("g:i A", strtotime($row['s_starttime']));
    $shift_time_to=  date("g:i A", strtotime($row['s_endtime']));
    ?>
    <div class="col-md-12 pt-2 pb-2">
      <input type="hidden" name="sd_id" value="<?php echo $sd_id ?>">
      <input type="hidden" name="s_id" value="<?php echo $row['s_id'] ?>">
      <input type="hidden" name="shift_time" value="<?php echo $shift_time ?>">
      <h3 style="font-weight: bolder; margin-bottom: 0px;"><?php echo ucwords($row['s_shift_type']); ?></h3>
      <span>Created on: <?php echo $create_date; ?></span>
    </div>
    <div class="col-md-12" style="background: #E7E8EA; padding: 30px 20px;">
      <button type="button" class="btn mb-5 ml-3" style="background: #4bd78a; border-radius: 10px; color: #fff; font-weight: bolder;">#00<?php echo $row['sd_id']; ?></button>
      <div class="col-md-12" style="background: #fff; padding: 20px; border-radius: 10px;">
        <h3 style="margin-bottom: 0px; font-weight: bolder;"><?php echo ucwords($row['f_name']." ".$row['l_name']) ?></h3>
        <span class="mb-3">(Client)</span>
        <hr>
        <div class="col-md-12 mb-2" style="padding: 0px;">
          <button type="button" class="btn mb-2" style="background: #aaabaf; border-radius: 10px; color: #fff; font-weight: bolder;">Amount</button><br>
          <span style="float: left; margin-left: 5px;">Expense(Amount)</span><span style="float: right; font-weight: bolder;"><?php echo $row['sd_expense']; ?></span>
        </div>

        <div class="col-md-12" style="padding: 30px 0px 20px 0px;">
          <button type="button" class="btn mb-2" style="background: #aaabaf; border-radius: 10px; color: #fff; font-weight: bolder;">Time and Location</button><br>
          <span><i class="fa fa-clock" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $shift_time_from; ?>-<?php echo $shift_time_to; ?></span><br>
          <span><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $row['sd_date']; ?></span><br>
          <span><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $row['s_address'];; ?></span>
        </div>

        <div class="col-md-12" style="padding: 0px 0px;">
          <button type="button" class="btn mb-2" style="background: #aaabaf; border-radius: 10px; color: #fff; font-weight: bolder;">Instructions</button><br>
          <span style="text-align: justify;"><?php echo ucwords($row['s_instructions']); ?></span>
        </div>

        <div class="mt-5">
          <button style="background: #4bd78a; color: #fff; border:none; border-radius: 10px;" type="submit" id="accept_shift" name="accept_shift" class="btn form-control col-md-12 mb-2"><span class="btn-label"><i class="fa fa-check"></i></span> Accept</button>
          <button style="border-radius: 10px;" type="submit" id="accept_shift" name="reject_shift" class="btn btn-danger form-control col-md-12"><span class="btn-label"><i class="fa fa-times"></i></span> Reject</button>
        </div>

      </div>

    </div>
    <?php
  }
}

if (isset($_POST['show_shift2'])) {
  $sd_id = $_POST['show_shift2'];
  $shift_time = date('Y-m-d',strtotime($_POST['start_date']));

  $select_shifts = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id JOIN client ON shifts.s_client = client.c_id JOIN wt_users ON shifts.s_staff = wt_users.id WHERE wt_users.user_type = 'staff' AND shift_dates.sd_id = '".$sd_id."' AND shifts.close = '1' AND shifts.status = '1'";
  $select_shifts_ex = mysqli_query($con,$select_shifts);

  foreach ($select_shifts_ex as $row) {
   $s_shiftdate = $row['s_shiftdate'];
   $create_date=  date("d-M-Y", strtotime($row['create_date']));
   $shift_time_from=  date("g:i A", strtotime($row['s_starttime']));
   $shift_time_to=  date("g:i A", strtotime($row['s_endtime']));
   ?>
   <div class="col-md-12 pt-2 pb-2">
    <input type="hidden" name="sd_id" id="cs_as_id_up" value="<?php echo $sd_id ?>">
    <input type="hidden" name="shift_time" id="cs_shift_time_up" value="<?php echo $shift_time ?>">
    <h3 style="font-weight: bolder; margin-bottom: 0px;"><?php echo ucwords($row['s_shift_type']); ?></h3>
    <span>Created on: <?php echo $create_date; ?></span>
  </div>
  <div class="col-md-12" style="background: #E7E8EA; padding: 30px 20px;">
    <button type="button" class="btn mb-5 ml-3" style="background: #4bd78a; border-radius: 10px; color: #fff; font-weight: bolder;">#00<?php echo $row['sd_id']; ?></button>
    <div class="col-md-12 mb-4" style="background: #fff; padding: 20px; border-radius: 10px;">
      <h3 style="margin-bottom: 0px; font-weight: bolder;"><?php echo ucwords($row['f_name']." ".$row['l_name']) ?></h3>
      <span class="mb-3">(Client)</span>
      <hr>
      <div class="col-md-12 mb-2" style="padding: 0px;">
        <button type="button" class="btn mb-2" style="background: #aaabaf; border-radius: 10px; color: #fff; font-weight: bolder;">Amount</button><br>
        <span style="float: left; margin-left: 5px;">Expense(Amount)</span><span style="float: right; font-weight: bolder;"><?php echo $row['sd_expense']; ?></span>
      </div>

      <div class="col-md-12" style="padding: 30px 0px 20px 0px;">
        <button type="button" class="btn mb-2" style="background: #aaabaf; border-radius: 10px; color: #fff; font-weight: bolder;">Time and Location</button><br>
        <span><i class="fa fa-clock" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $shift_time_from; ?>-<?php echo $shift_time_to; ?></span><br>
        <span><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $row['sd_date']; ?></span><br>
        <span><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $row['s_address'];; ?></span>
      </div>

      <div class="col-md-12" style="padding: 0px 0px;">
        <button type="button" class="btn mb-2" style="background: #aaabaf; border-radius: 10px; color: #fff; font-weight: bolder;">Instructions</button><br>
        <span style="text-align: justify;"><?php echo ucwords($row['s_instructions']); ?></span>
      </div>

    </div>

    <div class="col-md-12" style="background: #fff; padding: 20px; border-radius: 10px;">
      <div class="row">
        <div class="col-md-6 my-1">
          <label>Hours <span style="color: red;">*</span></label>
          <input id="cs_hour_up" class="form-control float-left" type="number" step="0.01" name="hour" required="required">
        </div>
        <div class="col-md-6 my-1">
          <label>Milage (Mile) <span style="color: red;">*</span></label>
          <input id="cs_milage_up" class="form-control float-left" type="number" step="0.01" name="milage" required="required" required="required">
        </div>
        <div class="col-md-12 my-1">
          <label>Expense <span style="color: red;">*</span></label>
          <input id="cs_expense_up" class="form-control float-left" type="number" name="expense" required="required">
        </div>
        <div class="col-md-12 my-1">
          <label>Note</label>
          <textarea id="cs_note_up" class="form-control" name="note" rows="5"></textarea>
        </div>
      </div>
       <div class="mt-5">
          <button style="border-radius: 10px; background: #4bd78a; color: #fff; border:none;" type="submit" id="complete_shift2" name="complete_shift2" class="btn form-control"><span class="btn-label"><i class="fa fa-check"></i></span> Completed</button>
        </div>

    </div>

  </div>
  <?php
}
}
?>
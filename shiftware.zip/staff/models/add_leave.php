<?php 
ob_start();
session_start();
include_once("../../env/main_config.php");




if (isset($_POST['leave_edit'])) {
    $leaveid = $_POST['leave_edit'];
    $userEdit = "SELECT * FROM leave_management WHERE lv_id = '".$leaveid."' AND close = '1' AND status = '1'";
    $userEdit_ex = mysqli_query($con,$userEdit);
    foreach($userEdit_ex as $row){
      ?>
      <fieldset class="scheduler-border">
                                                        <legend class="scheduler-border">
                                                            Leave Details <span class="req-data">*</span>
                                                        </legend>
      <div class="row">
         <input type="hidden" id="lv_id" name="lv_id" value="<?php echo $row['lv_id'] ?>">
          <div class="form-group col-md-12">
            <label for="emp_id_u">Requestor</label>
            <input type="text" id="emp_id_u" name="emp_id_u" value="<?php echo $_SESSION['user_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off" readonly>
        </div>

        <div class="form-group col-md-12">
            <label for="leavetype_u">Leave Type</label>
            <select class="form-control" name="leavetype_u" id="leavetype_u" onchange="checkleavetype_u();">
              <option class="text-center" value='<?php echo $row['leavetype']; ?>' selected><?php echo $row['leavetype']; ?></option>
              <option value='halfday'>Half Day</option>
              <option value='fullday'>Full Day</option>
              <option value='multidays'>Multiple Days</option>
          </select>
      </div>

      <div id="halfdayleavediv_u" class="col-md-12">
        <div class="row">
          <div class="form-group col-md-12">
          <label for="half_day_leave_date_u">Leave Date</label>
          <input type="date" id="half_day_leave_date_u" name="half_day_leave_date_u" value="<?php echo $row['half_day_leave_date']; ?>" class="form-control" autofocus autocomplete="off">
      </div>
          <div class="form-group col-md-6">
              <label for="half_day_leave_time_from_u">Leave Time From</label>
              <input type="time" id="half_day_leave_time_from_u" name="half_day_leave_time_from_u" value="<?php echo $row['half_day_leave_time_from']; ?>" class="form-control" autofocus autocomplete="off">
          </div>

          <div class="form-group col-md-6">
              <label for="half_day_leave_time_to_u">Leave Time To</label>
              <input type="time" id="half_day_leave_time_to_u" name="half_day_leave_time_to_u" value="<?php echo $row['half_day_leave_time_to']; ?>" class="form-control" autofocus autocomplete="off">
          </div>
        </div>
  </div>

  <div id="fulldayleavediv_u" class="col-md-12">
    <div class="form-group col-md-12">
      <label for="full_day_leave_date_u">Leave Date</label>
      <input type="date" id="full_day_leave_date_u" name="full_day_leave_date_u" value="<?php echo $row['full_day_leave_date']; ?>" class="form-control" autofocus autocomplete="off">
  </div>
</div>

<div id="multidaysleavediv_u" class="col-md-12">
    <div class="row">
      <div class="form-group col-md-12">
      <label for="multi_days_leave_date_from_u">Leave Date From</label>
      <input type="date" id="multi_days_leave_date_from_u" name="multi_days_leave_date_from_u" value="<?php echo $row['multi_days_leave_date_from']; ?>" class="form-control" autofocus autocomplete="off">
  </div>

  <div class="form-group col-md-12">
      <label for="multi_days_leave_date_to_u">Leave Date To</label>
      <input type="date" id="multi_days_leave_date_to_u" name="multi_days_leave_date_to_u" value="<?php echo $row['multi_days_leave_date_to']; ?>" class="form-control" autofocus autocomplete="off">
  </div>
    </div>
</div>

<div class="form-group col-md-12">
    <label for="leave_reason_u">Leave Reason</label>
    <textarea id="leave_reason_u" name="leave_reason_u" value="<?php echo $row['leave_reason']; ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off"><?php echo $row['leave_reason']; ?></textarea>
</div>
</div>
</fieldset>
<div class="modal-footer">
    <button type="submit" id="submitclient" name="editleave" class="btn btn-success"><span class="btn-label"><i class="fa fa-spinner"></i></span> Update</button>
</div>

<?php   
}
}











if (isset($_POST['leave_view'])) {
    $leaveid = $_POST['leave_view'];
    $userEdit = "SELECT * FROM leave_management WHERE lv_id = '".$leaveid."' AND close = '1' AND status = '1'";
    $userEdit_ex = mysqli_query($con,$userEdit);
    foreach($userEdit_ex as $row){
      ?>
      <fieldset class="scheduler-border">
                                                        <legend class="scheduler-border">
                                                            Leave Details <span class="req-data">*</span>
                                                        </legend>
      <div class="row">
          <div class="form-group col-md-12">
            <label for="emp_id_v">Requestor</label>
            <input type="text" id="emp_id_v" name="emp_id_v" value="<?php echo $_SESSION['user_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off" readonly>
        </div>

        <div class="form-group col-md-12">
            <label for="leavetype_v">Leave Type</label>
            <select class="form-control" name="leavetype_v" id="leavetype_v" onchange="checkleavetype_v();">
              <option class="text-center" value='<?php echo $row['leavetype']; ?>' selected><?php echo $row['leavetype']; ?></option>
              
          </select>
      </div>

      <div id="halfdayleavediv_v" class="col-md-12">
        <div class="row">
          <div class="form-group col-md-12">
          <label for="half_day_leave_date_v">Leave Date</label>
          <input type="date" id="half_day_leave_date_v" name="half_day_leave_date_v" value="<?php echo $row['half_day_leave_date']; ?>" class="form-control" autofocus autocomplete="off" readonly>
      </div>
          <div class="form-group col-md-6">
              <label for="half_day_leave_time_from_v">Leave Time From</label>
              <input type="time" id="half_day_leave_time_from_v" name="half_day_leave_time_from_v" value="<?php echo $row['half_day_leave_time_from']; ?>" class="form-control" autofocus autocomplete="off" readonly>
          </div>

          <div class="form-group col-md-6">
              <label for="half_day_leave_time_to_v">Leave Time To</label>
              <input type="time" id="half_day_leave_time_to_v" name="half_day_leave_time_to_v" value="<?php echo $row['half_day_leave_time_to']; ?>" class="form-control" autofocus autocomplete="off" readonly>
          </div>
        </div>
  </div>

  <div id="fulldayleavediv_v" class="col-md-12">
    <div class="form-group col-md-12">
      <label for="full_day_leave_date_v">Leave Date</label>
      <input type="date" id="full_day_leave_date_v" name="full_day_leave_date_v" value="<?php echo $row['full_day_leave_date']; ?>" class="form-control" autofocus autocomplete="off" readonly>
  </div>
</div>

<div id="multidaysleavediv_v" class="col-md-12">
    <div class="row">
      <div class="form-group col-md-12">
      <label for="multi_days_leave_date_from_v">Leave Date From</label>
      <input type="date" id="multi_days_leave_date_from_v" name="multi_days_leave_date_from_v" value="<?php echo $row['multi_days_leave_date_from']; ?>" class="form-control" autofocus autocomplete="off" readonly>
  </div>

  <div class="form-group col-md-12">
      <label for="multi_days_leave_date_to_v">Leave Date To</label>
      <input type="date" id="multi_days_leave_date_to_v" name="multi_days_leave_date_to_v" value="<?php echo $row['multi_days_leave_date_to']; ?>" class="form-control" autofocus autocomplete="off" readonly>
  </div>
    </div>
</div>

<div class="form-group col-md-12">
    <label for="leave_reason_v">Leave Reason</label>
    <textarea readonly id="leave_reason_v" name="leave_reason_u" value="<?php echo $row['leave_reason']; ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off"><?php echo $row['leave_reason']; ?></textarea>
</div>
</div>
</fieldset>


<?php   
}
}

?>
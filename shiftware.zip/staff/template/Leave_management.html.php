		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<!-- Card -->
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="card-head-row float-right">
										<button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-customs"><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Request Leave</button>
									</div>

									<!-- Modal -->
									<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                   <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                     <div class="modal-content">
                       <div class="modal-header">
                         <h3 class="modal-title" id="exampleModalLabel">Request Leave</h3>
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                         </button>
                       </div>
                       <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                        <div class="modal-body">
                          <fieldset class="scheduler-border">
                                                        <legend class="scheduler-border">
                                                            Leave Details <span class="req-data">*</span>
                                                        </legend>
                          <div class="row">
                            <div class="form-group col-md-12">
                              <label for="emp_id">Requestor</label>
                              <input type="text" id="emp_id" name="emp_id" value="<?php echo $_SESSION['user_name'] ?>" class="form-control" data-required="true" required="required" autofocus autocomplete="off" readonly>
                            </div>

                            <div class="form-group col-md-12">
                              <label for="leavetype">Leave Type</label>
                              <select class="form-control" name="leavetype" id="leavetype" onchange="checkleavetype();" required="">
                                <option class="text-center" value disabled selected>-----Select Option-----</option>
                                <option value='halfday'>Half Day</option>
                                <option value='fullday'>Full Day</option>
                                <option value='multidays'>Multiple Days</option>
                              </select>
                            </div>

                            <div id="halfdayleavediv" class="col-md-12">
                              <div class="row">
                                <div class="form-group col-md-12">
                                <label for="half_day_leave_date">Leave Date</label>
                                <input type="date" id="half_day_leave_date" name="half_day_leave_date" value="" class="form-control" autofocus autocomplete="off">
                              </div>
                                <div class="form-group col-md-6">
                                  <label for="half_day_leave_time_from">Leave Time From</label>
                                  <input type="time" id="half_day_leave_time_from" name="half_day_leave_time_from" value="" class="form-control" autofocus autocomplete="off">
                                </div>

                                <div class="form-group col-md-6">
                                  <label for="half_day_leave_time_to">Leave Time To</label>
                                  <input type="time" id="half_day_leave_time_to" name="half_day_leave_time_to" value="" class="form-control" autofocus autocomplete="off">
                                </div>
                              </div>
                            </div>

                            <div id="fulldayleavediv" class="col-md-12">
                              <div class="form-group col-md-12">
                                <label for="full_day_leave_date">Leave Date</label>
                                <input type="date" id="full_day_leave_date" name="full_day_leave_date" value="" class="form-control" autofocus autocomplete="off">
                              </div>
                            </div>

                            <div id="multidaysleavediv" class="col-md-12">
                              <div class="row">
                                <div class="form-group col-md-12">
                                <label for="multi_days_leave_date_from">Leave Date From</label>
                                <input type="date" id="multi_days_leave_date_from" name="multi_days_leave_date_from" value="" class="form-control" autofocus autocomplete="off">
                              </div>

                              <div class="form-group col-md-12">
                                <label for="multi_days_leave_date_to">Leave Date To</label>
                                <input type="date" id="multi_days_leave_date_to" name="multi_days_leave_date_to" value="" class="form-control" autofocus autocomplete="off">
                              </div>
                              </div>
                            </div>

                            <div class="form-group col-md-12">
                              <label for="leave_reason">Leave Reason</label>
                              <textarea id="leave_reason" name="leave_reason" value="" class="form-control" data-required="true" required="required" autofocus autocomplete="off"></textarea>
                            </div>
                          </div>
                        </fieldset>


                        </div>
                        <div class="modal-footer">
                          <button type="submit" id="submitleave" name="submitleave" class="btn btn-customs"><span class="btn-label"><i class="fa fa-spinner"></i></span> Submit</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>

                <button id="updateUser1" type="button" data-toggle="modal" data-target="#exampleModal1" class="btn btn-success" hidden><span class="btn-label"><i class="fa fa-plus-circle"></i></span> Update Leave</button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1" aria-hidden="true">
                 <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                   <div class="modal-content">
                     <div class="modal-header">
                       <h3 class="modal-title modal-head" id="exampleModalLabel1">Update Leave</h3>
                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                         <span aria-hidden="true">&times;</span>
                       </button>
                     </div>
                     <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
                      <div class="modal-body updateuser">

                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-body">
              <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                  <tr>
                    <th>S/No</th>
                    <th>Request Application Date</th>
                    <th>Leave type</th>
                    <th>Leave Reason</th>
                    <th>Status</th>
                    <th>Options</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $sr = 1;
                  foreach ($res_data_ex as $row) {
                    ?>
                    <tr id="<?php echo $row['lv_id']; ?>">
                      <?php 
                      echo "<td>".$sr."</td><td>".date("d-M-Y", strtotime($row['leave_create_date']))."</td><td>".ucwords($row['leavetype'])."</td><td class='ellipsis'>".$row['leave_reason']."</td>";
                      if ($row['leave_status'] == '0') {
                        $leavestatus = 'Pending';
                        echo"<td style='font-weight:bolder; color:brown;'>".$leavestatus."<input type='hidden' id='id-lv-id' value='".$row['lv_id']."'></td>";
                      }
                      if ($row['leave_status'] == '1') {
                        $leavestatus = 'Declined';
                        echo"<td style='font-weight:bolder; color:red;'>".$leavestatus."<input type='hidden' id='id-lv-id' value='".$row['lv_id']."'></td>";
                      }
                      if ($row['leave_status'] == '2') {
                        $leavestatus = 'Granted';
                        echo"<td style='font-weight:bolder; color:green;'>".$leavestatus."<input type='hidden' id='id-lv-id' value='".$row['lv_id']."'></td>";
                      }


                      ?>
                      <td><button class="btn btn-success btn-view" style="padding: 9px 5px; border-radius: 3px;"><i class="ml-1 fa fa-eye fa-lg" aria-hidden="true"></i></button> &nbsp;
                        <?php 
                        if ($row['leave_status'] == '0') {
                          ?>
                          <button class="btn btn-info btn-edit" style="padding: 9px 5px; border-radius: 3px;"><i class="ml-1 fa fa-edit fa-lg" aria-hidden="true"></i></button>
                        <?php } ?>
                      </td>
                    </tr>
                    <?php 
                    $sr++;
                  }?>
                </tbody>
                <tfoot>
                  <tr>
                   <th>S/No</th>
                   <th>Request Application Date</th>
                   <th>Leave type</th>
                   <th>Leave Reason</th>
                   <th>Status</th>
                   <th>Options</th>
                 </tr>
               </tfoot>
             </table>
           </div>
         </div>
       </div>
     </div>
   </div>
 </div>
</div>
<script>
	const Printcol = [0,1,2,3,4];
  var title = '<img src="../assets/img/logo.jpg" width="170"><h4 class="page-title text-center"><?php  echo $head_title1 = ucwords(substr(strstr(str_replace("_", " ", $head_title)," "), 1));  ?>s Report</h4>';
  $(document).ready(function(){
    $('.btn-edit').click(function(e){
     $('.modal-head').text('Update Client');
     e.preventDefault();
     var iduser = $(this).closest("tr").find("#id-lv-id").val();
     $.ajax({
      type: "POST",
      url: "models/add_leave.php",
      data:'leave_edit='+iduser,
      success: function(data){
        $(".updateUser").html(data);
        $('#updateUser1').trigger('click');
        checkleavetype_u();
      }
    });
   });
  });

  $(document).ready(function() {
    $('.btn-view').click(function(e) {
      $('.modal-head').text('View Client');
      e.preventDefault();
      var iduser = $(this).closest("tr").find("#id-lv-id").val();
      $.ajax({
        type: "POST",
        url: "models/add_leave.php",
        data: 'leave_view=' + iduser,
        success: function(data) {
          $(".updateUser").html(data);
          $('#updateUser1').trigger('click');
          checkleavetype_v();
        }
      });
    });

    function checkleavetype_v() {
     var leavetype = $("#leavetype_v").val();
     //alert(leavetype);
     if (leavetype == 'halfday') {
      $('#multidaysleavediv_v').hide();
      $('#fulldayleavediv_v').hide();
      $('#halfdayleavediv_v').show();
    } else if (leavetype == 'fullday') {
      $('#multidaysleavediv_v').hide();
      $('#fulldayleavediv_v').show();
      $('#halfdayleavediv_v').hide();
    } else if (leavetype == 'multidays') {
      $('#multidaysleavediv_v').show();
      $('#fulldayleavediv_v').hide();
      $('#halfdayleavediv_v').hide();
    }
  }
});


  $('#multidaysleavediv').hide();
  $('#fulldayleavediv').hide();
  $('#halfdayleavediv').hide();
  function checkleavetype(){
    var leavetype = $("#leavetype").val();
    if (leavetype == 'halfday') {
      $('#multidaysleavediv').hide();
      $('#fulldayleavediv').hide();
      $('#halfdayleavediv').show();
    }
    else if (leavetype == 'fullday') {
      $('#multidaysleavediv').hide();
      $('#fulldayleavediv').show();
      $('#halfdayleavediv').hide();
    }
    else if (leavetype == 'multidays') {
      $('#multidaysleavediv').show();
      $('#fulldayleavediv').hide();
      $('#halfdayleavediv').hide();
    }
  }


  function checkleavetype_u(){
    var leavetype = $("#leavetype_u").val();
    if (leavetype == 'halfday') {
      $('#multidaysleavediv_u').hide();
      $('#fulldayleavediv_u').hide();
      $('#halfdayleavediv_u').show();
    }
    else if (leavetype == 'fullday') {
      $('#multidaysleavediv_u').hide();
      $('#fulldayleavediv_u').show();
      $('#halfdayleavediv_u').hide();
    }
    else if (leavetype == 'multidays') {
      $('#multidaysleavediv_u').show();
      $('#fulldayleavediv_u').hide();
      $('#halfdayleavediv_u').hide();
    }
  }





</script>
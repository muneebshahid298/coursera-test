<style>
  td{
    width: 80px;
    height: 80px;
    background: #4BD78A;
    text-align: center;
    color: #fff;
    padding: 5px 21px;
    border-radius: 15%;
    border:5px solid #fff;
  }
  .datesdiv{
    overflow: scroll;
  }


  /* Hide scrollbar for Chrome, Safari and Opera */
  .datesdiv::-webkit-scrollbar {
    display: none;
  }

  /* Hide scrollbar for IE, Edge and Firefox */
  .datesdiv {
    -ms-overflow-style: none;  /* IE and Edge */
    scrollbar-width: none;  /* Firefox */
  }
  .shiftsondate{
    margin: 20px 15px;
  }
  .shift-detail{
    background: #fff;
    height: 200px; 
    border-radius: 10px;
    padding: 10px;
    margin-bottom: 15px;
    box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;
  }
    a{
      text-decoration: none;
      color: #000;
    }

  </style>
  <div class="main-panel">
   <div class="content">
    <div class="page-inner">

     <button class="btn btn-Success search green_back" style="float: right; border-radius: 3px;" data-toggle="modal" data-target="#shiftaccept" id="shiftaccept1" hidden>aaaaa</button>
     <div class="modal fade" id="shiftaccept" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-dialog-slideout" style="margin: 0px;">
        <div class="modal-content">
          <div class="modal-header" style="background: #fff;">
            <h2 class="modal-title" style="text-align: center;">Respond to Shift</h2>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times" aria-hidden="true"></i></button>
          </div>
          <form action="" method="post" enctype="multipart/form-data" class="was-validated" autocomplete="off">
            <div class="modal-body selected_start_time3" style="padding: 0px;">

            </div>

          </form>     
        </div>
      </div>
    </div>



    <button class="btn btn-Success search green_back" style="float: right; border-radius: 3px;" data-toggle="modal" data-target="#shiftslot" id="shiftslot1" hidden>aaaaa</button>
    <div class="modal fade" id="shiftslot" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-dialog-slideout" style="margin: 0px;">
        <div class="modal-content">
          <div class="modal-header bg-light">
            <h4 class="modal-title">View Shifts</h4>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times" aria-hidden="true"></i></button>
          </div>
          <div class="modal-body selected_start_time">

          </div>     
        </div>
      </div>
    </div>


    <button class="btn btn-Success search green_back" style="float: right; border-radius: 3px;" data-toggle="modal" data-target="#shiftcomplete" id="shiftcomplete1" hidden>aaaaa</button>
    <div class="modal fade" id="shiftcomplete" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-dialog-slideout" style="margin: 0px;">
        <div class="modal-content">
          <div class="modal-header bg-light">
            <h4 class="modal-title">Compete Shift</h4>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times" aria-hidden="true"></i></button>
          </div>
          <form action="" method="post" enctype="multipart/form-data" class="was-validated" onsubmit="openModal()" id="completeform">
            <div class="modal-body selected_start_time2">

            </div>

          </form>     
        </div>
      </div>
    </div>

    <div class="modal fade" id="ratingmodal" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-dialog-slideout" style="margin: 0px;">
        <div class="modal-content">
          <div class="modal-header bg-light">
            <h4 class="modal-title">Rating</h4>

          </div>
          <form action="" method="post" enctype="multipart/form-data" class="was-validated">
            <div class="modal-body">
              <input type="hidden" id="rating_as_id" name="sd_id">
              <input type="hidden" id="rating_shift_time" name="shift_time">
              <input id="rating_hour" type="hidden" step="0.01" name="hour">
              <input id="rating_milage" type="hidden" step="0.01" name="milage">
              <input id="rating_expense" type="hidden" name="expense">
              <textarea id="rating_note" name="note" rows="5" hidden=""></textarea>
              <div class="col-md-12 my-1 text-center">
                <label><h3>Please Rate this shift</h3></label>
                <input id="rating" class="form-control float-left" type="number" name="rating" value="0" required="required" style="display: none;">
              </div>
              <div class = "col-md-12 text-center">
               <div class = "con">
                <i class = "far fa-star fa-lg emoji" aria-hidden = "true" id = "st1"></i>
                <i class = "far fa-star fa-lg emoji" aria-hidden = "true" id = "st2"></i>
                <i class = "far fa-star fa-lg emoji" aria-hidden = "true" id = "st3"></i>
                <i class = "far fa-star fa-lg emoji" aria-hidden = "true" id = "st4"></i>
                <i class = "far fa-star fa-lg emoji" aria-hidden = "true" id = "st5"></i>
              </div>
            </div>
            <div id="rating_feedback" class = "col-md-12 text-center mt-4" style="display: none;">
              <label><h3>Rating Feedback</h3></label>
              <textarea class="form-control" name="rating_feedback"></textarea>
            </div>
            <script>
              $(document).ready(function() {
                $("#st1").click(function() {
                  $(".emoji").css("color", "black");
                  $("#st1").css("color", "#E00400");
                  $("#rating").val(1);
                  $("#rating_feedback").show();

                });
                $("#st2").click(function() {
                  $(".emoji").css("color", "black");
                  $("#st1, #st2").css("color", "#E66300");
                  $("#rating").val(2);
                  $("#rating_feedback").show();

                });
                $("#st3").click(function() {
                  $(".emoji").css("color", "black")
                  $("#st1, #st2, #st3").css("color", "#F8B912");
                  $("#rating").val(3);
                  $("#rating_feedback").show();

                });
                $("#st4").click(function() {
                  $(".emoji").css("color", "black");
                  $("#st1, #st2, #st3, #st4").css("color", "#BDD600");
                  $("#rating").val(4);
                  $("#rating_feedback").show();

                });
                $("#st5").click(function() {
                  $(".emoji").css("color", "black");
                  $("#st1, #st2, #st3, #st4, #st5").css("color", "#6CCA07");
                  $("#rating").val(5);
                  $("#rating_feedback").show();

                });
              });
            </script>
          </div>
          <div class="modal-footer">
            <button type="submit" id="complete_shift" name="complete_shift" class="btn btn-success form-control mb-2 mx-0"><span class="btn-label"><i class="fa fa-check"></i></span> Submit Rating</button>
            <button type="submit" id="complete_shift" name="complete_shift_withoutrating" class="btn btn-danger form-control mx-0"><span class="btn-label"><i class="fa fa-times"></i></span> Go Without Rating</button>
          </div>
        </form>     
      </div>
    </div>
  </div>



  <!-- Card -->
  <div class="row">
    <div class="col-md-12">
     <div class="card">
      <h1 style="font-weight: bolder; margin-left: 20px;">Shifts</h1>
      <div class="datesdiv">
        <table>
          <tr>
            <?php 
            $current_date = date("Y-m-d");
            ?>
            <div class="borderboxdiv">
              <td id="<?php echo $current_date; ?>" onclick="getdateshifts('<?php echo $current_date; ?>');">
                <span><?php echo date('M'); ?></span>
                <h3><?php echo date('d'); ?></h3>
                <span><?php echo date('Y'); ?></span>
              </td>
            </div>
            <?php
            $date = date('Y-m-d');
            for($i =1; $i <= 305; $i++){
              $date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
              $shift_date=  date("d", strtotime($date));
              $shift_month=  date("M", strtotime($date));
              $shift_year=  date("Y", strtotime($date));
              ?>
              <td id="<?php echo $date; ?>" onclick="getdateshifts('<?php echo $date; ?>');">
                <span><?php echo $shift_month; ?></span>
                <h3><?php echo $shift_date; ?></h3>
                <span><?php echo $shift_year; ?></span>
              </td>
              <?php
            }
            ?>

          </tr>
        </table>
      </div>
    </div>
    <?php
    if(isset($_GET['shiftsdate'])) {
      $shiftsdate = $_GET['shiftsdate'];
      ?>
      <div class="shiftsondate">
        <div class="row">
          <?php 
          $db->Select("*");
          $db->From("shifts");
          $db->Join("shift_dates");
          $db->ON("shifts.s_id","shift_dates.sd_s_id");
          $db->Join("client");
          $db->ON("shifts.s_client","client.c_id");
          $db->Join("wt_users");
          $db->ON("client.wt_user_id","wt_users.id");
          $db->Where("shift_dates.sd_date = '".$shiftsdate."' AND shifts.close = '1' AND shifts.status = '1' AND CONCAT(',', shifts.s_staff, ',') LIKE CONCAT('%,', '".$_SESSION['id']."', ',%')");
          $res_data_ex = $db->result();
          foreach ($res_data_ex as $row) {
            $shift_time_from=  date("g:i A", strtotime($row['s_starttime']));
            $shift_time_to=  date("g:i A", strtotime($row['s_endtime']));
            $shift_status = 0;
            $sd_complete = $row['sd_complete'];
            $sd_reject = $row['sd_reject'];
            if ($sd_reject == '0' && $sd_complete == '0') { ?>

              <div class="form-group col-md-12 shift-detail">
                <div class="row">
                  <div class="shiftclientimg col-md-2 col-sm-2 mb-3" style="width: 20%;"><img src="../files/<?php echo $row['profile_img']; ?>" style="height: 40px; width: 40px; float: left; border-radius: 50%;">
                  </div>
                  <div class="shiftdetail col-md-10 col-sm-10 mb-3" style="width: 80%; text-align: left;">
                    <h3 style="font-weight: bolder; margin-bottom: 0px;"><?php echo ucwords($row['prefix']." ".$row['f_name']." ".$row['l_name']); ?></h3><span style="font-size: smaller;">(Client)</span>
                  </div>
                  <div class="shiftclientimg col-md-6 col-sm-6 mb-3" style="width: 50%;">
                    <h5 style="font-weight: bolder; margin-bottom: 0px;">Time:</h5><span><?php echo $shift_time_from; ?>-<?php echo $shift_time_to; ?></span>
                  </div>
                  <div class="shiftdetail col-md-6 col-sm-6 mb-3" style="width: 50%; text-align: left;">
                    <h5 style="font-weight: bolder; margin-bottom: 0px;">Date:</h5><span><?php echo $row['sd_date']; ?></span>
                  </div>
                  <div class="shiftclientimg col-md-7 col-sm-7" style="width: 50%;">
                    <h5 style="font-weight: bolder; margin-bottom: 0px;">Shift Status:</h5><span style="color: #4bd78a;">Pending</span>
                  </div>
                  <div class="shiftdetail col-md-5 col-sm-5" style="width: 50%; text-align: left;">
                    <button onclick="respond_shift('<?php echo $row['sd_id']; ?>','<?php echo $row['sd_date']; ?>');" style="border-radius: 20px;" class="btn">Details &nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></button>
                  </div>                
                </div>
              </div>
            <?php }
            elseif ($sd_complete == '1') { ?>
              <div class="form-group col-md-12 shift-detail">
               <div class="row">
                <div class="shiftclientimg col-md-2 col-sm-2 mb-3" style="width: 20%;"><img src="../files/<?php echo $row['profile_img']; ?>" style="height: 40px; width: 40px; float: left; border-radius: 50%;">
                </div>
                <div class="shiftdetail col-md-10 col-sm-10 mb-3" style="width: 80%; text-align: left;">
                  <h3 style="font-weight: bolder; margin-bottom: 0px;"><?php echo ucwords($row['prefix']." ".$row['f_name']." ".$row['l_name']); ?></h3><span style="font-size: smaller;">(Client)</span>
                </div>
                <div class="shiftclientimg col-md-6 col-sm-6 mb-3" style="width: 50%;">
                  <h5 style="font-weight: bolder; margin-bottom: 0px;">Time:</h5><span><?php echo $shift_time_from; ?>-<?php echo $shift_time_to; ?></span>
                </div>
                <div class="shiftdetail col-md-6 col-sm-6 mb-3" style="width: 50%; text-align: left;">
                  <h5 style="font-weight: bolder; margin-bottom: 0px;">Date:</h5><span><?php echo $row['sd_date']; ?></span>
                </div>
                <div class="shiftclientimg col-md-7 col-sm-7" style="width: 50%;">
                  <h5 style="font-weight: bolder; margin-bottom: 0px;">Shift Status:</h5><span style="color: #4bd78a;">Accepted</span>
                </div>
                <div class="shiftdetail col-md-5 col-sm-5" style="width: 50%; text-align: left;">
                  <button onclick="shiftcomplete('<?php echo $row['sd_id']; ?>','<?php echo $row['sd_date']; ?>');" style="border-radius: 20px;" class="btn">Details &nbsp;&nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></button>
                </div>                
              </div>
            </div>
          <?php }
          elseif ($sd_complete == '2') { ?>
           <div class="form-group col-md-12 shift-detail">
            <div class="row">
              <div class="shiftclientimg col-md-2 col-sm-2 mb-3" style="width: 20%;"><img src="../files/<?php echo $row['profile_img']; ?>" style="height: 40px; width: 40px; float: left; border-radius: 50%;">
              </div>
              <div class="shiftdetail col-md-10 col-sm-10 mb-3" style="width: 80%; text-align: left;">
                <h3 style="font-weight: bolder; margin-bottom: 0px;"><?php echo ucwords($row['prefix']." ".$row['f_name']." ".$row['l_name']); ?></h3><span style="font-size: smaller;">(Client)</span>
              </div>
              <div class="shiftclientimg col-md-6 col-sm-6 mb-3" style="width: 50%;">
                <h5 style="font-weight: bolder; margin-bottom: 0px;">Time:</h5><span><?php echo $shift_time_from; ?>-<?php echo $shift_time_to; ?></span>
              </div>
              <div class="shiftdetail col-md-6 col-sm-6 mb-3" style="width: 50%; text-align: left;">
                <h5 style="font-weight: bolder; margin-bottom: 0px;">Date:</h5><span><?php echo $row['sd_date']; ?></span>
              </div>
              <div class="shiftclientimg col-md-7 col-sm-7" style="width: 50%;">
                <h5 style="font-weight: bolder; margin-bottom: 0px;">Shift Status:</h5><span style="color: #4bd78a;">Completed</span>
              </div>
              <div class="shiftdetail col-md-5 col-sm-5" style="width: 50%; text-align: left;">
                <button onclick="shiftdetailonly('<?php echo $row['sd_id']; ?>','<?php echo $row['sd_date']; ?>');" style="border-radius: 20px;" class="btn">Details &nbsp;&nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></button>
              </div>                
            </div>
          </div>
        <?php }
        elseif ($sd_reject == '1') { ?>
          <div class="form-group col-md-12 shift-detail">
            <div class="row">
              <div class="shiftclientimg col-md-2 col-sm-2 mb-3" style="width: 20%;"><img src="../files/<?php echo $row['profile_img']; ?>" style="height: 40px; width: 40px; float: left; border-radius: 50%;">
              </div>
              <div class="shiftdetail col-md-10 col-sm-10 mb-3" style="width: 80%; text-align: left;">
                <h3 style="font-weight: bolder; margin-bottom: 0px;"><?php echo ucwords($row['prefix']." ".$row['f_name']." ".$row['l_name']); ?></h3><span style="font-size: smaller;">(Client)</span>
              </div>
              <div class="shiftclientimg col-md-6 col-sm-6 mb-3" style="width: 50%;">
                <h5 style="font-weight: bolder; margin-bottom: 0px;">Time:</h5><span><?php echo $shift_time_from; ?>-<?php echo $shift_time_to; ?></span>
              </div>
              <div class="shiftdetail col-md-6 col-sm-6 mb-3" style="width: 50%; text-align: left;">
                <h5 style="font-weight: bolder; margin-bottom: 0px;">Date:</h5><span><?php echo $row['sd_date']; ?></span>
              </div>
              <div class="shiftclientimg col-md-7 col-sm-7" style="width: 50%;">
                <h5 style="font-weight: bolder; margin-bottom: 0px;">Shift Status:</h5><span style="color: #4bd78a;">Rejected</span>
              </div>
              <div class="shiftdetail col-md-5 col-sm-5" style="width: 50%; text-align: left;">
                <button onclick="shiftdetailonly('<?php echo $row['sd_id']; ?>','<?php echo $row['sd_date']; ?>');" style="border-radius: 20px;" class="btn">Details &nbsp;&nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></button>
              </div>                
            </div>
          </div>
        <?php }
      } ?>



    </div>
  </div>
  <?php 
}

else{
  $current_date = date("Y-m-d");
  ?>
  <div class="shiftsondate">
    <div class="row">
      <?php 
      $db->Select("*");
      $db->From("shifts");
      $db->Join("shift_dates");
      $db->ON("shifts.s_id","shift_dates.sd_s_id");
      $db->Join("client");
      $db->ON("shifts.s_client","client.c_id");
      $db->Join("wt_users");
      $db->ON("client.wt_user_id","wt_users.id");
      $db->Where("shift_dates.sd_date = '".$current_date."' AND shifts.close = '1' AND shifts.status = '1' AND CONCAT(',', shifts.s_staff, ',') LIKE CONCAT('%,', '".$_SESSION['id']."', ',%')");
      $select_shift_ex = $db->result();
      foreach ($select_shift_ex as $row) {
        $shift_time_from=  date("g:i A", strtotime($row['s_starttime']));
        $shift_time_to=  date("g:i A", strtotime($row['s_endtime']));
        $shift_status = 0;
        $sd_complete = $row['sd_complete'];
        $sd_reject = $row['sd_reject'];
        if ($sd_reject == '0' && $sd_complete == '0') { ?>

          <div class="form-group col-md-12 shift-detail">
            <div class="row">
              <div class="shiftclientimg col-md-2 col-sm-2 mb-3" style="width: 20%;"><img src="../files/<?php echo $row['profile_img']; ?>" style="height: 40px; width: 40px; float: left; border-radius: 50%;">
              </div>
              <div class="shiftdetail col-md-10 col-sm-10 mb-3" style="width: 80%; text-align: left;">
                <h3 style="font-weight: bolder; margin-bottom: 0px;"><?php echo ucwords($row['prefix']." ".$row['f_name']." ".$row['l_name']); ?></h3><span style="font-size: smaller;">(Client)</span>
              </div>
              <div class="shiftclientimg col-md-6 col-sm-6 mb-3" style="width: 50%;">
                <h5 style="font-weight: bolder; margin-bottom: 0px;">Time:</h5><span><?php echo $shift_time_from; ?>-<?php echo $shift_time_to; ?></span>
              </div>
              <div class="shiftdetail col-md-6 col-sm-6 mb-3" style="width: 50%; text-align: left;">
                <h5 style="font-weight: bolder; margin-bottom: 0px;">Date:</h5><span><?php echo $row['sd_date']; ?></span>
              </div>
              <div class="shiftclientimg col-md-7 col-sm-7" style="width: 50%;">
                <h5 style="font-weight: bolder; margin-bottom: 0px;">Shift Status:</h5><span style="color: #4bd78a;">Pending</span>
              </div>
              <div class="shiftdetail col-md-5 col-sm-5" style="width: 50%; text-align: left;">
                <button onclick="respond_shift('<?php echo $row['sd_id']; ?>','<?php echo $row['sd_date']; ?>');" style="border-radius: 20px;" class="btn">Details &nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></button>
              </div>                
            </div>
          </div>
        <?php }
        elseif ($sd_complete == '1') { ?>
          <div class="form-group col-md-12 shift-detail">
           <div class="row">
            <div class="shiftclientimg col-md-2 col-sm-2 mb-3" style="width: 20%;"><img src="../files/<?php echo $row['profile_img']; ?>" style="height: 40px; width: 40px; float: left; border-radius: 50%;">
            </div>
            <div class="shiftdetail col-md-10 col-sm-10 mb-3" style="width: 80%; text-align: left;">
              <h3 style="font-weight: bolder; margin-bottom: 0px;"><?php echo ucwords($row['prefix']." ".$row['f_name']." ".$row['l_name']); ?></h3><span style="font-size: smaller;">(Client)</span>
            </div>
            <div class="shiftclientimg col-md-6 col-sm-6 mb-3" style="width: 50%;">
              <h5 style="font-weight: bolder; margin-bottom: 0px;">Time:</h5><span><?php echo $shift_time_from; ?>-<?php echo $shift_time_to; ?></span>
            </div>
            <div class="shiftdetail col-md-6 col-sm-6 mb-3" style="width: 50%; text-align: left;">
              <h5 style="font-weight: bolder; margin-bottom: 0px;">Date:</h5><span><?php echo $row['sd_date']; ?></span>
            </div>
            <div class="shiftclientimg col-md-7 col-sm-7" style="width: 50%;">
              <h5 style="font-weight: bolder; margin-bottom: 0px;">Shift Status:</h5><span style="color: #4bd78a;">Accepted</span>
            </div>
            <div class="shiftdetail col-md-5 col-sm-5" style="width: 50%; text-align: left;">
              <button onclick="shiftcomplete('<?php echo $row['sd_id']; ?>','<?php echo $row['sd_date']; ?>');" style="border-radius: 20px;" class="btn">Details &nbsp;&nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></button>
            </div>                
          </div>
        </div>
      <?php }
      elseif ($sd_complete == '2') { ?>
       <div class="form-group col-md-12 shift-detail">
        <div class="row">
          <div class="shiftclientimg col-md-2 col-sm-2 mb-3" style="width: 20%;"><img src="../files/<?php echo $row['profile_img']; ?>" style="height: 40px; width: 40px; float: left; border-radius: 50%;">
          </div>
          <div class="shiftdetail col-md-10 col-sm-10 mb-3" style="width: 80%; text-align: left;">
            <h3 style="font-weight: bolder; margin-bottom: 0px;"><?php echo ucwords($row['prefix']." ".$row['f_name']." ".$row['l_name']); ?></h3><span style="font-size: smaller;">(Client)</span>
          </div>
          <div class="shiftclientimg col-md-6 col-sm-6 mb-3" style="width: 50%;">
            <h5 style="font-weight: bolder; margin-bottom: 0px;">Time:</h5><span><?php echo $shift_time_from; ?>-<?php echo $shift_time_to; ?></span>
          </div>
          <div class="shiftdetail col-md-6 col-sm-6 mb-3" style="width: 50%; text-align: left;">
            <h5 style="font-weight: bolder; margin-bottom: 0px;">Date:</h5><span><?php echo $row['sd_date']; ?></span>
          </div>
          <div class="shiftclientimg col-md-7 col-sm-7" style="width: 50%;">
            <h5 style="font-weight: bolder; margin-bottom: 0px;">Shift Status:</h5><span style="color: #4bd78a;">Completed</span>
          </div>
          <div class="shiftdetail col-md-5 col-sm-5" style="width: 50%; text-align: left;">
            <button onclick="shiftdetailonly('<?php echo $row['sd_id']; ?>','<?php echo $row['sd_date']; ?>');" style="border-radius: 20px;" class="btn">Details &nbsp;&nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></button>
          </div>                
        </div>
      </div>
    <?php }
    elseif ($sd_reject == '1') { ?>
      <div class="form-group col-md-12 shift-detail">
        <div class="row">
          <div class="shiftclientimg col-md-2 col-sm-2 mb-3" style="width: 20%;"><img src="../files/<?php echo $row['profile_img']; ?>" style="height: 40px; width: 40px; float: left; border-radius: 50%;">
          </div>
          <div class="shiftdetail col-md-10 col-sm-10 mb-3" style="width: 80%; text-align: left;">
            <h3 style="font-weight: bolder; margin-bottom: 0px;"><?php echo ucwords($row['prefix']." ".$row['f_name']." ".$row['l_name']); ?></h3><span style="font-size: smaller;">(Client)</span>
          </div>
          <div class="shiftclientimg col-md-6 col-sm-6 mb-3" style="width: 50%;">
            <h5 style="font-weight: bolder; margin-bottom: 0px;">Time:</h5><span><?php echo $shift_time_from; ?>-<?php echo $shift_time_to; ?></span>
          </div>
          <div class="shiftdetail col-md-6 col-sm-6 mb-3" style="width: 50%; text-align: left;">
            <h5 style="font-weight: bolder; margin-bottom: 0px;">Date:</h5><span><?php echo $row['sd_date']; ?></span>
          </div>
          <div class="shiftclientimg col-md-7 col-sm-7" style="width: 50%;">
            <h5 style="font-weight: bolder; margin-bottom: 0px;">Shift Status:</h5><span style="color: #4bd78a;">Rejected</span>
          </div>
          <div class="shiftdetail col-md-5 col-sm-5" style="width: 50%; text-align: left;">
            <button onclick="shiftdetailonly('<?php echo $row['sd_id']; ?>','<?php echo $row['sd_date']; ?>');" style="border-radius: 20px;" class="btn">Details &nbsp;&nbsp;<i class="fa fa-arrow-right" aria-hidden="true"></i></button>
          </div>                
        </div>
      </div>
    <?php } } ?>



  </div>
</div>
<?php 
}
?>

</div>
</div>
</div>

</div>
</div>
<script type="text/javascript">
  $('#completeform').on('submit', function(e){
    var as_id = $("#cs_as_id_up").val();
    var shift_time = $("#cs_shift_time_up").val();
    var hour = $("#cs_hour_up").val();
    var milage = $("#cs_milage_up").val();
    var expense = $("#cs_expense_up").val();
    var note = $("#cs_note_up").val();

    $("#rating_as_id").val(as_id);
    $("#rating_shift_time").val(shift_time);
    $("#rating_hour").val(hour);
    $("#rating_milage").val(milage);
    $("#rating_expense").val(expense);
    $("#rating_note").html(note);

    $('#shiftcomplete').modal('hide');
    $('#ratingmodal').modal('show');
    e.preventDefault();
  });
</script>
<script type="text/javascript">
  function getdateshifts(shiftdate){
   var shiftdate = shiftdate;
   // alert(shiftdate);
   location.href = "shifts?shiftsdate="+shiftdate;
   document.getElementById(shiftdate).style.backgroundColor='#90e5b5';
 }

 function respond_shift(id,shifttime2){
   var id = id;
   var shifttime2 = shifttime2;
   $.ajax({
    type: "POST",
    url: "models/shifts_edit.php",
    data:{
      show_shift_for_accept:id,
      start_date:shifttime2
    },
    success: function(data){
      $(".selected_start_time3").html(data);
      $('#shiftaccept1').trigger('click');
    }
  });
 }

 function shiftcomplete(id,shifttime2){
  $.ajax({
    type: "POST",
    url: "models/shifts_edit.php",
    data:{
      show_shift2:id,
      start_date:shifttime2
    },
    success: function(data){
      $(".selected_start_time2").html(data);
      $('#shiftcomplete1').trigger('click');
    }
  });
}
function shiftdetailonly(id,shifttime2){
  var id = id;
  var shifttime2 = shifttime2;
  $.ajax({
    type: "POST",
    url: "models/shifts_edit.php",
    data:{
      show_shift3:id,
      start_date:shifttime2
    },
    success: function(data){
      $(".selected_start_time").html(data);
      $('#shiftslot1').trigger('click');
    }
  });
}



function staffinfo(){
  $('#staffinfo1').trigger('click');
}

</script>
<?php
$select_client = "SELECT * FROM client WHERE close = '1' AND status = '1'";
$select_client_ex = mysqli_query($con,$select_client);

$select_staff = "SELECT * FROM wt_users WHERE user_type = 'staff' AND close = '1' AND status = '1'";
$select_staff_ex = mysqli_query($con,$select_staff);

$select_shift = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id WHERE CONCAT(',', shifts.s_staff, ',') LIKE CONCAT('%,', '".$_SESSION['id']."', ',%') AND shifts.close = '1' AND shifts.status = '1' AND shift_dates.sd_complete = '0' AND shift_dates.sd_reject = '0' AND shift_dates.close = '1' AND shift_dates.status = '1'";
$select_shift_ex = mysqli_query($con,$select_shift);

$select_shift2 = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id WHERE shifts.s_staff = '".$_SESSION['id']."' AND shifts.close = '1' AND shifts.status = '1' AND shift_dates.sd_complete = '1' AND shift_dates.sd_reject = '0' AND shift_dates.close = '1' AND shift_dates.status = '1'";
$select_shift2_ex = mysqli_query($con,$select_shift2);

$select_shift3 = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id WHERE shifts.s_staff = '".$_SESSION['id']."' AND shifts.close = '1' AND shifts.status = '1' AND shift_dates.sd_complete = '2' AND shift_dates.sd_reject = '0' AND shift_dates.close = '1' AND shift_dates.status = '1'";
$select_shift3_ex = mysqli_query($con,$select_shift3);

$select_shift4 = "SELECT * FROM shifts JOIN shift_dates ON shifts.s_id = shift_dates.sd_s_id WHERE shifts.s_staff = '".$_SESSION['id']."' AND shifts.close = '1' AND shifts.status = '1' AND shift_dates.sd_complete = '0' AND shift_dates.sd_reject = '1' AND shift_dates.close = '1' AND shift_dates.status = '1'";
$select_shift4_ex = mysqli_query($con,$select_shift4);


$current_date = date('Y-m-d');

if (isset($_POST['complete_shift'])) {
       $sd_id = $_POST['sd_id'];
      $shift_time = $_POST['shift_time'];
      $hour = $_POST['hour'];
      $milage = $_POST['milage'];
      $expense = $_POST['expense'];
      $note = $_POST['note'];
      $rating = $_POST['rating'];
      $rating_feedback = $_POST['rating_feedback'];

       $complete_shift = "UPDATE shift_dates SET sd_complete = '2', sd_hour = '".$hour."', sd_milage = '".$milage."', sd_expense = '".$expense."', sd_note = '".$note."', sd_rating = '".$rating."', sd_rating_feedback = '".$rating_feedback."', sd_completed_date = '".$current_date."' WHERE sd_id = '".$sd_id."'";
      $complete_shift_ex = mysqli_query($con,$complete_shift);
      // if ($complete_shift_ex) {
      //       header('Location: shifts');
      // }
}

if (isset($_POST['complete_shift_withoutrating'])) {
       $sd_id = $_POST['sd_id'];
      $shift_time = $_POST['shift_time'];
      $hour = $_POST['hour'];
      $milage = $_POST['milage'];
      $expense = $_POST['expense'];
      $note = $_POST['note'];

       $complete_shift = "UPDATE shift_dates SET sd_complete = '2', sd_hour = '".$hour."', sd_milage = '".$milage."', sd_expense = '".$expense."', sd_note = '".$note."', sd_rating = '0', sd_rating_feedback = '', sd_completed_date = '".$current_date."' WHERE sd_id = '".$sd_id."'";
      $complete_shift_ex = mysqli_query($con,$complete_shift);
      // if ($complete_shift_ex) {
      //       header('Location: shifts');
      // }
}

if (isset($_POST['accept_shift'])) {
      $sd_id = $_POST['sd_id'];
      $s_id = $_POST['s_id'];
      $shift_time = $_POST['shift_time'];

      $accept_shift = "UPDATE shift_dates SET sd_complete = '1' WHERE sd_id = '".$sd_id."'";
      $accept_shift_ex = mysqli_query($con,$accept_shift);
      if ($accept_shift_ex) {
            $accept_shift1 = "UPDATE shifts SET s_staff = '".$_SESSION['id']."' WHERE s_id = '".$s_id."'";
            $accept_shift1_ex = mysqli_query($con,$accept_shift1);
      }

      // if ($accept_shift_ex) {
      //       header('Location: shifts');
      // }
}

if (isset($_POST['reject_shift'])) {
      $sd_id = $_POST['sd_id'];
      $s_id = $_POST['s_id'];
      $shift_time = $_POST['shift_time'];

      $reject_shift = "UPDATE shifts SET s_staff = REPLACE(s_staff, '".','.$_SESSION['id']."', '') WHERE s_id = '".$s_id."'";
      $reject_shift_ex = mysqli_query($con,$reject_shift);
      if ($reject_shift_ex) {
            $duplicate_shift = "INSERT INTO shifts (s_client, s_shift_type, s_staff, s_shiftdate, s_finish_next_day, s_starttime, s_endtime, s_repeat, s_recurrance, s_address, s_apartment, s_instructions, s_completed, create_date, close, status) SELECT s_client, s_shift_type, s_staff, s_shiftdate, s_finish_next_day, s_starttime, s_endtime, s_repeat, s_recurrance, s_address, s_apartment, s_instructions, s_completed, create_date, close, status FROM shifts WHERE s_id = '".$s_id."'";
            $duplicate_shift_ex = mysqli_query($con,$duplicate_shift);

            if ($duplicate_shift_ex) {
                  $last_id11 = $con->insert_id;;

                  $update_duplicate_shift = "UPDATE shifts SET s_staff = '".$_SESSION['id']."' WHERE s_id = LAST_INSERT_ID()";
                  $update_duplicate_shift_ex = mysqli_query($con,$update_duplicate_shift);
            }

            $duplicate_shift = "INSERT INTO shift_dates (sd_s_id, sd_date, sd_complete, sd_reject, sd_hour, sd_milage, sd_expense, sd_note, sd_rating, sd_rating_feedback, sd_completed_date, close, status) SELECT sd_s_id, sd_date, sd_complete, sd_reject, sd_hour, sd_milage, sd_expense, sd_note, sd_rating, sd_rating_feedback, sd_completed_date, close, status FROM shift_dates WHERE sd_id = '".$sd_id."'";
            $duplicate_shift_ex = mysqli_query($con,$duplicate_shift);

            if ($duplicate_shift_ex) {

                  $update_duplicate_shift_dates = "UPDATE shift_dates SET sd_reject = '1', sd_s_id = '".$last_id11."' WHERE sd_id = LAST_INSERT_ID()";
                  $update_duplicate_shift_dates_ex = mysqli_query($con,$update_duplicate_shift_dates);
            }
      }

      // if ($reject_shift_ex) {
      //       header('Location: shifts');
      // }
}
?>
<?php
$current_date = date('Y-m-d');
$current_month = date('m');
$current_month2 = date('F');
$current_year = date('Y');

$user_email = $_SESSION['user_email'];
$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['id']; 
$fetch = "SELECT * FROM wt_users WHERE email = '".$user_email."' AND status = '1' AND close = '1' AND user_type = 'staff'";
$execuit = mysqli_query($con,$fetch);

$current_date = date('Y-m-d');

$total_worked_hours = 0;
$select_total_hours = "SELECT *,SUM(sd_hour) FROM shift_dates JOIN shifts ON shift_dates.sd_s_id = shifts.s_id WHERE shift_dates.close = '1' AND shift_dates.status = '1' AND CONCAT(',', shifts.s_staff, ',') LIKE CONCAT('%,', '".$_SESSION['id']."', ',%')";
$select_total_hours_ex = mysqli_query($con,$select_total_hours);
foreach ($select_total_hours_ex as $row) {
  $total_worked_hours = $row['SUM(sd_hour)'];
}


$total_created_shifts = 0;
$select_created_shifts = "SELECT * FROM shift_dates JOIN shifts ON shift_dates.sd_s_id = shifts.s_id WHERE shift_dates.close = '1' AND shift_dates.status = '1' AND shift_dates.sd_reject = '0' AND CONCAT(',', shifts.s_staff, ',') LIKE CONCAT('%,', '".$_SESSION['id']."', ',%') ";
$select_created_shifts_ex = mysqli_query($con,$select_created_shifts);
$total_created_shifts = mysqli_num_rows($select_created_shifts_ex);

$total_accepted_shifts = 0;
$select_rejected_shifts = "SELECT * FROM shift_dates JOIN shifts ON shift_dates.sd_s_id = shifts.s_id WHERE shift_dates.close = '1' AND shift_dates.status = '1' AND shift_dates.sd_reject = '1' AND CONCAT(',', shifts.s_staff, ',') LIKE CONCAT('%,', '".$_SESSION['id']."', ',%')";
$select_rejected_shifts_ex = mysqli_query($con,$select_rejected_shifts);
$total_rejectd_shifts = mysqli_num_rows($select_rejected_shifts_ex);







$select_staff_with_most_hours = "SELECT *,SUM(sd_hour) FROM shifts JOIN shift_dates ON shifts.s_id=shift_dates.sd_s_id WHERE shift_dates.close = '1' AND shift_dates.status = '1' AND CONCAT(',', shifts.s_staff, ',') LIKE CONCAT('%,', '".$_SESSION['id']."', ',%') GROUP BY shifts.s_staff ORDER BY SUM(sd_hour) DESC";
$select_staff_with_most_hours_ex = mysqli_query($con,$select_staff_with_most_hours);

$weekly_repeated_shifts = array();
$i = 1;
$select_top_weekly_provided_services = "SELECT *,SUM(close) FROM shifts WHERE close = '1' AND status = '1' AND s_recurrance = 'weekly' AND CONCAT(',', s_staff, ',') LIKE CONCAT('%,', '".$_SESSION['id']."', ',%') GROUP BY s_shift_type ORDER BY SUM(close) DESC LIMIT 3";
$select_top_weekly_provided_services_ex = mysqli_query($con,$select_top_weekly_provided_services);
foreach ($select_top_weekly_provided_services_ex as $row) {
      $weekly_repeated_shifts[$i] = $row['s_shift_type'];
      $i++;
}




$monthly_repeated_shifts = array();
$j = 1;
$select_top_monthly_provided_services = "SELECT *,SUM(close) FROM shifts WHERE close = '1' AND status = '1' AND CONCAT(',', s_staff, ',') LIKE CONCAT('%,', '".$_SESSION['id']."', ',%') AND s_recurrance = 'monthly' GROUP BY s_shift_type ORDER BY SUM(close) DESC LIMIT 3";
$select_top_monthly_provided_services_ex = mysqli_query($con,$select_top_monthly_provided_services);
foreach ($select_top_monthly_provided_services_ex as $row) {
      $monthly_repeated_shifts[$j] = $row['s_shift_type'];
      $j++;
}






$current_month_shifts = 0;
$select_current_month_shifts = "SELECT SUM(close) AS total_shifts FROM shifts WHERE MONTH(create_date) = '".$current_month."' AND YEAR(create_date) = '".$current_year."' AND close = '1' AND status = '1' AND CONCAT(',', s_staff, ',') LIKE CONCAT('%,', '".$_SESSION['id']."', ',%') GROUP BY MONTH(create_date), YEAR(create_date)";
$select_current_month_shifts_ex = mysqli_query($con, $select_current_month_shifts);
foreach ($select_current_month_shifts_ex as $row) {
    $current_month_shifts = $row['total_shifts'];
}


$current_month_open_shifts = 0;
$current_month = date('m'); // Get current month
$current_year = date('Y'); // Get current year

$select_current_month_open_shifts = "SELECT * 
FROM shifts 
JOIN shift_dates ON shift_dates.sd_s_id = shifts.s_id 
WHERE MONTH(shifts.create_date) = '".$current_month."' 
AND YEAR(shifts.create_date) = '".$current_year."' 
AND shifts.close = '1' 
AND shifts.status = '1' 
AND CONCAT(',', shifts.s_staff, ',') LIKE CONCAT('%,', '".$_SESSION['id']."', ',%') 
AND shift_dates.sd_complete != '2' 
GROUP BY MONTH(shifts.create_date), YEAR(shifts.create_date)";

$select_current_month_open_shifts_ex = mysqli_query($con, $select_current_month_open_shifts);

if ($select_current_month_open_shifts_ex) {
    $current_month_open_shifts = mysqli_num_rows($select_current_month_open_shifts_ex);
}



$current_month_closed_shifts = 0;
$current_month = date('m'); // Get current month
$current_year = date('Y'); // Get current year

$select_current_month_closed_shifts = "SELECT * 
FROM shifts 
JOIN shift_dates ON shift_dates.sd_s_id = shifts.s_id 
WHERE MONTH(shifts.create_date) = '".$current_month."' 
AND YEAR(shifts.create_date) = '".$current_year."' 
AND shifts.close = '1' 
AND shifts.status = '1' 
AND CONCAT(',', shifts.s_staff, ',') LIKE CONCAT('%,', '".$_SESSION['id']."', ',%') 
AND shift_dates.sd_complete = '2' 
GROUP BY MONTH(shifts.create_date), YEAR(shifts.create_date)";

$select_current_month_closed_shifts_ex = mysqli_query($con, $select_current_month_closed_shifts);

if ($select_current_month_closed_shifts_ex) {
    $current_month_closed_shifts = mysqli_num_rows($select_current_month_open_shifts_ex);
}






?>
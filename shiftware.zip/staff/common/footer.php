
		</div>
	</div>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/jquery.3.2.1.min.js"></script>
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>
	<script src="../assets/dropify/dist/js/dropify.js"></script>

	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
	<!-- Select2 -->
	<script src="../assets/js/plugin/select2/select2.full.min.js"></script>
	<!-- Chart JS -->
	<script src="../assets/js/plugin/chart.js/chart.min.js"></script>

	<!-- jQuery Sparkline -->
	<script src="../assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

	<!-- Chart Circle -->
	<script src="../assets/js/plugin/chart-circle/circles.min.js"></script>

	<!-- Datatables -->
	<script src="../assets/js/plugin/datatables/datatables.min.js"></script>

	<!-- datatable -->
	<!-- <script src="../assets/js/lib/datatable/jquery-3.5.1.js"></script> -->
	<script src="../assets/js/lib/datatable/jquery.dataTables.min.js"></script>
	<script src="../assets/js/lib/datatable/dataTables.buttons.min.js"></script>
	<script src="../assets/js/lib/datatable/jszip.min.js"></script>
	<script src="../assets/js/lib/datatable/pdfmake.min.js"></script>
	<script src="../assets/js/lib/datatable/vfs_fonts.js"></script>
	<script src="../assets/js/lib/datatable/buttons.html5.min.js"></script>
	<script src="../assets/js/lib/datatable/buttons.print.min.js"></script>

	<!-- Bootstrap Notify -->
	<script src="../assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

	<!-- jQuery Vector Maps -->
	<script src="../assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>
	<script src="../assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>

	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

	<?php

      $total_accepted_shifts = 0;
      $select_accepted_shifts = "SELECT * FROM shift_dates WHERE sd_complete != '0' AND close = '1' AND status = '1'";
      $select_accepted_shifts_ex = mysqli_query($con,$select_accepted_shifts);
      $total_accepted_shifts = mysqli_num_rows($select_accepted_shifts_ex);

      $total_rejected_shifts = 0;
      $select_rejected_shifts = "SELECT * FROM shift_dates WHERE sd_reject = '1' AND close = '1' AND status = '1'";
      $select_rejected_shifts_ex = mysqli_query($con,$select_rejected_shifts);
      $total_rejected_shifts = mysqli_num_rows($select_rejected_shifts_ex);

	?>
	<script>
	Circles.create({
		id:'circles-1',
		radius:45,
		value:<?php echo round($total_created_shifts,1) ?>,
		maxValue:<?php echo round($total_created_shifts,1) ?>,
		width:7,
		text: <?php echo round($total_created_shifts,1) ?>,
		colors:['#f1f1f1', '#006AF5'],
		duration:400,
		wrpClass:'circles-wrp',
		textClass:'circles-text',
		styleWrapper:true,
		styleText:true
	})
	Circles.create({
		id:'circles-2',
		radius:45,
		value:<?php echo round($total_worked_hours,1) ?>,
		maxValue:<?php echo round($total_worked_hours,1) ?>,
		width:7,
		text: <?php echo round($total_worked_hours,1) ?>,
		colors:['#f1f1f1', '#2BB930'],
		duration:400,
		wrpClass:'circles-wrp',
		textClass:'circles-text',
		styleWrapper:true,
		styleText:true
	})

	Circles.create({
		id:'circles-3',
		radius:45,
		value:<?php echo round($total_rejected_shifts,1) ?>,
		maxValue:<?php echo round($total_rejected_shifts,1) ?>,
		width:7,
		text: <?php echo round($total_rejected_shifts,1) ?>,
		colors:['#f1f1f1', '#F25961'],
		duration:400,
		wrpClass:'circles-wrp',
		textClass:'circles-text',
		styleWrapper:true,
		styleText:true
	})
	var pieChart = document.getElementById('pieChart').getContext('2d');
	var myPieChart = new Chart(pieChart, {
			type: 'pie',
			data: {
				datasets: [{
					data: [<?php echo $total_accepted_shifts ?>, <?php echo $total_rejected_shifts ?>],
					backgroundColor :["#31D78A","#fdaf4b"],
					borderWidth: 0
				}],
				labels: ['Acepted', 'Rejected'] 
			},
			options : {
				responsive: true, 
				maintainAspectRatio: false,
				legend: {
					position : 'bottom',
					labels : {
						fontColor: 'rgb(154, 154, 154)',
						fontSize: 11,
						usePointStyle : true,
						padding: 20
					}
				},
				pieceLabel: {
					render: 'percentage',
					fontColor: 'white',
					fontSize: 14,
				},
				tooltips: false,
				layout: {
					padding: {
						left: 20,
						right: 20,
						top: 20,
						bottom: 20
					}
				}
			}
		})
</script>

<?php

      $total_accepted_shifts = 0;
      $select_completed_shifts = "SELECT *,count(sd_rating) FROM shift_dates WHERE close = '1' AND status = '1' GROUP BY sd_rating";
      $select_completed_shifts_ex = mysqli_query($con,$select_completed_shifts);
      $outstanding_rating = 0;
      $very_satisfied_rating = 0;
      $satisfied_rating = 0;
      $unsatisfied_rating = 0;
      $poor_rating = 0;
      foreach ($select_completed_shifts_ex as $row) {
      	if ($row['sd_rating'] == 5) {
      		$outstanding_rating = $row['count(sd_rating)'];
      	}
      	elseif ($row['sd_rating'] == 4) {
      		$very_satisfied_rating = $row['count(sd_rating)'];
      	}
      	elseif ($row['sd_rating'] == 3) {
      		$satisfied_rating = $row['count(sd_rating)'];
      	}
      	elseif ($row['sd_rating'] == 2) {
      		$unsatisfied_rating = $row['count(sd_rating)'];
      	}
      	elseif ($row['sd_rating'] == 1) {
      		$poor_rating = $row['count(sd_rating)'];
      	}
      }
	?>
<script>
	var pieChart2 = document.getElementById('pieChart2').getContext('2d');
	var myPieChart2 = new Chart(pieChart2, {
			type: 'pie',
			data: {
				datasets: [{
					data: [<?php echo $poor_rating ?>, <?php echo $unsatisfied_rating ?>, <?php echo $satisfied_rating ?>, <?php echo $very_satisfied_rating ?>, <?php echo $outstanding_rating ?>],
					backgroundColor :["#DF211D","#F97107","#F8B912","#C3D819","#78BD2C"],
					borderWidth: 0
				}],
				labels: ['Poor', 'Unsatisfy', 'Satisfy', 'Very Satisfy', 'Outstanding'] 
			},
			options : {
				responsive: true, 
				maintainAspectRatio: false,
				legend: {
					position : 'bottom',
					labels : {
						fontColor: 'rgb(154, 154, 154)',
						fontSize: 11,
						usePointStyle : true,
						padding: 20
					}
				},
				pieceLabel: {
					render: 'percentage',
					fontColor: 'white',
					fontSize: 14,
				},
				tooltips: false,
				layout: {
					padding: {
						left: 20,
						right: 20,
						top: 20,
						bottom: 20
					}
				}
			}
		})
</script>

<script>
	<?php
	$current_date = date('Y-m-d');
	$current_day = date('d');
	$current_month = date('m');
	$current_year = date('Y');
	?>
	barChart = document.getElementById('statisticsChart').getContext('2d');

	var myBarChart = new Chart(barChart, {
		type: 'bar',
		data: {
			// labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
			labels: [
				<?php
			      $mon = [];
			      $year = [];
			      $output1 = [];
			            $date1 = $current_year.'-01-01';
			            $date2 = $current_year.'-12-31';
			            $output = [];
			            $time   = strtotime($date1);
			            $last   = date('M-Y', strtotime($date2));
			            do {
			                $month = date('M-Y', $time);
			                $total = date('t', $time);
			                $output[] = "'".$month."'".",";
			                $output1[] = "'".$month."'".",";
			                $time = strtotime('+1 month', $time);
			            } while ($month != $last);
			            echo implode(" ", $output);
			    ?>
			],
			datasets : [{
				label: "Sales",
				backgroundColor: '#2EFF9F',
				borderColor: '#2EFF9F',
				data: [
					<?php
			        for ($i=1; $i <= 12; $i++) { 
			          $select_query = "SELECT *,SUM(in_total_amount) from invoice WHERE month(in_issue_date) = '".$i."' AND year(in_issue_date) = '".$current_year."' AND status = '1' AND close='1' GROUP BY month(in_issue_date),year(in_issue_date)";
			          $select_query_ex = mysqli_query($con,$select_query);
			          if (mysqli_num_rows($select_query_ex) != 0) {
			            foreach($select_query_ex as $month){
			                echo $month['SUM(in_total_amount)'].",";
			            }
			          }
			          else{
			            echo "0,";
			          }
			        }
			        ?>
				],
			}],
		},
		options: {
			responsive: true, 
			maintainAspectRatio: false,
			scales: {
				yAxes: [{
					ticks: {
						beginAtZero:true
					}
				}]
			},
		}
	});

	$('#lineChart').sparkline([105,103,123,100,95,105,115], {
		type: 'line',
		height: '70',
		width: '100%',
		lineWidth: '2',
		lineColor: '#ffa534',
		fillColor: 'rgba(255, 165, 52, .14)'
	});
</script>

<script type="text/javascript">
$(function($) {
    let url = window.location.href;
    const arr = url.split("?");
    $('.nav li a').each(function() {
        if (this.href === arr[0]) {
            $(this).closest('.pcoded-hasmenu').addClass('active pcoded-trigger');
            $(this).closest('ul').addClass('show');
            $(this).closest('li').addClass('active');
        }
    });
});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$('.dropify').dropify();
		$('#example').DataTable({
		    dom: 'Bfrtip',
		    buttons: [
		        'copy', 'csv', 'excel', 'pdf', {
		            extend: 'print',
		            className: "dt-center",
		            messageTop: "'"+title+"'",
		            title: '',
		            exportOptions: {
		                columns: Printcol
		            }
		        }
		    ],
		    "columnDefs": [
		        { "className": "dt-center", "targets": "_all" }
		    ]
		});

       

        $('#radioBtn a').on('click', function(){
          var sel = $(this).data('title');
          var tog = $(this).data('toggle');
          $('#'+tog).prop('value', sel);
          
          $('a[data-toggle="'+tog+'"]').not('[data-title="'+sel+'"]').removeClass('active').addClass('notActive');
          $('a[data-toggle="'+tog+'"][data-title="'+sel+'"]').removeClass('notActive').addClass('active');
        });
	});
function del(x,y) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won’t be able to reverse this !",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#bab8b8',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
            if (result.isConfirmed) {
                x(y);
            }
        })
}
$(".prevent").on("focus", function() {
    $(this).on("keydown", function(event) {
      if (event.keyCode === 38 || event.keyCode === 40) {
        event.preventDefault();
      }
    });
  });
</script>
<!-- <<<<<<<<Avoid continue>>>>>>>>> -->
<script type="text/javascript">
    if (window.history.replaceState){
        window.history.replaceState(null, null, window.location.href);
    }
</script>
</body>
</html>
<style type="text/css">

@import url('https://fonts.googleapis.com/css?family=Numans');

.container{
height: 100%;
align-content: center;
}

.card{
height: 370px;
margin-top: auto;
margin-bottom: auto;
width: 400px;
background: transparent;
/*background-color: rgba(0,0,0,0.5) !important;*/
}

.social_icon span{
    margin-top: 20px;
    margin-left: 10px;
    color: #31D78A;
}

.card-header h3{
color: #000;
}

.social_icon{
position: absolute;
right: 20px;
top: -45px;
}

.input-group-prepend span{
width: 50px;
background-color: #31D78A;
color: white;
border:0 !important;
}

input:focus{
outline: 0 0 0 0  !important;
box-shadow: 0 0 0 0 !important;

}

.remember{
color: white;
}

.remember input
{
width: 20px;
height: 20px;
margin-left: 15px;
margin-right: 5px;
}

.login_btn{
color: white;
background-color: #31D78A;
width: 100px;
}

.login_btn:hover{
color: black;
background-color: white;
}

.links{
color: white;
}

.links a{
margin-left: 4px;
}
</style>
<div class="container-fluid">
    <div class="container">
        <div class="d-flex justify-content-center h-100">
            <div class="card" style="margin-top:100px;">
                <div class="card-header">
                    <img src="assets/img/logo-transparent.png" width="170">
                  
                </div>
                <div class="card-body mt-5">
                    <form action="" method="post">
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fa fa-user ml-1"></i></span>
                            </div>
                            <input name="hdusername" type="text" class="form-control" placeholder="Your Username" autocomplete="off" required="required">
                        </div>
                        <div class="input-group form-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fa fa-key ml-1"></i></span>
                            </div>
                            <input name="hduserpassword" type="password" class="form-control" placeholder="Password" autocomplete="off" required="required">
                        </div>
                        <div class="form-group">
                             <button style="height: 60px; width: 60px;  border-radius: 50%;" id="" type="submit" name="hdsignin2" class="btn float-right login_btn"><i class="fa fa-arrow-right"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
	if (isset($_POST['hdsignin'])) {
		$log_email = $_POST['hdusername'];
		$log_pass = $_POST['hduserpassword'];
		$final_pass = md5($log_pass);

		$log_sql = "SELECT * FROM wt_users WHERE user_name = '".$log_email."' AND password = '".$final_pass."' AND close = '1' AND status = '1'";
		$log_sql_ex = mysqli_query($con,$log_sql);
		if (mysqli_num_rows($log_sql_ex) == '1') {
			foreach($log_sql_ex as $fetch){
				$_SESSION['user_loginName'] = $fetch['user_name'];
				$_SESSION['user_email'] = $fetch['email'];
				$_SESSION['id'] = $fetch['id'];
				$_SESSION['user_name'] = $fetch['f_name']." ".$fetch['l_name'];
				$_SESSION['type'] = $fetch['user_type'];
			}
			if ($_SESSION['type'] == 'admin') {
			 	header('Location: admin/dashboard');
			}elseif ($_SESSION['type'] == 'staff'){
				header('Location: staff/dashboard');
				//echo "string";
			}
			else{
				session_unset();
				header('Location: login');
			} 
		}
	}

	if (isset($_POST['hdsignin2'])) {
		$log_email = $_POST['hdusername'];
		$log_pass = $_POST['hduserpassword'];
		$final_pass = md5($log_pass);

		$log_sql = "SELECT * FROM wt_users WHERE user_name = '".$log_email."' AND password = '".$final_pass."' AND user_type = 'staff' AND close = '1' AND status = '1'";
		$log_sql_ex = mysqli_query($con,$log_sql);
		if (mysqli_num_rows($log_sql_ex) == '1') {
			foreach($log_sql_ex as $fetch){
				$_SESSION['user_loginName'] = $fetch['user_name'];
				$_SESSION['user_email'] = $fetch['email'];
				$_SESSION['id'] = $fetch['id'];
				$_SESSION['user_name'] = $fetch['f_name']." ".$fetch['l_name'];
				$_SESSION['type'] = $fetch['user_type'];
			}
			if ($_SESSION['type'] == 'staff'){
				header('Location: staff/dashboard');
			}else{
				session_unset();
				header('Location: login');
			} 
		}
	}
 ?>
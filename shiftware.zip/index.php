<?php 
  session_start();
  ob_start(); 
if(!isset($_GET['page'])){
  $_GET['page']= "login";
}
if(file_exists("controller/". $_GET['page'].".php")) 
{
    /* Common Header */
    $head_title = $_GET['page'];
    include_once('env/main_config.php');
    include_once("common/header.php");
  
    // incldue Controller here
    include_once("controller/". $_GET['page'].".php");
    
    // incldue template here
    include_once("web_temp/". $_GET['page'].".html.php");
    /* Common Footer */
    include_once("common/footer.php");
}else{
  ?>
  <img src="images/html-404-error.jpg" width="100%" height="100%">
  <?php
  die();
}
?>    